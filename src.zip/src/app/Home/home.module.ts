import { MaterialModule } from './../core/_helpers/material.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeComponent } from './components/home/home.component';
import { HomeRoutingModule } from './home-routing.module';
import { NgbPaginationModule} from '@ng-bootstrap/ng-bootstrap';


@NgModule({
  declarations: [HomeComponent],
  imports: [
    CommonModule,
    HomeRoutingModule,
    NgbPaginationModule,
    MaterialModule
  ],
  exports: [
    CommonModule,
    HomeRoutingModule,
    NgbPaginationModule,
    MaterialModule
  ]
})
export class HomeModule { }
