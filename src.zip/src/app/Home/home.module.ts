import { MaterialModule } from './../core/_helpers/material.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeComponent } from './components/home/home.component';
import { HomeRoutingModule } from './home-routing.module';
import { NgbPaginationModule} from '@ng-bootstrap/ng-bootstrap';
import { BlogModule } from '../Blog';
import { HomeHeaderComponent } from './components/home-header/home-header.component';


@NgModule({
  declarations: [HomeComponent, HomeHeaderComponent],
  imports: [
    CommonModule,
    HomeRoutingModule,
    NgbPaginationModule,
    MaterialModule,
    BlogModule
  ],
  exports: [
    CommonModule,
    HomeRoutingModule,
    NgbPaginationModule,
    MaterialModule,
    BlogModule,
    HomeComponent
  ]
})
export class HomeModule { }
