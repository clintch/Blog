import { trigger, transition, animate, style } from '@angular/animations';
import { Router } from '@angular/router';
import { Component, OnInit, ViewChild } from '@angular/core';
import { BlogService, BlogPost, } from 'src/app/core';
import { MatMenuTrigger } from '@angular/material/menu';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';

@Component({
  selector: 'home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  animations: [
    trigger('fade', [
      transition('void => *', [
        style({ opacity:0 }),
        animate(2000)
      ])
    ])
  ]
})
export class HomeComponent implements OnInit {


  title: string = "Welcome to Our Angular App";
  blogList: BlogPost[] = [];
  blog: BlogPost;
  page: number = 1;
  pageSize: number = 5;
  maxSize: number = 5;

  userid:number = 1;

  isHandset$: Observable<boolean> = this.breakpointObserver.observe(
    [ 
      Breakpoints.Handset,
      Breakpoints.HandsetPortrait, 
      Breakpoints.HandsetLandscape,
      Breakpoints.Tablet,
      Breakpoints.TabletPortrait,
      Breakpoints.TabletLandscape
    ])
    .pipe(
      map(result => result.matches),
      shareReplay()
  );

  constructor(
    private blogService: BlogService,
    private router: Router,
    private breakpointObserver: BreakpointObserver,
  ) { }

  ngOnInit(): void {
    this.blogService.getBlogList().subscribe(
      (response) => {
        this.blogList = response;
        console.log(response);
      }
    );
  }

  cancelClick(ev: MouseEvent) {
    ev.stopPropagation();
  }
}
