import { Router } from '@angular/router';
import { Component, OnInit, ViewChild } from '@angular/core';
import { BlogService, BlogPost, } from 'src/app/core';
import { MatMenuTrigger } from '@angular/material/menu';

@Component({
  selector: 'home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {


  title: string = "Welcome to Our Angular App";
  blogList: BlogPost[] = [];
  blog: BlogPost;
  page: number = 1;
  pageSize: number = 5;
  maxSize: number = 5;

  constructor(
    private blogService: BlogService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.blogService.getBlogList().subscribe(
      (response) => {
        this.blogList = response;
        console.log(response);
      }
    );
    // this.blogService.getBlogBySlug("SLUG-02").subscribe(
    //   (res) => {
    //     this.blog =res;
    //     console.log("Res :"+res)
    //   }
    // );
  }

  cancelClick(ev: MouseEvent) {
    ev.stopPropagation();
  }
}
