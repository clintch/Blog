import { Test } from './../../../core/_models/test';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { BlogOperationsService, BlogPost } from 'src/app/core';

@Component({
  selector: 'home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  title: string = "Welcome to Our Angular App";
  blogList: BlogPost[] = [];
  page: number = 1;
  pageSize: number = 5;
  maxSize: number = 5;

  constructor(
    private blogOperations: BlogOperationsService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.blogOperations.getblogList().subscribe(
      (response) => {
        this.blogList = response;
        console.log(response);
      }
    )
  }

}
