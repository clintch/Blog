import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FontAwesomeModule, FaIconLibrary } from '@fortawesome/angular-fontawesome';
import { faSyncAlt } from '@fortawesome/free-solid-svg-icons';

import { AdminRoutingModule } from './admin-routing.module';
import { AdminPageComponent } from './components/admin-page/admin-page.component';
import { AdminPageTotalCountCardComponent } from './components/admin-page-total-count-card/admin-page-total-count-card.component';
import { AdminPageDashboardComponent } from './components/admin-page-dashboard/admin-page-dashboard.component';
import { MaterialModule } from '../core';
import { AdminPageUserscardComponent } from './components/admin-page-userscard/admin-page-userscard.component';
import { AdminPageUserslistComponent } from './components/admin-page-userslist/admin-page-userslist.component';
import { AdminPageUserstableComponent } from './components/admin-page-userstable/admin-page-userstable.component';

import { AdminPageBlogcountChartComponent } from './components/admin-page-blogcount-chart/admin-page-blogcount-chart.component';
import { ChartsModule } from "ng2-charts";

@NgModule({
  declarations: [AdminPageComponent, AdminPageTotalCountCardComponent, AdminPageDashboardComponent, AdminPageUserscardComponent, AdminPageUserslistComponent, AdminPageUserstableComponent, AdminPageBlogcountChartComponent],
  imports: [
    CommonModule,
    AdminRoutingModule,
    MaterialModule,
    FontAwesomeModule,
    ChartsModule
   ],
  exports: [
    AdminPageComponent,
    MaterialModule,
    FontAwesomeModule,
  ]
})
export class AdminModule { 
  constructor(private library: FaIconLibrary) {
    library.addIcons(faSyncAlt);
  }
}
