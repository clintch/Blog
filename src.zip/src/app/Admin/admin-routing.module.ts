import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminPageComponent } from './components/admin-page';
import { AdminPageDashboardComponent } from './components/admin-page-dashboard';
import { AdminPageUserstableComponent } from './components/admin-page-userstable';

const routes: Routes = [
  {
    path: "",
    component: AdminPageComponent,
    children: [
      {
        path: "dashboard",
        component: AdminPageDashboardComponent
      },
      {
        path: "users",
        component: AdminPageUserstableComponent
      },
      {
        path: "",
        redirectTo: "/dashboard",
        pathMatch: 'full'
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
