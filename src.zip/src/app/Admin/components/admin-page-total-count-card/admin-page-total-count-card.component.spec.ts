import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminPageTotalCountCardComponent } from './admin-page-total-count-card.component';

describe('AdminPageTotalCountCardComponent', () => {
  let component: AdminPageTotalCountCardComponent;
  let fixture: ComponentFixture<AdminPageTotalCountCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminPageTotalCountCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminPageTotalCountCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
