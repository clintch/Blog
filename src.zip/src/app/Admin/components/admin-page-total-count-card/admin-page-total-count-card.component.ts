import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'admin-page-totalCountCard',
  templateUrl: './admin-page-total-count-card.component.html',
  styleUrls: ['./admin-page-total-count-card.component.css']
})
export class AdminPageTotalCountCardComponent implements OnInit {
  
  @Input() title: string;
  @Input() count: number;
  @Input() icon: string;
  constructor() { }

  ngOnInit(): void {
  }

}
