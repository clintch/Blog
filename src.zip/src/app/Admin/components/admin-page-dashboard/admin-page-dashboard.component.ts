import { Component, OnInit } from '@angular/core';
import { AdminService } from 'src/app/core';

@Component({
  selector: 'admin-page-dashboard',
  templateUrl: './admin-page-dashboard.component.html',
  styleUrls: ['./admin-page-dashboard.component.css']
})
export class AdminPageDashboardComponent implements OnInit {

  cardTitle1: string ="ACTIVE BLOGS";
  cardTitle2: string ="AUTH PENDING BLOGS";
  cardTitle3: string ="BLOG USERS";
  cardTitle4: string ="AUTH USERS";

  activeBlogsCount: number;
  authPendingBlogsCount: number;
  blogUsersCount: number;
  authUsersCount: number;

  iconactiveBlogs: string = "verified";
  iconauthPendingBlogs: string = "pending_actions";
  iconUsers: string = "group";
  iconauthUsers: string = "supervisor_account";

  constructor(
    private adminService: AdminService
  ) { }

  ngOnInit(): void {
    this.adminService.getCountAllBlogs().subscribe(
      (response) => {
        this.activeBlogsCount = response;
      }
    );
    this.adminService.getCountAllAuthPendingBlogs().subscribe(
      (response) => {
        this.authPendingBlogsCount = response;
      }
    )
    this.adminService.getCountAllBlogUsers().subscribe(
      (response) => {
        this.blogUsersCount = response;
      }
    )
    this.adminService.getCountAllAuthUsers().subscribe(
      (response) => {
        this.authUsersCount = response;
      }
    )
  }

}
