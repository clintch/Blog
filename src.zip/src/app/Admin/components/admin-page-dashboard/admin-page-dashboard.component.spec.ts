import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminPageDashboardComponent } from './admin-page-dashboard.component';

describe('AdminPageDashboardComponent', () => {
  let component: AdminPageDashboardComponent;
  let fixture: ComponentFixture<AdminPageDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminPageDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminPageDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
