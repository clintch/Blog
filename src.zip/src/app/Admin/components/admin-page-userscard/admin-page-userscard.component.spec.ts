import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminPageUserscardComponent } from './admin-page-userscard.component';

describe('AdminPageUserscardComponent', () => {
  let component: AdminPageUserscardComponent;
  let fixture: ComponentFixture<AdminPageUserscardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminPageUserscardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminPageUserscardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
