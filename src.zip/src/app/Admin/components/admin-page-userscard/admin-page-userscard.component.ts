import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'admin-page-userscard',
  templateUrl: './admin-page-userscard.component.html',
  styleUrls: ['./admin-page-userscard.component.css']
})
export class AdminPageUserscardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
