import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTable } from '@angular/material/table';
import { AdminPageUserstableDataSource } from './admin-page-userstable-datasource';
import { AdminService, UserMaster } from 'src/app/core';
import { DatePipe } from '@angular/common';
import {animate, state, style, transition, trigger} from '@angular/animations';

@Component({
  selector: 'app-admin-page-userstable',
  templateUrl: './admin-page-userstable.component.html',
  styleUrls: ['./admin-page-userstable.component.css'],
  providers: [DatePipe],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({height: '0px', minHeight: '0'})),
      state('expanded', style({height: '*'})),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class AdminPageUserstableComponent implements AfterViewInit, OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatTable) table: MatTable<UserMaster>;
  dataSource: AdminPageUserstableDataSource;
  expandedElement: UserMaster | null;
  space: string=" ";
  labelPosition: 'before' | 'after' = 'after';
  checkAuthFlagY: boolean = false;
  checkAuthFlagN: boolean = false;
  checkUserStatusA: boolean = false;
  checkUserStatusB: boolean = false;
  checkUserStatusI: boolean = false;

  /** Columns displayed in the table. Columns IDs can be added, removed, or reordered. */
  displayedColumns = ['userId', 'firstName', 'lastName', 'primaryEmail', 'primaryMobile', 'addDate', 'status'];

  constructor(
    private adminService: AdminService
  ) {
    console.log("userId:: "+ this.displayedColumns[1]);
  }

  ngOnInit() {
    this.dataSource = new AdminPageUserstableDataSource(this.adminService);
  }

  ngAfterViewInit() {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
    this.table.dataSource = this.dataSource;
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    // this.dataSource.filter = filterValue.trim().toLowerCase();
  }
  statusChanged(event, userId: string) {
    this.adminService.updateUserStatus(event.value, Number(userId)).subscribe(
      (response) => {
        console.log("Opertion Success: "+response);
      },
      (err) => {
        console.log("OPeration Falied: "+err);
      }
    )
  }
  
}
