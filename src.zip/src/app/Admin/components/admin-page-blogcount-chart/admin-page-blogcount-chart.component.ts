import { Component, OnInit, ViewChild } from '@angular/core';
import { ChartDataSets, ChartOptions } from 'chart.js';
import { Color, BaseChartDirective, Label } from 'ng2-charts';
import { AdminService } from 'src/app/core';

@Component({
  selector: 'admin-page-blogcount-chart',
  templateUrl: './admin-page-blogcount-chart.component.html',
  styleUrls: ['./admin-page-blogcount-chart.component.css']
})
export class AdminPageBlogcountChartComponent implements OnInit {

  labels: number[] = [2020, 2021, 2022, 2023, 2024];
  selected = this.labels[0];

  chartData: number[] =[0,0,0,0,0,0,0,0,0,0,0,0] ;

  public lineChartData: ChartDataSets[] = [
    { data: this.chartData, label: 'TOTAL BLOG COUNT OF EACH MONTH AGAINST '+ this.selected },
   ];

  public lineChartLabels: Label[] = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'OCT', 'NOV', 'DEC'];
  public lineChartOptions: (ChartOptions) = {
    responsive: true,
  };
  public lineChartColors: Color[] = [
      { // red
      backgroundColor: 'rgba(255,0,0,0.3)',
      borderColor: 'red',
      pointBackgroundColor: 'rgba(148,159,177,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(148,159,177,0.8)'
    }
  ];
  public lineChartLegend = true;
  public lineChartType = 'line';

  @ViewChild(BaseChartDirective, { static: true }) chart: BaseChartDirective;

  constructor(
    private adminService: AdminService
  ) { }

  ngOnInit() {
    console.log("chartData: "+this.chartData);
      this.adminService.getCountAllBlogsMonthwiseByYear(this.selected).subscribe(
        (response) => {
          console.log(response);
          for (let i = 0; i < 12; i++) {
            if( i+1 === response[i].month )
              this.chartData[i] = response[i].count;  
          }
        }
      );
      console.log("chartData: "+this.chartData);
  }

  public onYearChange(year:any): void {
    this.adminService.getCountAllBlogsMonthwiseByYear(year.value).subscribe(
      (response) => {
        console.log(response);
        this.chartData = [0];
        for (let i = 0; i < response.length; i++) {
          if( i+1 === response[i].month )
            this.chartData[i] = response[i].count;  
        }
      }
    );
    this.chart.update();
  }



  // events
  // public chartClicked({ event, active }: { event: MouseEvent, active: {}[] }): void {
  //   console.log(event, active);
  // }

  // public chartHovered({ event, active }: { event: MouseEvent, active: {}[] }): void {
  //   console.log(event, active);
  // }

}
