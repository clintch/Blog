import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminPageBlogcountChartComponent } from './admin-page-blogcount-chart.component';

describe('AdminPageBlogcountChartComponent', () => {
  let component: AdminPageBlogcountChartComponent;
  let fixture: ComponentFixture<AdminPageBlogcountChartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminPageBlogcountChartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminPageBlogcountChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
