import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'admin-page-userslist',
  templateUrl: './admin-page-userslist.component.html',
  styleUrls: ['./admin-page-userslist.component.css']
})
export class AdminPageUserslistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
