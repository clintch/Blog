import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminPageUserslistComponent } from './admin-page-userslist.component';

describe('AdminPageUserslistComponent', () => {
  let component: AdminPageUserslistComponent;
  let fixture: ComponentFixture<AdminPageUserslistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminPageUserslistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminPageUserslistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
