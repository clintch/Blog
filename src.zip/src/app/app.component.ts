import { Component, OnInit, ViewChild } from '@angular/core';
import { SocialAuthService } from 'angularx-social-login';
import { Router } from '@angular/router';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';
import { MatMenuTrigger } from '@angular/material/menu';
import { TokenStorageService } from 'src/app/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'blogvF1';

 
  @ViewChild(MatMenuTrigger) ddTrigger: MatMenuTrigger;

  socialUser: any = null;
  loggedIn: boolean = false;
  isRoleAdmin: boolean = false;
  isRoleMod: boolean = false;
  private roles: string[];
  signin: string = "signin";
  showModeratorBoard = false;
  username: string;
  
  isHandset$: Observable<boolean> = this.breakpointObserver.observe(
    [ 
      Breakpoints.Tablet, 
      Breakpoints.TabletPortrait, 
      Breakpoints.TabletLandscape,
      Breakpoints.Handset,
      Breakpoints.HandsetPortrait,
      Breakpoints.HandsetLandscape,
    ])
    .pipe(
      map(result => result.matches),
      shareReplay()
  );
  isTablet$: Observable<boolean> = this.breakpointObserver.observe(
    [ 
      Breakpoints.Tablet, 
      Breakpoints.TabletPortrait, 
      Breakpoints.TabletLandscape,
    ])
    .pipe(
      map(result => result.matches),
      shareReplay()
  );

  constructor(
    private breakpointObserver: BreakpointObserver, 
    private router: Router,  
    private socialAuthService: SocialAuthService,
    private tokenService: TokenStorageService
  ) {}


  ngOnInit(): void {
    this.socialAuthService.authState.subscribe((socialUser) => {
      this.socialUser = socialUser;
      this.loggedIn = socialUser != null;
    });

    if(this.tokenService.getCookieToken().length>0 || this.tokenService.getSessionToken().length>0) {
      this.loggedIn = null;
    }
    this.loggedIn = !!this.tokenService.getSessionToken();

    if (this.loggedIn) {
      const user = this.tokenService.getSessionUser();
      this.roles = user.roles;

      this.isRoleAdmin = this.roles.includes('ROLE_ADMIN');
      this.isRoleMod = this.roles.includes('ROLE_MODERATOR');

      this.username = user.email;
    }
  }

  cancelClick(ev: MouseEvent) {
    ev.stopPropagation();
  }
  profile_name: string ="profileName";
  // signin: boolean=false;
  // toggle() {
  //   this.signin = !this.signin;
  // }


  logout() {
    this.socialAuthService.signOut();
    window.sessionStorage.clear();
    window.location.reload();
    this.router.navigate(["/signin"]);
  }

}
