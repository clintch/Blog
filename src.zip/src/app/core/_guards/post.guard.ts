import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot} from '@angular/router';
import { Observable, of} from 'rxjs';
import { BlogService } from '../_services';
import { switchMap } from 'rxjs/operators';

@Injectable()
export class PostGuard implements CanActivate {

  truefalse : boolean;
  constructor(
    private blogService: BlogService
  ){}

  canActivate(_next: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    // return this.blogService.getBlogBySlug(_next.params.blog).pipe(
    //   switchMap(blog => {
    //       if (blog) {
    //           return of(true);
    //       }
    //       return of(false);
    //   })
    // );
    // let slug = this._next.snapshot.paramMap.get('blog');
    let route = _next.paramMap.get('blog');
    console.log("route : "+route);

    if(route == "edit-profile") {
      return false;
        }
    else {
      return true;
    }
   
  }
}
