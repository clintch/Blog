import { UserMaster } from 'src/app/core';
import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";
import { Json } from '../_models';

const API_URL = "http://localhost:8080/";
const URL_BASE = "https://jsonplaceholder.typicode.com/posts";
const httpOptions = {
  headers: new HttpHeaders({ "Content-Type": "application/json" }),
};

@Injectable({
  providedIn: "root",
})
export class UserService {
  constructor(private httpClient: HttpClient) {}

  // public headersGetter() {
  //   let username = "admin";
  //   let password = "password";
  //   const headers = new HttpHeaders({
  //     Authorization: "Basic " + window.btoa(username + ":" + password),
  //   });
  //   return headers;
  // }

  //   public findAll() {
  //   const headers = this.headersGetter();
  //   return this.httpClient.get<User[]>(this.url, { headers });
  // }
  // public insert(user: User) {
  //   const headers = this.headersGetter();
  //   return this.httpClient.post<User>(this.url, user, { headers });
  // }


  /*
  getAllUsers(): Observable<UserMaster[]> {
    return this.httpClient.get<UserMaster[]>(API_URL + "all");
  }
*/

  getAllUsers(): Observable<Json[]> {
    return this.httpClient.get<Json[]>(URL_BASE);
  }

  getBlogList(status: string): Observable<Json[]> {
    return this.httpClient.get<Json[]>(URL_BASE+"?userId="+status,httpOptions)
  }

  socialsignin(user): Observable<any> {
    return this.httpClient.post(
      API_URL + "social",
      {
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email,
        username: user.username,
        password: user.password,
      },
      httpOptions
    );
  }



  getById(id): Observable<any> {
    return this.httpClient.get(API_URL + "id/" + id);
  }

  delete(id): Observable<any> {
    return this.httpClient.delete(API_URL + id);
  }

  getbyUsername(username): Observable<any> {
    return this.httpClient.get(API_URL + "username/" + username);
  }

  getToken(token: any) {
    return this.httpClient.post(
      API_URL+"confirm-account",
      {
        token: token.number,
      },
      httpOptions   
    );
  }
}
