import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";

const API_URL = "http://localhost:8080/api/custom/";

const httpOptions = {
  headers: new HttpHeaders({ "Content-Type": "application/json" }),
};

@Injectable({
  providedIn: "root",
})
export class UserService {
  constructor(private httpClient: HttpClient) {}

  // public headersGetter() {
  //   let username = "admin";
  //   let password = "password";
  //   const headers = new HttpHeaders({
  //     Authorization: "Basic " + window.btoa(username + ":" + password),
  //   });
  //   return headers;
  // }

  //   public findAll() {
  //   const headers = this.headersGetter();
  //   return this.httpClient.get<User[]>(this.url, { headers });
  // }
  // public insert(user: User) {
  //   const headers = this.headersGetter();
  //   return this.httpClient.post<User>(this.url, user, { headers });
  // }
  getAllUsers(): Observable<any> {
    return this.httpClient.get(API_URL + "all");
  }

  socialsignin(user): Observable<any> {
    return this.httpClient.post(
      API_URL + "social",
      {
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email,
        username: user.username,
        password: user.password,
      },
      httpOptions
    );
  }

  getById(id): Observable<any> {
    return this.httpClient.get(API_URL + "id/" + id);
  }

  delete(id): Observable<any> {
    return this.httpClient.delete(API_URL + id);
  }

  getbyUsername(username): Observable<any> {
    return this.httpClient.get(API_URL + "username/" + username);
  }
}
