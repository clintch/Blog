import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";
import { UserMaster } from 'src/app/core';
import { Json, ParentComment, Comment, ChildComment } from '../_models';
import { environment } from "../../../environments/environment";

const URL_BASE = "https://jsonplaceholder.typicode.com/posts";
const PROFILE_POSTS = "https://jsonplaceholder.typicode.com/posts?userId=";  //check tomorrow
const httpOptions = {
  headers: new HttpHeaders({ "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }),
};

@Injectable({
  providedIn: "root",
})
export class UserService {
  API_URL = environment.API_URL;
  constructor(
    // private API_URL = environment.API_URL,
    private httpClient: HttpClient
    ) {}

  // public headersGetter() {
  //   let username = "admin";
  //   let password = "password";
  //   const headers = new HttpHeaders({
  //     Authorization: "Basic " + window.btoa(username + ":" + password),
  //   });
  //   return headers;
  // }

  //   public findAll() {
  //   const headers = this.headersGetter();
  //   return this.httpClient.get<User[]>(this.url, { headers });
  // }
  // public insert(user: User) {
  //   const headers = this.headersGetter();
  //   return this.httpClient.post<User>(this.url, user, { headers });
  // }


  /*
  getAllUsers(): Observable<UserMaster[]> {
    return this.httpClient.get<UserMaster[]>(API_URL + "all");
  }
*/

  getAllUsers(): Observable<Json[]> {
    return this.httpClient.get<Json[]>(this.API_URL);
  }

  getProfileBlogs(id: number): Observable<Json[]> {
    return this.httpClient.get<Json[]>(PROFILE_POSTS+id);
  }

  deleteId(id: number): Observable<Json[]> {
    return this.httpClient.get<Json[]>(URL_BASE+"/"+id);
  }

  getBlogList(status: string): Observable<Json[]> {
    return this.httpClient.get<Json[]>(URL_BASE+"?userId="+status,httpOptions)
  }

  socialsignin(user): Observable<any> {
    return this.httpClient.post(
      this.API_URL + "social",
      {
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email,
        username: user.username,
        password: user.password,
      },
      httpOptions
    );
  }



  getById(id): Observable<any> {
    return this.httpClient.get(this.API_URL + "id/" + id);
  }

  delete(id): Observable<any> {
    return this.httpClient.delete(this.API_URL + id);
  }

  getbyUsername(username): Observable<any> {
    return this.httpClient.get(this.API_URL + "username/" + username);
  }

  //Token Authentication of account
  getToken(token: any): Observable<any> {
    return this.httpClient.post(
      this.API_URL+"confirm-account",
      {
        token: token.number,
      },
      httpOptions   
    );
  }

  //Checking Email Availability
  checkEmail(email): Observable<any> {
    return this.httpClient.post(
      this.API_URL+"confirm-account",
      {
        primaryEmail:email,
      },
      httpOptions
    )
  }

  //Getting Details of User initial stage of Profile Page
  getUserDetailsById(id: number): Observable<UserMaster> {
    return this.httpClient.post<UserMaster>(
      this.API_URL+"getUserDetailsById",
      {
        userId: id,
      },
      httpOptions
    );
  }


  //Change Status Priavte P to Active A
  changePrivateToActivePost(blogid: number, userid: number):Observable<number> {
    return this.httpClient.post<number>(
      this.API_URL + "blog/statusUpdation",
      {
        blogId: blogid,
        userId: userid,
        status: "P"
      },
      httpOptions
    );
  }//end

  //Change Status Active A to Private P
  changeActiveToPrivatePost(blogid: number, userid: number):Observable<any> {
    return this.httpClient.post(
      this.API_URL + "/blog/",
      {
        blogId: blogid,
        userId: userid,
      },
      httpOptions
    );
  }//end

  //Change Status Draft D to Active A
  changeDraftToActivePost(blogid: number, userid: number):Observable<any> {
    return this.httpClient.post(
      this.API_URL + "/blog/",
      {
        blogId: blogid,
        userId: userid,
      },
      httpOptions
    );
  }//end

  //Change AuthFlag P to A
  changeAuthFlagPtoA(blogid: number, userid: number):Observable<any> {
    return this.httpClient.post(
      this.API_URL + "/blog/",
      {
        blogId: blogid,
        userId: userid,
      },
      httpOptions
    );  
  }//end

  //Blog Comment Posting
  postParentComment(comment: ParentComment): Observable<number> {
    return this.httpClient.post<number>(
      this.API_URL+"blog/SaveBlogParentComment",
      {
        userId: 1,
        blogId: comment.blogId,
        parentContent:comment.parentContent,
      },
      httpOptions
    );
  }

  postChildComment(comment: ChildComment): Observable<number> {
    return this.httpClient.post<number>(
      this.API_URL+"blog/SaveBlogChildComment",
      {
        userId: 1,
        blogId: comment.blogId,
        childContent:comment.childContent,
        parentId: comment.parentId,
      },
      httpOptions
    );
  }//end

  //Like and DisLike
  addLikeCount(blogid: number, userid: number, type: string): Observable<number> {
    if(type === "like") {
      return this.httpClient.post<number>(
        this.API_URL+"blog/saveLike",
        {
          blogId: blogid,
          userId: userid,
        },
        httpOptions
      );
    }
    else {
      return this.httpClient.post<number>(
        this.API_URL+"blog/saveDisLike",
        {
          blogId: blogid,
          userId: userid,
        },
        httpOptions
      );
    }
  }//end

  addViewCount(): Observable<any> {
    let add = 1;
    return this.httpClient.post<any>(
      this.API_URL+"blog/addViewCount",
      {
        viewCount: add,
      },
      httpOptions
    )
  }

}
