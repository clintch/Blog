import { UniversalLoginStg } from 'src/app/core';
import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { map } from "rxjs/operators";
import {
  SocialAuthService,
  GoogleLoginProvider,
  FacebookLoginProvider,
} from "angularx-social-login";
import { Observable } from "rxjs";
import { Router } from "@angular/router";

const AUTH_API = "http://150.1.16.146:8090/";
const httpOptions = {
  headers: new HttpHeaders({ "Content-Type": "application/json", "Access-Control-Allow-Origin": "*"}),
};
const TOKEN_KEY = "token";
const USER_KEY = "user";

@Injectable({
  providedIn: "root",
})
export class AuthenticateService {
  roles: any[];
  invalidLogin: boolean;
  constructor(
    private httpClient: HttpClient,
    private authService: SocialAuthService,
    private router: Router
  ) {}

  // public auth(user: User) {
  //   return this.httpClient.post<User>(this.url, user);
  // }
  // authenticate(user: User) {
  //   return this.httpClient.post<User>(this.url, user).pipe(
  //     map((userData) => {
  //       sessionStorage.setItem("email", user.email);
  //       let tokenStr = "Bearer " + userData.token;
  //       sessionStorage.setItem("token", tokenStr);
  //       return userData;
  //     })
  //   );
  // }
  authenticate(credentials): Observable<any> {
    return this.httpClient.post(
      AUTH_API + "api/auth/signin",
      {
        username: credentials.primaryEmail,
        password: credentials.passwordHash,
      },
      httpOptions
    );
  }

  register(user: UniversalLoginStg): Observable<any> {
    return this.httpClient.post(AUTH_API + "userSignUpSave",user,httpOptions);
  }

  public getToken(): string {
    return sessionStorage.getItem(TOKEN_KEY);
  }

  public getUser() {
    return JSON.parse(sessionStorage.getItem(USER_KEY));
  }
  isUserLoggedIn() {
    let user = sessionStorage.getItem(USER_KEY);
    //console.log(!(user === null));
    return !(user === null);
  }

  isAdmin() {
    this.roles = this.getUser().roles;
    return this.roles.includes("ROLE_ADMIN") ? true : false;
  }

  gooFaceSignIn(socialPlatform: string) {
    let socialPlatformProvider: any;
    if (socialPlatform == "facebook")
      socialPlatformProvider = FacebookLoginProvider.PROVIDER_ID;
    else if (socialPlatform == "google")
      socialPlatformProvider = GoogleLoginProvider.PROVIDER_ID;

    this.authService.signIn(socialPlatformProvider).then((response) => {
      window.sessionStorage.removeItem(USER_KEY);
      window.sessionStorage.setItem(USER_KEY, JSON.stringify(response.name));
      window.sessionStorage.removeItem(TOKEN_KEY);
      window.sessionStorage.setItem(TOKEN_KEY, response.idToken);
      console.log("Yess   asasaskjhakshdkjhk");
      console.log(response);
      // this.user.firstName = response.firstName;
      // this.user.lastName = response.lastName;
      // this.user.email = response.email;
      // this.user.username = response.name;
      // this.user.password = response.provider;
      // this.userService.socialsignin(this.user).subscribe((data) => {
      //   console.log(data);
      // });
      //this.storage(response);
      this.invalidLogin = true;
      //this.reloadPage();
      this.router.navigate(["/profile"]);
    });
  }

  signOut(): void {
    this.authService.signOut();
    window.sessionStorage.clear();
  }
}
