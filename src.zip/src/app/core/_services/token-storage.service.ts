import { CookieService } from 'ngx-cookie-service';
import { Injectable } from '@angular/core';

const TOKEN_KEY = 'auth-token';
const USER_KEY = 'auth-user';
@Injectable({
  providedIn: 'root'
})
export class TokenStorageService {

  constructor(
    private cookieService: CookieService
  ) { }

  signOut() {
    window.sessionStorage.clear();
  }

  public saveToken(token: string) {
    window.sessionStorage.removeItem(TOKEN_KEY);
    window.sessionStorage.setItem(TOKEN_KEY, token);
    this.cookieService.set(TOKEN_KEY, token);
  }

  public getSessionToken(): string {
    return sessionStorage.getItem(TOKEN_KEY);
  }

  public getCookieToken(): string {
    return this.cookieService.get(TOKEN_KEY);
  }

  public saveUser(user) {
    window.sessionStorage.removeItem(USER_KEY);
    window.sessionStorage.setItem(USER_KEY, JSON.stringify(user));
    this.cookieService.set(USER_KEY, JSON.stringify(user));
  }

  public getSessionUser() {
    return JSON.parse(sessionStorage.getItem(USER_KEY));
  }

  public getCookieUser() {
    return JSON.parse(this.cookieService.get(USER_KEY));
  }
}
