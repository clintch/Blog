import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from "rxjs";
import { BlogPost, Comment } from '../_models';
import { environment } from "../../../environments/environment";

const httpOptions = {
  headers: new HttpHeaders({ "Content-Type": "application/json", "Access-Control-Allow-Origin": "*"}),
};

@Injectable({
  providedIn: "root",
})
export class BlogService {
  API_URL = environment.API_URL;
  // url_Post: string = "http://150.1.13.252:8686/";
  // url_Comments: string = "https://jsonplaceholder.typicode.com/comments";
  // url_Post_Json: string = "https://jsonplaceholder.typicode.com/posts";
  // new_URL: string = "https://gorest.co.in/public-api/users";
  constructor(
    private httpClient: HttpClient
    ) {}

  getBlogList(): Observable<BlogPost[]> {
    return this.httpClient.get<BlogPost[]>(this.API_URL+"blog/getAllBlogs", httpOptions);
  }

  getBlogBySlug(slugname:string): Observable<BlogPost[]> {
    return this.httpClient.post<BlogPost[]>(
      this.API_URL+"blog/getBlogBySlug", 
      {
        slug: slugname,
      }, 
      httpOptions
    );
  }

  // getComments(postid): Observable<any> {
  //   return this.httpClient.get(this.url_Comments+"?postId="+postid, httpOptions);
  // }

  getActiveUserBlogList(userid: number): Observable<BlogPost[]> {
    return this.httpClient.post<BlogPost[]>(
      this.API_URL+"getAllBlogByStatus",
      {
        userId: userid,
        status: "A"
      },
      httpOptions
    );
  }

  getDraftUserBlogList(userid: number): Observable<BlogPost[]> {
    return this.httpClient.post<BlogPost[]>(
      this.API_URL+"getAllBlogByStatus",
      {
        userId: userid,
        status: "D"
      },
      httpOptions
    );
  }
  getPrivateUserBlogList(userid: number): Observable<BlogPost[]> {
    return this.httpClient.post<BlogPost[]>(
      this.API_URL+"getAllBlogByStatus",
      {
        userId: userid,
        status: "P"
      },
      httpOptions
    );
  }
  getAuthPendingUserBlogList(userid: number): Observable<BlogPost[]> {
    return this.httpClient.post<BlogPost[]>(
      this.API_URL+"getAllBlogByAuthFlag",
      {
        userId: userid,
        authFlag: "P"
      },
      httpOptions
    );
  }

  addLikeCount(blogidOfType: number, useridOfType: number, type: string): Observable<any> {
    return this.httpClient.post<any>(
      this.API_URL+"blog/addLikeCount",
      {
        blogid: blogidOfType,
        userid: useridOfType,
        counttype: type,
      },
      httpOptions
    )
  }

  addViewCount(): Observable<any> {
    let add = 1;
    return this.httpClient.post<any>(
      this.API_URL+"blog/addViewCount",
      {
        viewCount: add,
      },
      httpOptions
    )
  }

    //Blog Comment Posting
    postParentComment(comment: Comment): Observable<any> {
      return this.httpClient.post<any>(
        this.API_URL+"blogPostParentComment",
        {
          userId: comment.userId,
          blogId: comment.blogId,
          parentContent:comment.content
        },
        httpOptions
      )
    }

}
