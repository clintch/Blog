import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from "rxjs";
import { BlogPost, Comment } from '../_models';
import { environment } from "../../../environments/environment";


const params = new HttpParams().set('authFlag', "P");
 
const httpOptions = {
  headers: new HttpHeaders({ "Content-Type": "application/json", "Access-Control-Allow-Origin": "*"}),
};

@Injectable({
  providedIn: "root",
})
export class BlogService {
  API_URL = environment.API_URL;
  // url_Post: string = "http://150.1.13.252:8686/";
  // url_Comments: string = "https://jsonplaceholder.typicode.com/comments";
  // url_Post_Json: string = "https://jsonplaceholder.typicode.com/posts";
  // new_URL: string = "https://gorest.co.in/public-api/users";
  constructor(
    private httpClient: HttpClient
    ) {}

  //getting all blogs having authFlag = A and status = A
  getBlogList(): Observable<BlogPost[]> {
    return this.httpClient.get<BlogPost[]>(this.API_URL+"blog/getAllBlogs", httpOptions);
  }

  getBlogBySlug(slugname:string): Observable<BlogPost[]> {
    return this.httpClient.post<BlogPost[]>(
      this.API_URL+"blog/getAllBlogBySlug", 
      {
        slug: slugname,
      }, 
      httpOptions
    );
  }

  getBlogByBlogId(blogId: number): Observable<BlogPost> {
    return this.httpClient.post<BlogPost>(
      this.API_URL+"blog/getBlog",
      {
        blogId: blogId,
      },
      httpOptions
    );
  }

  // getComments(postid): Observable<any> {
  //   return this.httpClient.get(this.url_Comments+"?postId="+postid, httpOptions);
  // }

//4200/profile
  getBlogListByStatus(userid: number, status: string): Observable<BlogPost[]> {
    return this.httpClient.post<BlogPost[]>(
      this.API_URL+"blog/getAllBlogByStatus",
      {
        userId: userid,
        status: status,
      },
      httpOptions
    );
  }
  
  
  getUserBlogListByAuthFlagPending(userid: number): Observable<BlogPost[]> {
    return this.httpClient.post<BlogPost[]>(
      this.API_URL+"blog/getAllUserBlogByAuthFlagPending",
      {
        userId: userid,
      },
      httpOptions
    );
  }

  //getting all blogs having authFlag=P and status=A
  getBlogListByAuthFlagPending(): Observable<BlogPost[]> {
    return this.httpClient.get<BlogPost[]>(
      this.API_URL+"blog/getAllBlogByAuthFlagPendingStatusActive", httpOptions
    );
  }
}
