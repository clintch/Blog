import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpEvent, HttpRequest } from "@angular/common/http";
import { Observable } from "rxjs";
import { UserMaster, Json, ParentComment, Comment, ChildComment} from 'src/app/core';
import { environment } from "../../../environments/environment";
import { BlogCountMonth } from '../_models';

const httpOptions = {
  headers: new HttpHeaders({ "Content-Type": "application/json", "Access-Control-Allow-Origin": "*"}),
};


@Injectable({
  providedIn: 'root'
})
export class AdminService {
  API_URL = environment.API_URL;
  constructor(
    private httpClient: HttpClient
  ) { }

  getAllUsers(): Observable<UserMaster[]> {
    return this.httpClient.get<UserMaster[]>(this.API_URL+"admin/getAllUsersAndModerators");
  }

  getCountAllAuthUsers(): Observable<number> {
    return this.httpClient.get<number>(this.API_URL+"admin/getCountAllAuthUsers");
  }

  getCountAllBlogUsers(): Observable<number> {
    return this.httpClient.get<number>(this.API_URL+"admin/getCountAllUsersAndModerators");
  }

  getCountAllBlogs(): Observable<number> {
    return this.httpClient.get<number>(this.API_URL+"admin/getCountAllBlogsAuthFlagActive");
  }

  getCountAllAuthPendingBlogs(): Observable<number> {
    return this.httpClient.get<number>(this.API_URL+"admin/getCountAllBlogsAuthFlagPending");
  }

  updateUserStatus(status: string, userId: number): Observable<number> {
    return this.httpClient.post<number>(
      this.API_URL+"admin/userStatusUpdation",
      {
        userId: userId,
        status: status,
      },
      httpOptions
      );
  }

  getCountAllBlogsMonthwiseByYear( year: number): Observable<BlogCountMonth[]> {
    return this.httpClient.post<BlogCountMonth[]>(
      this.API_URL+"admin/getCountAllBlogsMonthwiseByYear",
      {
        year: year,
      },
      httpOptions
    );
  }
}
