import { TestBed } from '@angular/core/testing';

import { BloglistingService } from './bloglisting.service';

describe('BloglistingService', () => {
  let service: BloglistingService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BloglistingService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
