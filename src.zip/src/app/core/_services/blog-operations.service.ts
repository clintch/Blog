import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from "rxjs";

const httpOptions = {
  headers: new HttpHeaders({ "Content-Type": "application/json", "Access-Control-Allow-Origin": "*"}),
};

@Injectable({
  providedIn: "root",
})
export class BlogOperationsService {
  url_Post: string = "http://150.1.13.252:8686/";
  url_Comments: string = "https://jsonplaceholder.typicode.com/comments";
  url_Post_Json: string = "https://jsonplaceholder.typicode.com/posts";
  new_URL: string = "https://gorest.co.in/public-api/users";
  constructor(private httpClient: HttpClient) {}

  getblogList(): Observable<any> {
    return this.httpClient.get(this.url_Post_Json, httpOptions);
  }

  getblog(id): Observable<any> {
    return this.httpClient.get(this.url_Post + "/" + id, httpOptions);
  }

  getcomments(postid): Observable<any> {
    return this.httpClient.get(this.url_Comments+"?postId="+postid, httpOptions);
  }
}
