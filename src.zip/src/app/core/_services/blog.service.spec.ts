import { TestBed } from '@angular/core/testing';

import { BlogOperationsService } from './blog.service';

describe('BlogOperationsService', () => {
  let service: BlogOperationsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BlogOperationsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
