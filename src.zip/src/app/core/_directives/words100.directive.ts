import { Directive, Input } from '@angular/core';

@Directive({
  selector: '[words100]'
})
export class Words100Directive {

  @Input() content: string;

  // for (let index = 0; index < array.length; index++) {
  //   const element = array[index];
    
  // }
}
