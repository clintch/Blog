import { Words100Directive } from './words100.directive';

describe('Words100Directive', () => {
  it('should create an instance', () => {
    const directive = new Words100Directive();
    expect(directive).toBeTruthy();
  });
});
