import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'truncateText'
})
export class TruncateTextPipe implements PipeTransform {

  transform(text: string, noofWords:number): string {
    let returnText = '';
    let lengthOfText = text.length;

    for (let i = 0; i <= noofWords; i++) {
      let endIndex = text.indexOf(" ");
      returnText = returnText + text.substring(0, endIndex)+" ";
      let textEndPoint = text.length;
      text = text.substring(endIndex+1, textEndPoint);
    }
    
    return returnText;
  }

}
