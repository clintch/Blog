import { BreakAddingPipe } from './break-adding.pipe';

describe('BreakAddingPipe', () => {
  it('create an instance', () => {
    const pipe = new BreakAddingPipe();
    expect(pipe).toBeTruthy();
  });
});
