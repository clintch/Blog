import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'dateFormat'
})
export class DateFormatPipe implements PipeTransform {

  transform(date: string): string {
    let formattedDate: string;
    let yyyy = date.substring(0, 4);
    let mm= date.substring(6, 8);
    let dd= date.substring(9, 11);
    let month: string;
    if(mm==="01")
      month="January";


    return formattedDate;
  }

}
