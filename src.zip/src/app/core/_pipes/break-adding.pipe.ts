import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'breakAdding'
})
export class BreakAddingPipe implements PipeTransform {

  transform(text: string,noofCharacters: number): string {
    let returnText = '';
    let loopCount = text.length/noofCharacters;
    let length = text.length;
    
    for (let i = 1; i <= loopCount; i++) {
      returnText = returnText + text.substring(0, noofCharacters)+"\n";
	    text = text.substring(noofCharacters, length);
	    length = text.length;
    }
    
    return returnText+text;
  }

}
