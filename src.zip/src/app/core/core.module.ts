import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CookieService } from "ngx-cookie-service";
import {
          AuthGuardService,
          AuthenticateService,
          BloglistingService,
          BlogOperationsService,
          TokenStorageService,
          UserService
} from "./_services";

@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ],
  providers: [
    AuthGuardService,
    AuthenticateService,
    BloglistingService,
    BlogOperationsService,
    TokenStorageService,
    CookieService,
    UserService
  ]
})
export class CoreModule { }
