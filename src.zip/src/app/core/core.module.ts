import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CookieService } from "ngx-cookie-service";
import {
          AuthGuardService,
          AuthenticateService,
          BloglistingService,
          BlogOperationsService,
          TokenStorageService
} from "./_services";

@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ],
  providers: [
    AuthGuardService,
    AuthenticateService,
    BloglistingService,
    BlogOperationsService,
    TokenStorageService,
    CookieService
  ]
})
export class CoreModule { }
