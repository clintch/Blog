import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CookieService } from "ngx-cookie-service";
import {
          AuthGuardService,
          AuthenticateService,
          BloglistingService,
          BlogService,
          TokenStorageService,
          UserService
} from "./_services";
import { PostGuard } from './_guards';
import { Words100Directive } from './_directives/words100.directive';
import { TruncateTextPipe } from './_pipes/truncate-text.pipe';
import { DateFormatPipe } from './_pipes/date-format.pipe';
import { FakeBackendInterceptor } from './_helpers';
import { BreakAddingPipe } from './_pipes/break-adding.pipe';

@NgModule({
  declarations: [Words100Directive, TruncateTextPipe, DateFormatPipe, BreakAddingPipe],
  imports: [
    CommonModule
  ],
  providers: [
    AuthGuardService,
    AuthenticateService,
    BloglistingService,
    BlogService,
    TokenStorageService,
    CookieService,
    UserService,
    PostGuard,
    FakeBackendInterceptor
  ],
  exports: [
    TruncateTextPipe,
    BreakAddingPipe,
  ]
})
export class CoreModule { }
