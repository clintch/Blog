import { District } from './district';

export class Pincode {
    pincode: number;
    district_code: string;
    state_code: string;
    country_code: string;
    districts: Array<District> = new Array();
}
