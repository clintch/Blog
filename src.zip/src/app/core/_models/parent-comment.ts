import { ChildComment } from './child-comment';

export class ParentComment {
    parentId: number;
    blogId: number;
    parentContent: String;
    children: ChildComment[];
}
