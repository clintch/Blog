import { ChildComment } from './child-comment';

export class ParentComment {
    parentId: number;
    blogId: number;
    userId: number;
    parentContent: string;
    // children: ChildComment[] = [];
    children: Array<ChildComment> = new Array();
    // comments: Array<ParentComment> = new Array();
}
