import { UserMaster } from './user-master';

describe('UserMaster', () => {
  it('should create an instance', () => {
    expect(new UserMaster()).toBeTruthy();
  });
});
