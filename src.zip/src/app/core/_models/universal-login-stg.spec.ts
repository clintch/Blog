import { UniversalLoginStg } from './universal-login-stg';

describe('UniversalLoginStg', () => {
  it('should create an instance', () => {
    expect(new UniversalLoginStg()).toBeTruthy();
  });
});
