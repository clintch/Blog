import { ChildComment } from './child-comment';

describe('ChildComment', () => {
  it('should create an instance', () => {
    expect(new ChildComment()).toBeTruthy();
  });
});
