export class Json {
    id: number;
    title: string;
    body: string;
}