import { BlogVideosUrls } from './blog-videos-urls';

describe('BlogVideosUrls', () => {
  it('should create an instance', () => {
    expect(new BlogVideosUrls()).toBeTruthy();
  });
});
