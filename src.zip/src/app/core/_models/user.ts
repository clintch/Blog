export class User {
    userId: number;
    username: string;
    password: string;
    firstName: string;
    lastName: string;
    authdata?: string;
    email: string;
    roles: string[];
    access_token: string;
    type: string;
}