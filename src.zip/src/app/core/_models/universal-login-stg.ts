export class UniversalLoginStg {
    firstName: string; 
    lastName: string; 
	primaryMobile: string;
	primaryEmail: string;
	passwordHash: string;
}
