export class ChildComment {
    childId: number;
    childContent: string;
    parentId: number;
    blogId: number;
    userId: number;
}
