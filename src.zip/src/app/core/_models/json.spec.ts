import { Json } from './json';

describe('Json', () => {
  it('should create an instance', () => {
    expect(new Json()).toBeTruthy();
  });
});
