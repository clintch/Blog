export class UniversalLogin {
    userId: number; 
	primaryMobile: string;
	secondaryMobile: string;
	primaryEmail: string;
	secondaryEmail: string;
	passwordHash: string;
	addDate: string;
	registeredAt: string;
	lastLogin: string;					
	failureCount: number;
    lastPwdChngDt: string;
    status: string;
}
