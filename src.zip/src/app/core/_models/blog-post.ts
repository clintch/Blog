export class BlogPost {
    blogId: number;
	userId: number;
	parentId: number;
	title: string;
	metaTitle: string;
	slug: string;
	summary: string;
	published: number;
    createdAt: string;
	updatedAt: string;
	publishedAt: string;
	replyCount: number;
	likeCount: number;
	viewCount: number;
	status: string;
	authFlag: string;
	authUser: string;
	authDate: string;
	content: string;
}
