import { ParentComment } from './parent-comment';
export class BlogPost {
    blogId: number;
	userId: number;
	firstName: string;
	lastName: string;
	parentId: number;
	title: string;
	metaTitle: string;
	slug: string;
	summary: string;
	published: number;
    createdAt: string;
	updatedAt: string;
	publishedAt: string;
	replyCount: number;
	likeCount: number;
	viewCount: number;
	status: string;
	authFlag: string;
	authUser: string;
	authDate: string;
	content: string;
	// comments: ParentComment[];
	comments: Array<ParentComment> = new Array();
}
