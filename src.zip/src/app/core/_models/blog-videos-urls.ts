export class BlogVideosUrls {
    urlId: number;
    blogId: number;
    url: string;
    addDate: string;
}
