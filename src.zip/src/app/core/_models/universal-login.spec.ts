import { UniversalLogin } from './universal-login';

describe('UniversalLogin', () => {
  it('should create an instance', () => {
    expect(new UniversalLogin()).toBeTruthy();
  });
});
