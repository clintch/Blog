export class Comment {
    blogId: number;
    userId: number;
    content: String;
}
