export class Comment {
    blogId: number;
    userId: number;
    parentId: number;
    content: string;
    reply: string;
}
