export class District {
    district_code: string;
    country_code: string;
    district_name:string;
    state_code: string;
    state_name_caps: string;
    status: string;
}
