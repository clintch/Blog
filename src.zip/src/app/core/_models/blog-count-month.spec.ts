import { BlogCountMonth } from './blog-count-month';

describe('BlogCountMonth', () => {
  it('should create an instance', () => {
    expect(new BlogCountMonth()).toBeTruthy();
  });
});
