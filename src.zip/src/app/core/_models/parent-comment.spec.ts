import { ParentComment } from './parent-comment';

describe('ParentComment', () => {
  it('should create an instance', () => {
    expect(new ParentComment()).toBeTruthy();
  });
});
