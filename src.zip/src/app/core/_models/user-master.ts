export class UserMaster {
    userId: number;
	firstName: string;
	middleName: string;
	lastName: string;
	primaryMobile: string;
	secondaryMobile: string;
	primaryEmail: string;
	secondaryEmail: string;
	Address1: string;
	Address2: string;
	streetName: string;
	stateCode: string;
	districtCode: string;
	pinCode: number;	
	addDate: string;
	intro: string;
	profile: string;
	pauthFlag: string;
	blogCount: number;
	followersCnt: number;
	followingCnt: number;
	status: string;
	contactVerifyFlag: string;
	gender: string;
	professionCode: string;
}
