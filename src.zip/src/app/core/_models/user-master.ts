import { District } from './district';
import { State } from './state';

export class UserMaster {
    userId: number;
	firstName: string;
	middleName: string;
	lastName: string;
	primaryMobile: string;
	secondaryMobile: string;
	primaryEmail: string;
	secondaryEmail: string;
	address1: string;
	address2: string;
	streetName: string;
	stateCode: string;
	districtCode: string;
	pinCode: number;	
	addDate: string;
	intro: string;
	profile: string;
	authFlag: string;
	blogCount: number;
	followersCnt: number;
	followingCnt: number;
	status: string;
	contactVerifyFlag: string;
	gender: string;
	professionCode: string;
	adminRole: string;
	district: District[];
	state: State[];
}
