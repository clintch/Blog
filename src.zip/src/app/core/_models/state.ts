export class State {
    state_code: string;
    country_code: string;
    max_pin_prefix: number;
    min_pin_prefix: number;
    state_name_caps: string;
    state_name_reg: string;
    status: string;
}
