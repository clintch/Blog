export class BlogCountMonth {
    count: number;
    month: number;
}
