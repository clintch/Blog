import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor
} from '@angular/common/http';
import { AuthenticateService } from '../_services';

const TOKEN_HEADER_KEY = "Authorization";

@Injectable()
export class AuthInterceptor implements HttpInterceptor {

  constructor(private authenticateService: AuthenticateService) {}

  intercept(req: HttpRequest<any>, next: HttpHandler) {
    let authReq = req;
    // const token = this.authenticateService.getToken();
    // if (token != null) {
    //   authReq = req.clone({
    //     headers: req.headers.set(TOKEN_HEADER_KEY, "Bearer " + token),
    //   });
    // }
    return next.handle(authReq);
  }

  // intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
  //   return next.handle(request);
  // }
}
