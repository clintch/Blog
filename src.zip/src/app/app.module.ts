import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';

import { SocialLoginModule } from 'angularx-social-login';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { SharedModule } from './Shared';
import { HomeModule } from './Home';
import { BlogModule } from "./Blog";
import { UserModule } from './User';
import { ProfileModule } from "./Profile";
import { MaterialModule } from './core';
import { CoreModule } from "./core";

@NgModule({
  declarations: [
    AppComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    CommonModule,
    BrowserAnimationsModule,
    UserModule,
    SocialLoginModule,
    HttpClientModule,
    HomeModule,
    SharedModule,
    FontAwesomeModule,
    NgbModule,
    ProfileModule,
    BlogModule,
    MaterialModule,
    CoreModule
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
