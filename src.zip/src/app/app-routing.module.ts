import { NgModule } from '@angular/core';
import { Routes, RouterModule, PreloadAllModules } from '@angular/router';


const routes: Routes = [
  {
    path: "home",
    loadChildren: "./Home/#HomeModule",
  },
  {
    path: "signin",
    loadChildren: "./User/#UserModule",
  },
  {
    path: "profile",
    loadChildren: "./Profile/#ProfileModule",
  },
  {
    path: "blog",
    loadChildren: "./Blog/#BlogModule",
  },
  {
    path: "",
    redirectTo: "home",
    pathMatch: "full",
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    preloadingStrategy: PreloadAllModules,
  })
],
  exports: [RouterModule]
})
export class AppRoutingModule { }
