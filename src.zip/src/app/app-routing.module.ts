import { NgModule } from '@angular/core';
import { Routes, RouterModule, PreloadAllModules } from '@angular/router';


const routes: Routes = [
  {
    path: "",
    loadChildren: "./Home/#HomeModule",
  },
  {
    path: "signin",
    loadChildren: "./User/#UserModule",
  },
  {
    path: "profile",
    loadChildren: "./Profile/#ProfileModule",
  },
  {
    path: "blog/:blog",
    loadChildren: "./Blog/#BlogModule",
  },
  {
    path: "admin",
    loadChildren: "./Admin/#AdminModule",
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    preloadingStrategy: PreloadAllModules
  },)
],
  exports: [RouterModule],
})
export class AppRoutingModule { }
