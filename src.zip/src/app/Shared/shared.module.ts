import { MaterialModule } from './../core/_helpers/material.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedRoutingModule } from './shared-routing.module';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { SearchColumnComponent } from './components/search-column/search-column.component';
import { CategoriesWidgetComponent } from './components/categories-widget/categories-widget.component';
import { SideWidgetComponent } from './components/side-widget/side-widget.component';
import { AdColumnComponent } from './components/ad-column/ad-column.component';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';



@NgModule({
  declarations: [
    HeaderComponent,
    FooterComponent,
    SearchColumnComponent,
    CategoriesWidgetComponent,
    SideWidgetComponent,
    AdColumnComponent,
    PageNotFoundComponent
  ],
  imports: [
    CommonModule,
    SharedRoutingModule,
    MaterialModule,
  ],
  exports: [
    CommonModule,
    SharedRoutingModule,
    MaterialModule,
    HeaderComponent,
    FooterComponent,
    SearchColumnComponent,
    CategoriesWidgetComponent,
    SideWidgetComponent,
    AdColumnComponent,
    PageNotFoundComponent,
  ]
})
export class SharedModule { }
