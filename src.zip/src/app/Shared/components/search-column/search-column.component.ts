import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'search-column',
  templateUrl: './search-column.component.html',
  styleUrls: ['./search-column.component.css']
})
export class SearchColumnComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
