import { Component, OnInit, ViewChild } from '@angular/core';
import { SocialAuthService } from 'angularx-social-login';
import { Router } from '@angular/router';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';
import { MatMenuTrigger } from '@angular/material/menu';

@Component({
  selector: 'header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  @ViewChild(MatMenuTrigger) ddTrigger: MatMenuTrigger;

  socialUser: any = null;
  loggedIn: boolean = false;
  isRoleAdmin: boolean = false;
  
  isHandset$: Observable<boolean> = this.breakpointObserver.observe(
    [ 
      Breakpoints.Tablet, 
      Breakpoints.TabletPortrait, 
      Breakpoints.TabletLandscape,
      Breakpoints.Handset,
      Breakpoints.HandsetPortrait,
      Breakpoints.HandsetLandscape,
    ])
    .pipe(
      map(result => result.matches),
      shareReplay()
  );

  constructor(
    private breakpointObserver: BreakpointObserver, 
    private router: Router,  
    private socialAuthService: SocialAuthService
  ) {}


  ngOnInit(): void {
    this.socialAuthService.authState.subscribe((socialUser) => {
      this.socialUser = socialUser;
      this.loggedIn = socialUser != null;
    });
  }

  cancelClick(ev: MouseEvent) {
    ev.stopPropagation();
  }
  profile_name: string ="profileName";
  signin: boolean=false;
  toggle() {
    this.signin = !this.signin;
  }


  logout() {
    this.socialAuthService.signOut();
    window.sessionStorage.clear();
    // window.location.reload();
    this.router.navigate(["/signin"]);
  }

}
