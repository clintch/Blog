import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'categories-widget',
  templateUrl: './categories-widget.component.html',
  styleUrls: ['./categories-widget.component.css']
})
export class CategoriesWidgetComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
