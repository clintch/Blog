import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ad-column',
  templateUrl: './ad-column.component.html',
  styleUrls: ['./ad-column.component.css']
})
export class AdColumnComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
