import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'side-widget',
  templateUrl: './side-widget.component.html',
  styleUrls: ['./side-widget.component.css']
})
export class SideWidgetComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
