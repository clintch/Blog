import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AuthPostsComponent } from './auth-posts.component';

describe('AuthPostsComponent', () => {
  let component: AuthPostsComponent;
  let fixture: ComponentFixture<AuthPostsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AuthPostsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AuthPostsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
