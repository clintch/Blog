import { AfterViewInit, Component, OnInit, ViewChild, Input } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTable } from '@angular/material/table';
import { AuthPostsDataSource } from './auth-posts-datasource';
import { UserMaster, UserService, Json } from 'src/app/core';

@Component({
  selector: 'auth-posts',
  templateUrl: './auth-posts.component.html',
  styleUrls: ['./auth-posts.component.css']
})
export class AuthPostsComponent implements OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatTable) table: MatTable<Json>;
  dataSource: AuthPostsDataSource;

  @Input() userId: number;

  /** Columns displayed in the table. Columns IDs can be added, removed, or reordered. */
  displayedColumns = ['id', 'title', 'body'];
  expandedElement: Json | null;
  constructor(
    private userService: UserService
  ){}
  ngOnInit() {
    this.dataSource = new AuthPostsDataSource(this.userService);
  }

  ngAfterViewInit() {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
    this.table.dataSource = this.dataSource;
  }

  applyFiltering(event: Event) {
    this.dataSource.applyFilter(event);
  }
  

}
