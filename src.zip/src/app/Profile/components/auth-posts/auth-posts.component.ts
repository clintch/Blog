import { Component, OnInit, Input } from '@angular/core';
import { BlogPost, BlogService } from 'src/app/core';
import { Observable } from 'rxjs';
import { Breakpoints, BreakpointObserver } from '@angular/cdk/layout';
import { map, shareReplay } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'auth-posts',
  templateUrl: './auth-posts.component.html',
  styleUrls: ['./auth-posts.component.css']
})
export class AuthPostsComponent implements OnInit {
  @Input() userId: number;
  
  page: number = 1;
  pageSize: number = 5;
  maxSize: number = 5;

  blogList: BlogPost[];

  isHandset$: Observable<boolean> = this.breakpointObserver.observe(
    [ 
      Breakpoints.Handset,
      Breakpoints.HandsetPortrait, 
      Breakpoints.HandsetLandscape,
      Breakpoints.Tablet,
      Breakpoints.TabletPortrait,
      Breakpoints.TabletLandscape
    ])
    .pipe(
      map(result => result.matches),
      shareReplay()
  );
  constructor(
    private breakpointObserver: BreakpointObserver,
    private httpClient: HttpClient,
    private router: Router,
    private blogService: BlogService,
  ) { }

  ngOnInit(): void {
    this.blogService.getBlogListByAuthFlagPending().subscribe(
      (response) => {
        this.blogList = response;
      }
    );
  }

  deleteBlogAuthPendingActive(blogId: number) {
    for (let i = 0; i < this.blogList.length; i++) {
      if(this.blogList[i].blogId === blogId) {
        this.blogList = this.blogList.slice(0, i).concat(this.blogList.slice(i+1, this.blogList.length));
       } 
    }
  }
}
