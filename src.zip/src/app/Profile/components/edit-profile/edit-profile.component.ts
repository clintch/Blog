import { state } from '@angular/animations';
import { map, shareReplay } from 'rxjs/operators';
import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Breakpoints, BreakpointObserver } from '@angular/cdk/layout';
import { TokenStorageService, UserService, UserMaster, Pincode } from 'src/app/core';

@Component({
  selector: 'edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.css']
})
export class EditProfileComponent implements OnInit {
  
  isEmail2 = false;
  isPhone2 = false;
  isMiddle = false;
  isAddress2 = false;
  user =new UserMaster();
  userDetails =new UserMaster();
  loggedUser: any={};

  user_id: number;
  hide = true;
  emailSame=false;
  isSignUpFailed: boolean = false;
  isLoggedIn: boolean = false;
  errorMessage: string="";
  isSuccessful = false;
  district: string="AutoPopulated! with PINCODE";
  state: string="AutoPopulated! with PINCODE";
  checkDetailsUpdated: boolean= false;

  pinCodeDetail: Pincode[];
  
  constructor(
    private breakpointObserver: BreakpointObserver,
    private tokenStorageService:  TokenStorageService,
    private userService: UserService,
  ) {}
  isHandset$: Observable<boolean> = this.breakpointObserver.observe(
    [ 
      Breakpoints.Handset,
      Breakpoints.HandsetPortrait, 
      Breakpoints.HandsetLandscape,
      Breakpoints.Tablet,
      Breakpoints.TabletPortrait,
      Breakpoints.TabletLandscape
    ])
    .pipe(
      map(result => result.matches),
      shareReplay()
  );
  ngOnInit(): void {
    // getUserDetailsById
    // isLoggedIn: boolean = false;
    // user_id: number;
    this.isLoggedIn = !!this.tokenStorageService.getToken();

    if (this.isLoggedIn) {
      this.loggedUser = this.tokenStorageService.getUser();
      this.user_id = this.loggedUser.userDetails[0].userId;
    }

    this.userService.getUserDetailsById(this.user_id).subscribe(
      (response) => {
        this.userDetails = response;
        console.log(response);
      }
    )
  }
  onSubmit() {
      this.userService.updateUserDetails(this.userDetails).subscribe(
      (response) => {
        this.checkDetailsUpdated = response;
      }
    )
  }
    checkEmail() {
      alert("Email is available");
    }

    getValue(event) {
      
    }
    reload() {
      window.location.reload();
    }

    pinCodeDetails(pinCode: number) {
      this.userService.pinCodeDetails(pinCode).subscribe(
        (response) => {
          this.pinCodeDetail =response;
          this.userDetails.districtCode = this.pinCodeDetail[0].districts[0].district_name;
          this.userDetails.stateCode = this.pinCodeDetail[0].districts[0].state_name_caps;
        }
      )
    }
}
