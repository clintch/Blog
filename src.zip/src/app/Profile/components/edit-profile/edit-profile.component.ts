import { map, shareReplay } from 'rxjs/operators';
import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Breakpoints, BreakpointObserver } from '@angular/cdk/layout';

@Component({
  selector: 'edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.css']
})
export class EditProfileComponent implements OnInit {
  
  isEmail2 = false;
  isPhone2 = false;
  isMiddle = false;
  isAddress2 = false;
  user: any = {};
  hide = true;
  emailSame=false;
  isSignUpFailed: boolean = false;
  errorMessage: string="";
  isSuccessful = false;
  district: string="AutoPopulated! with PINCODE";
  state: string="AutoPopulated! with PINCODE";
  
  constructor(
    private breakpointObserver: BreakpointObserver,
  ) {}
  
  isHandset$: Observable<boolean> = this.breakpointObserver.observe(
    [ 
      Breakpoints.TabletPortrait, 
      Breakpoints.TabletLandscape,
      Breakpoints.HandsetLandscape,
      Breakpoints.HandsetPortrait,
    ])
    .pipe(
      map(result => result.matches),
      shareReplay()
  );
  ngOnInit(): void {
  }
  submit() {
    alert('Thanks!');
    }
    checkEmail() {
      alert("Email is available");
    }

    getValue(event) {
      
    }
 

}
