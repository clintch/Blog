import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dashboard-editProfile',
  templateUrl: './dashboard-edit-profile.component.html',
  styleUrls: ['./dashboard-edit-profile.component.css']
})
export class DashboardEditProfileComponent implements OnInit {
  
  isEmail2 = false;
  isPhone2 = false;
  isMiddle = false;
  isAddress2 = false;
  user: any = {};
  hide = true;
  emailSame=false;
  isSignUpFailed: boolean = false;
  errorMessage: string="";
  isSuccessful = false;
  district: string="AutoPopulated! with PINCODE";
  state: string="AutoPopulated! with PINCODE";
  
  constructor() {}
  ngOnInit(): void {
  }
  submit() {
    alert('Thanks!');
    }
    checkEmail() {
      alert("Email is available");
    }

    getValue(event) {
      
    }
 

}
