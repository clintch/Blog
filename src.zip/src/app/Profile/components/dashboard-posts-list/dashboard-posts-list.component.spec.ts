import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardPostsListComponent } from './dashboard-posts-list.component';

describe('DashboardPostsListComponent', () => {
  let component: DashboardPostsListComponent;
  let fixture: ComponentFixture<DashboardPostsListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DashboardPostsListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardPostsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
