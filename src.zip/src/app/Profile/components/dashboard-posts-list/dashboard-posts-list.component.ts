import { Component, OnInit, ViewChild} from '@angular/core';
import { UserService } from 'src/app/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';


@Component({
  selector: 'dashboard-postsList',
  templateUrl: './dashboard-posts-list.component.html',
  styleUrls: ['./dashboard-posts-list.component.css']
})
export class DashboardPostsListComponent implements OnInit {

  blogList: MatTableDataSource<any>;
  displayedColumns: string[] = ['id', 'title', 'body', 'options'];

  @ViewChild(MatSort, null) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  
  constructor(
    private userService: UserService
  ) { }

  ngOnInit(): void {
    this.userService.getBlogList("1").subscribe(
      (response) => {
        this.blogList = new MatTableDataSource(response);
        this.blogList.sort = this.sort;
        this.blogList.paginator = this.paginator;
      }
    )
  }

  onDelete(row: number) {
    alert("Row: "+row);
  }

}
