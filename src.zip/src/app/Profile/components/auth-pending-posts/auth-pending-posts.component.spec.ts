import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AuthPendingPostsComponent } from './auth-pending-posts.component';

describe('AuthPendingPostsComponent', () => {
  let component: AuthPendingPostsComponent;
  let fixture: ComponentFixture<AuthPendingPostsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AuthPendingPostsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AuthPendingPostsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
