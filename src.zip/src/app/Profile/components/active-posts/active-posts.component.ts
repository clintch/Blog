import { AfterViewInit, Component, OnInit, ViewChild, Input, Output, EventEmitter } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTable } from '@angular/material/table';
import { ActivePostsDataSource } from './active-posts-datasource';
import { UserMaster, UserService, Json, BlogService, BlogPost } from 'src/app/core';

@Component({
  selector: 'active-posts',
  templateUrl: './active-posts.component.html',
  styleUrls: ['./active-posts.component.css']
})
export class ActivePostsComponent implements OnInit {
  // @ViewChild(MatPaginator) paginator: MatPaginator;
  // @ViewChild(MatSort) sort: MatSort;
  // @ViewChild(MatTable) table: MatTable<Json>;

  @Input() userId: number;
  @Input() privateActiveBlogId: number;

  @Output() activePrivate = new EventEmitter<number>();

  page: number = 1;
  pageSize: number = 5;
  maxSize: number = 5;

  blogList: BlogPost[];

  // dataSource: ActivePostsDataSource;

  /** Columns displayed in the table. Columns IDs can be added, removed, or reordered. */
  // displayedColumns = ['id', 'title', 'body'];
  // expandedElement: Json | null;
  constructor(
    private blogService: BlogService
  ){}

  ngOnInit() {
    // this.dataSource = new ActivePostsDataSource(this.userService);
    this.blogService.getBlogListByStatus(this.userId, "A").subscribe(
      (response) => {
        this.blogList = response;
      }
    );
    console.log("privateActiveBlogId: "+this.privateActiveBlogId);
  }

  updatePrivateActiveBlog() {
    console.log("privateActiveBlogId: "+this.privateActiveBlogId);
    this.blogService.getBlogByBlogId(this.privateActiveBlogId).subscribe(
      (response) => {
        this.blogList.unshift(response);
      }
    );
  }

  deleteBlogActivePrivate(blogId: number) {
    for (let i = 0; i < this.blogList.length; i++) {
      if(this.blogList[i].blogId === blogId) {
        this.blogList = this.blogList.slice(0, i).concat(this.blogList.slice(i+1, this.blogList.length));
        this.activePrivate.emit(blogId);
      } 
    }
  }

  // ngAfterViewInit() {
  //   this.dataSource.sort = this.sort;
  //   this.dataSource.paginator = this.paginator;
  //   this.table.dataSource = this.dataSource;
  // }

  // applyFiltering(event: Event) {
  //   this.dataSource.applyFilter(event);
  // }
  

}
