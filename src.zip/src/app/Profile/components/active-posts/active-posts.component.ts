import { AfterViewInit, Component, OnInit, ViewChild, Input } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTable } from '@angular/material/table';
import { ActivePostsDataSource } from './active-posts-datasource';
import { UserMaster, UserService, Json, BlogService, BlogPost } from 'src/app/core';

@Component({
  selector: 'active-posts',
  templateUrl: './active-posts.component.html',
  styleUrls: ['./active-posts.component.css']
})
export class ActivePostsComponent implements OnInit {
  // @ViewChild(MatPaginator) paginator: MatPaginator;
  // @ViewChild(MatSort) sort: MatSort;
  // @ViewChild(MatTable) table: MatTable<Json>;

  @Input() userId: number;
  page: number = 1;
  pageSize: number = 5;
  maxSize: number = 5;

  blogList: BlogPost[];
  userid:number = 1;

  // dataSource: ActivePostsDataSource;

  /** Columns displayed in the table. Columns IDs can be added, removed, or reordered. */
  // displayedColumns = ['id', 'title', 'body'];
  // expandedElement: Json | null;
  constructor(
    private userService: UserService,
    private blogService: BlogService
  ){}
  ngOnInit() {
    // this.dataSource = new ActivePostsDataSource(this.userService);
    this.blogService.getActiveUserBlogList(this.userid).subscribe(
      (response) => {
        this.blogList = response;
      }
    );
  }

  // ngAfterViewInit() {
  //   this.dataSource.sort = this.sort;
  //   this.dataSource.paginator = this.paginator;
  //   this.table.dataSource = this.dataSource;
  // }

  // applyFiltering(event: Event) {
  //   this.dataSource.applyFilter(event);
  // }
  

}
