import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dashboard-authPosts',
  templateUrl: './dashboard-auth-posts.component.html',
  styleUrls: ['./dashboard-auth-posts.component.css']
})
export class DashboardAuthPostsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
