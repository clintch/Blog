import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardAuthPostsComponent } from './dashboard-auth-posts.component';

describe('DashboardAuthPostsComponent', () => {
  let component: DashboardAuthPostsComponent;
  let fixture: ComponentFixture<DashboardAuthPostsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DashboardAuthPostsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardAuthPostsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
