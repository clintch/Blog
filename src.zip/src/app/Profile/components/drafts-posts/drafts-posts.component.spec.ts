import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DraftsPostsComponent } from './drafts-posts.component';

describe('DraftsPostsComponent', () => {
  let component: DraftsPostsComponent;
  let fixture: ComponentFixture<DraftsPostsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DraftsPostsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DraftsPostsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
