import { Router } from '@angular/router';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Component, OnInit, Input, ɵConsole } from '@angular/core';
import { Observable } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { BlogService, BlogPost } from 'src/app/core';

@Component({
  selector: 'drafts-posts',
  templateUrl: './drafts-posts.component.html',
  styleUrls: ['./drafts-posts.component.css']
})
export class DraftsPostsComponent implements OnInit {

  @Input() userId: number;
  
  
  page: number = 1;
  pageSize: number = 5;
  maxSize: number = 5;

  blogList: BlogPost[];

  isHandset$: Observable<boolean> = this.breakpointObserver.observe(
    [ 
      Breakpoints.Handset,
      Breakpoints.HandsetPortrait, 
      Breakpoints.HandsetLandscape,
      Breakpoints.Tablet,
      Breakpoints.TabletPortrait,
      Breakpoints.TabletLandscape
    ])
    .pipe(
      map(result => result.matches),
      shareReplay()
  );
  constructor(
    private breakpointObserver: BreakpointObserver,
    private httpClient: HttpClient,
    private router: Router,
    private blogService: BlogService,
  ) { }

  ngOnInit(): void {
    this.blogService.getBlogListByStatus(this.userId, "D").subscribe(
      (response) => {
        this.blogList = response;
        console.log(response);
      }
    );
  }

  deleteBlogDraftActive(blogId: number) {
    for (let i = 0; i < this.blogList.length; i++) {
      if(this.blogList[i].blogId === blogId) {
        this.blogList = this.blogList.slice(0, i).concat(this.blogList.slice(i+1, this.blogList.length));
      } 
    }
  }
}
