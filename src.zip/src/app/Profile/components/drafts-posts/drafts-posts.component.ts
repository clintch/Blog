import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'drafts-posts',
  templateUrl: './drafts-posts.component.html',
  styleUrls: ['./drafts-posts.component.css']
})
export class DraftsPostsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
