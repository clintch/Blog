import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router, ActivatedRouteSnapshot, NavigationEnd } from '@angular/router';
import { UserService, TokenStorageService, BlogService, BlogPost } from 'src/app/core';
import { UserMaster } from 'src/app/core';
import { Observable } from 'rxjs';
import { Breakpoints, BreakpointObserver } from '@angular/cdk/layout';
import { map, shareReplay } from 'rxjs/operators';
import { Location } from "@angular/common";
import { PrivatePostsComponent } from '../private-posts';
import { ActivePostsComponent } from '../active-posts';

@Component({
  selector: 'profile-page',
  templateUrl: './profile-page.component.html',
  styleUrls: ['./profile-page.component.css']
})
export class ProfilePageComponent{

  privateActiveBlogId: number;
  activePrivateBlogId: number;

  user =new UserMaster();
  blogPost: BlogPost;

  loggedUser: any={};
  user_id: number;
  isLoggedIn: boolean = false;

  isHandset$: Observable<boolean> = this.breakpointObserver.observe(
    [ 
      Breakpoints.Handset,
      Breakpoints.HandsetPortrait, 
      Breakpoints.HandsetLandscape,
      Breakpoints.Tablet,
      Breakpoints.TabletPortrait,
      Breakpoints.TabletLandscape
    ])
    .pipe(
      map(result => result.matches),
      shareReplay()
  );
  constructor(
    private activatedRoute: ActivatedRoute,
    private userService: UserService,
    private breakpointObserver: BreakpointObserver,
    private router: Router,
    private location: Location,
    private tokenStorageService: TokenStorageService,
    private blogService: BlogService
    // private activatedSnapRoute: ActivatedRouteSnapshot

  ) {}

  ngOnInit(): void {
    this.isLoggedIn = !!this.tokenStorageService.getToken();

    if (this.isLoggedIn) {
      this.loggedUser = this.tokenStorageService.getUser();
      this.user_id = this.loggedUser.userDetails[0].userId;
    }

    // this.userService.getUserDetailsById(this.user_id).subscribe(
    //   (response) => {
    //     this.userDetails = response;
    //     console.log(response);
    //   },
    //   (errors) => {
    //     console.log("UserDetails Api Call Errror: "+errors);
    //   }
    // )
    // this.router.navigateByUrl("/dummy", {skipLocationChange:true}).then(
    //   () => {
    //     this.router.navigate(["/profile"]);
    //   }
    // );
  }

  ngAfterViewIit() {
    // this.blogService.getBlogByBlogId(this.privateActiveBlogId).subscribe(
    //   (response) => {
    //     this.blogPost = response;
    //     console.log(response);
    //     this.activePostsRef.blogList.unshift(this.blogPost);
    //   }
    // );

    // this.blogService.getBlogByBlogId(this.activePrivateBlogId).subscribe(
    //   (response) => {
    //     this.blogPost = response;
    //     console.log(response);
    //     this.privatePostsRef.blogList.unshift(this.blogPost);
    //   }
    // );
    // // this.activePostsRef.blogList = 
  }
  getPrivateActiveBlogId(blogId: number) {
    this.privateActiveBlogId = blogId;
    console.log("privateActiveBlogId in profile: "+this.privateActiveBlogId);
  }

  getActivePrivateBlogId(blogId: number) {
    this.activePrivateBlogId = blogId;
  }
}
