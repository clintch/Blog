import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, ActivatedRouteSnapshot } from '@angular/router';
import { UserService } from 'src/app/core';
import { UserMaster } from 'src/app/core';
import { Observable } from 'rxjs';
import { Breakpoints, BreakpointObserver } from '@angular/cdk/layout';
import { map, shareReplay } from 'rxjs/operators';
import { Location } from "@angular/common";

@Component({
  selector: 'profile-page',
  templateUrl: './profile-page.component.html',
  styleUrls: ['./profile-page.component.css']
})
export class ProfilePageComponent implements OnInit {

  user: UserMaster;
  userId: number;

  isHandset$: Observable<boolean> = this.breakpointObserver.observe(
    [ 
      Breakpoints.Handset,
      Breakpoints.HandsetPortrait, 
      Breakpoints.HandsetLandscape,
      Breakpoints.Tablet,
      Breakpoints.TabletPortrait,
      Breakpoints.TabletLandscape
    ])
    .pipe(
      map(result => result.matches),
      shareReplay()
  );
  constructor(
    private activatedRoute: ActivatedRoute,
    private userService: UserService,
    private breakpointObserver: BreakpointObserver,
    private router: Router,
    private location: Location,
    // private activatedSnapRoute: ActivatedRouteSnapshot

  ) {

   }

  ngOnInit(): void {
    console.log("ProfilePage");
    this.userId = Number(this.activatedRoute.snapshot.paramMap.get('id'));
    this.userService.getUserDetailsById(this.userId).subscribe(
      (response) => {
        this.user = response;
      },
      (errors) => {
        console.log("UserDetails Api Call Errror: "+errors);
      }
    );
    // this.router.navigateByUrl("/dummy", {skipLocationChange:true}).then(
    //   () => {
    //     this.router.navigate(["/profile"]);
    //   }
    // );
  }

}
