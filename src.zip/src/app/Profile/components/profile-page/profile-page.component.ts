import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { UserService } from 'src/app/core';
import { UserMaster } from 'src/app/core';

@Component({
  selector: 'profile-page',
  templateUrl: './profile-page.component.html',
  styleUrls: ['./profile-page.component.css']
})
export class ProfilePageComponent implements OnInit {

  user: UserMaster;
  userId: number;
  constructor(
    private activatedRoute: ActivatedRoute,
    private userService: UserService,

  ) { }

  ngOnInit(): void {
    // this.userId = Number(this.activatedRoute.snapshot.paramMap.get('id'));
    // this.userService.getUserDetailsById(this.userId).subscribe(
    //   (response) => {
    //     this.user = response;
    //   },
    //   (errors) => {
    //     console.log("UserDetails Api Call Errror: "+errors);
    //   }
    // )
  }

}
