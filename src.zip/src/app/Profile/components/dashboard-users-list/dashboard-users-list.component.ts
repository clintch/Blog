import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTable } from '@angular/material/table';
import { DashboardUsersListDataSource } from './dashboard-users-list-datasource';
import { UserMaster, UserService, Json } from 'src/app/core';
@Component({
  selector: 'users-list',
  templateUrl: './dashboard-users-list.component.html',
  styleUrls: ['./dashboard-users-list.component.css'],
})
export class DashboardUsersListComponent implements AfterViewInit, OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatTable) table: MatTable<Json>;
  dataSource: DashboardUsersListDataSource;

  /** Columns displayed in the table. Columns IDs can be added, removed, or reordered. */
  displayedColumns = ['id', 'name', 'body'];
  constructor(
    private userService: UserService
  ){}
  ngOnInit() {
    this.dataSource = new DashboardUsersListDataSource(this.userService);
  }

  ngAfterViewInit() {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
    this.table.dataSource = this.dataSource;
  }

  applyFiltering(event: Event) {
    this.dataSource.applyFilter(event);
  }
}
