import { Component, OnInit } from '@angular/core';
import { MatChipInputEvent } from '@angular/material/chips';
import {COMMA, ENTER} from '@angular/cdk/keycodes';
import { map, shareReplay } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { Breakpoints, BreakpointObserver } from '@angular/cdk/layout';
import { HttpEventType, HttpResponse } from '@angular/common/http';
import { UserService, BlogPost } from 'src/app/core';

export interface Url {
  address: string;
}
@Component({
  selector: 'new-post',
  templateUrl: './new-post.component.html',
  styleUrls: ['./new-post.component.css']
})
export class NewPostComponent{

  isEmail2 = false;
  isPhone2 = false;
  isMiddle = false;
  isAddress2 = false;
  
  constructor(
    private breakpointObserver: BreakpointObserver,
    private userService: UserService,
    ) {}
  blog: BlogPost;
  hide = true;
  emailSame=false;
  isSignUpFailed: boolean = false;
  errorMessage: string="";
  isSuccessful = false;
  titleRemainingSize: number= 0;
  subtitleRemainingSize: number=0;
  slugRemainingSize: number=0;
  checkSubtitleSize: boolean = false;
  checkTitleSize: boolean = false;
  checkSlugSize: boolean = false;
  slugTitle: string='';

  //Chips
  visible = true;
  selectable = true;
  removable = true;
  addOnBlur = true;
  readonly separatorKeysCodes: number[] = [ENTER, COMMA];
  urls: Url[] = [];
  youtubeUrl: string = '';

  //Upload
  progress: number =0;
  valueZero: boolean =true;
  selectedFiles: FileList;
  currentFile: File;
  message: string;

  isHandset$: Observable<boolean> = this.breakpointObserver.observe(
    [ 
      Breakpoints.Handset,
      Breakpoints.HandsetPortrait, 
      Breakpoints.HandsetLandscape,
      Breakpoints.Tablet,
      Breakpoints.TabletPortrait,
      Breakpoints.TabletLandscape
    ])
    .pipe(
      map(result => result.matches),
      shareReplay()
  );

  add(event: MatChipInputEvent): void {
    const input = event.input;
    const value = event.value;
    // Add each url
    if ((value || '').trim()) {
      this.urls.push({address: value.trim()});
    }
    // Reset the input value
    if (input) {
      input.value = '';
    }
  }

  remove(url: Url): void {
    const index = this.urls.indexOf(url);
    if (index >= 0) {
      this.urls.splice(index, 1);
    }
  }
  submit() {
    alert('Thanks!');
  }

  checkEmail() {
    alert("Email is available");
  }

  getValue(event) {
    
  }

  getSubtitleLength(str) {
      this.checkSubtitleSize = true;
      let strValue = new String(str);
      let len: number = strValue.length;
      this.subtitleRemainingSize = 100 - len;
      if(this.subtitleRemainingSize == 0) {
        this.checkSubtitleSize = false;
      }  
  }

  getTitleLength(str) {
    this.checkTitleSize = true;
    let strValue = new String(str);
    let len: number = strValue.length;
    this.titleRemainingSize = 70 - len;
    if(this.titleRemainingSize == 0) {
      this.checkTitleSize = false;
    }  
  }

  getSlugLength(str) {
    this.checkSlugSize = true;
    let strValue = new String(str);
    let len: number = strValue.length;
    this.slugRemainingSize = 100 - len;
    if(this.slugRemainingSize == 0) {
      this.checkSlugSize = false;
    }  
}

  createSlug(str) {
    console.log("String: "+str);
    this.checkTitleSize = true;
    let strValue = new String(str);
    let len: number = strValue.length;
    this.slugTitle = this.transform(str);  
  }
  transform(str: string): string {
    return this.isString(str)
    ? str.toLowerCase().trim()
      .replace(/[^\w\-]+/g, ' ')
      .replace(/\s+/g, '-')
    : str;
  }
  isString(value: any) {
    return typeof value === 'string';
  }

  //upload

  selectFile(event) {
    this.selectedFiles = event.target.files;
  }

  upload() {
    this.progress = 0;

    this.currentFile = this.selectedFiles.item(0);
    this.userService.upload(this.currentFile).subscribe(
      event => {
        if (event.type === HttpEventType.UploadProgress) {
          this.progress = Math.round(100 * event.loaded / event.total);
        } else if (event instanceof HttpResponse) {
          this.message = event.body.message;
        }
      },
      err => {
        this.progress = 0;
        this.message = 'Could not upload the file!';
        this.currentFile = undefined;
      });

    this.selectedFiles = undefined;
  }
}
