import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dashboard-newPost',
  templateUrl: './dashboard-new-post.component.html',
  styleUrls: ['./dashboard-new-post.component.css']
})
export class DashboardNewPostComponent{

  isEmail2 = false;
  isPhone2 = false;
  isMiddle = false;
  isAddress2 = false;

  constructor(
  ) {}
  blog: any = {};
  hide = true;
  emailSame=false;
  isSignUpFailed: boolean = false;
  errorMessage: string="";
  isSuccessful = false;
  titleRemainingSize: number= 0;
  subtitleRemainingSize: number=0;
  slugRemainingSize: number=0;
  checkSubtitleSize: boolean = false;
  checkTitleSize: boolean = false;
  checkSlugSize: boolean = false;
  slugTitle: string='';

  submit() {
    alert('Thanks!');
    }
    checkEmail() {
      alert("Email is available");
    }

    getValue(event) {
      
    }

    getSubtitleLength(str) {
        this.checkSubtitleSize = true;
        let strValue = new String(str);
        let len: number = strValue.length;
        this.subtitleRemainingSize = 100 - len;
        if(this.subtitleRemainingSize == 0) {
          this.checkSubtitleSize = false;
        }  
    }

    getTitleLength(str) {
      this.checkTitleSize = true;
      let strValue = new String(str);
      let len: number = strValue.length;
      this.titleRemainingSize = 70 - len;
      if(this.titleRemainingSize == 0) {
        this.checkTitleSize = false;
      }  
  }

  getSlugLength(str) {
    this.checkSlugSize = true;
    let strValue = new String(str);
    let len: number = strValue.length;
    this.slugRemainingSize = 100 - len;
    if(this.slugRemainingSize == 0) {
      this.checkSlugSize = false;
    }  
}

  createSlug(str) {
    console.log("String: "+str);
    this.checkTitleSize = true;
    let strValue = new String(str);
    let len: number = strValue.length;
    this.slugTitle = this.transform(str);  
  }
  transform(str: string): string {
    return this.isString(str)
    ? str.toLowerCase().trim()
      .replace(/[^\w\-]+/g, ' ')
      .replace(/\s+/g, '-')
    : str;
  }
  isString(value: any) {
    return typeof value === 'string';
  }
}
