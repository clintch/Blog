import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardNewPostComponent } from './dashboard-new-post.component';

describe('DashboardNewPostComponent', () => {
  let component: DashboardNewPostComponent;
  let fixture: ComponentFixture<DashboardNewPostComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DashboardNewPostComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardNewPostComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
