import { AfterViewInit, Component, OnInit, ViewChild, Input } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTable } from '@angular/material/table';
import { PrivatePostsDataSource } from './private-posts-datasource';
import { UserMaster, UserService, Json, BlogService, BlogPost } from 'src/app/core';

@Component({
  selector: 'private-posts',
  templateUrl: './private-posts.component.html',
  styleUrls: ['./private-posts.component.css']
})
export class PrivatePostsComponent implements OnInit {
  // @ViewChild(MatPaginator) paginator: MatPaginator;
  // @ViewChild(MatSort) sort: MatSort;
  // @ViewChild(MatTable) table: MatTable<Json>;
  // dataSource: PrivatePostsDataSource;

  @Input() userId: number;
  userid:number = 1;
  blogList: BlogPost[];

  page: number = 1;
  pageSize: number = 5;
  maxSize: number = 5;
  /** Columns displayed in the table. Columns IDs can be added, removed, or reordered. */
  // displayedColumns = ['id', 'title', 'body'];
  // expandedElement: Json | null;
  constructor(
    private userService: UserService,
    private blogService: BlogService
  ){}
  ngOnInit() {
    // this.dataSource = new PrivatePostsDataSource(this.userService);
    this.blogService.getPrivateUserBlogList(this.userid).subscribe(
      (response) => {
        this.blogList = response;
      }
    );
  }

  // ngAfterViewInit() {
  //   this.dataSource.sort = this.sort;
  //   this.dataSource.paginator = this.paginator;
  //   this.table.dataSource = this.dataSource;
  // }

  // applyFiltering(event: Event) {
  //   this.dataSource.applyFilter(event);
  // }
  

}
