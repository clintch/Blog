import { AfterViewInit, Component, OnInit, ViewChild, Input, Output, EventEmitter } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTable } from '@angular/material/table';
import { PrivatePostsDataSource } from './private-posts-datasource';
import { UserMaster, UserService, Json, BlogService, BlogPost } from 'src/app/core';

@Component({
  selector: 'private-posts',
  templateUrl: './private-posts.component.html',
  styleUrls: ['./private-posts.component.css']
})
export class PrivatePostsComponent implements OnInit {
  // @ViewChild(MatPaginator) paginator: MatPaginator;
  // @ViewChild(MatSort) sort: MatSort;
  // @ViewChild(MatTable) table: MatTable<Json>;
  // dataSource: PrivatePostsDataSource;

  @Input() userId: number;
  @Output() privateActive = new EventEmitter<number>();

  blogList: BlogPost[];

  page: number = 1;
  pageSize: number = 5;
  maxSize: number = 5;
  /** Columns displayed in the table. Columns IDs can be added, removed, or reordered. */
  // displayedColumns = ['id', 'title', 'body'];
  // expandedElement: Json | null;
  constructor(
    private blogService: BlogService
  ){}
  ngOnInit() {
    // this.dataSource = new PrivatePostsDataSource(this.userService);
    this.blogService.getBlogListByStatus(this.userId, "P").subscribe(
      (response) => {
        this.blogList = response;
      }
    );
  }


  deleteBlogPrivateActive(blogId: number) {
    for (let i = 0; i < this.blogList.length; i++) {
      if(this.blogList[i].blogId === blogId) {
        this.blogList = this.blogList.slice(0, i).concat(this.blogList.slice(i+1, this.blogList.length));
        this.privateActive.emit(blogId);
       } 
    }
    window.location.reload();
  }
  // ngAfterViewInit() {
  //   this.dataSource.sort = this.sort;
  //   this.dataSource.paginator = this.paginator;
  //   this.table.dataSource = this.dataSource;
  // }

  // applyFiltering(event: Event) {
  //   this.dataSource.applyFilter(event);
  // }
  

}
