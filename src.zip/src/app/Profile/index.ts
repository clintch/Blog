export * from './profile.module';
export * from './components/profile-page';
export * from './components/dashboard';
export * from './components/dashboard-edit-profile';
export * from './components/dashboard-new-post';
export * from './components/dashboard-posts-list';
// export * from './components/dashboard-users-list';
// export * from './components/dashboard-draftsS';
export * from './components/dashboard-auth-posts';
// export * from './components/dashboard-drafts';

export * from './components/dashboard-drafts';
export * from './components/dashboard-users-list';