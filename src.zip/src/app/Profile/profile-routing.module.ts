
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
// import { EditProfileComponent } from './components/edit-profile';
// import { ProfilePageComponent } from './components/profile-page';
// import { NewPostComponent } from './components/new-post';
// import { AuthPostsComponent } from './components/auth-posts';
// import { UsersListComponent } from './components/users-list';
// import { ActivePostsComponent } from './components/active-posts';
// import { PrivatePostsComponent } from './components/private-posts';

//New==============================
import { ProfilePageComponent } from './components/profile-page';
import { ActivePostsComponent } from './components/active-posts';
import { AuthPendingPostsComponent } from './components/auth-pending-posts';
import { PrivatePostsComponent } from './components/private-posts';
import { EditProfileComponent } from './components/edit-profile';
import { UsersListComponent } from './components/users-list';
import { DraftsPostsComponent } from './components/drafts-posts';
import { NewPostComponent } from './components/new-post';
import { AuthPostsComponent } from './components/auth-posts';
import { PageNotFoundComponent } from '../Shared';
import { DummyComponent } from './components/dummy';


const routes: Routes = [
    // {
    //   path: "",
    //   component: ProfilePageComponent,
    //   children: [
    //     {
    //       path: "active-posts",
    //       component: ActivePostsComponent
    //     },
    //     {
    //       path: "private-posts",
    //       component: PrivatePostsComponent
    //     }
    //   ]
    // },
    // {
    //   path: "edit-profile",
    //   component: EditProfileComponent
    // },
    // {
    //   path: "new-post",
    //   component: NewPostComponent
    // },
    // {
    //   path: "draft-posts",
    //   component: DraftPostsComponent
    // },
    // {
    //   path: "auth-posts",
    //   component: AuthPostsComponent
    // },
    // {
    //   path: "users-list",
    //   component: UsersListComponent
    // }
    {
      path: "",
      component: ProfilePageComponent,
      children: [
        {
          path: "active-posts",
          component: ActivePostsComponent,
        },
        {
          path: "auth-pending-posts",
          component: AuthPendingPostsComponent,
        },
        {
          path: "private-posts",
          component: PrivatePostsComponent,
        },
        
      ],
      
    },
    {
      path: "edit-profile",
      component: EditProfileComponent
    },
    {
      path: "new-post",
      component: NewPostComponent
    },
    {
      path: "draft-posts",
      component: DraftsPostsComponent
    },
    {
      path: "auth-posts",
      component: AuthPostsComponent
    },
    {
      path: "users-list",
      component: UsersListComponent
    },
    {
      path: "dummy",
      component: DummyComponent
    },
    // { 
    //   path: '**',
    //   component: PageNotFoundComponent
    // }

    
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProfileRoutingModule { }
