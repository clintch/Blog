import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './components/dashboard';
import { DashboardEditProfileComponent } from './components/dashboard-edit-profile';
import { DashboardNewPostComponent } from './components/dashboard-new-post';
import { DashboardPostsListComponent } from './components/dashboard-posts-list';
import { DashboardAuthPostsComponent } from './components/dashboard-auth-posts';
import { ProfilePageComponent } from './components/profile-page';
import { DashboardUsersListComponent } from './components/dashboard-users-list';
import { DashboardDraftsComponent } from "./components/dashboard-drafts";
// import { DashboardUsersListComponent } from './components/dashboard-users-list';
// import { DashboardDraftsComponent } from './components/dashboard-drafts';


const routes: Routes = [
    {
      path: "",
      component: ProfilePageComponent,
    },
    {
      path: "edit-profile",
      component: DashboardEditProfileComponent
    },
    {
      path: "new-post",
      component: DashboardNewPostComponent
    },
    {
      path: "drafts",
      component: DashboardDraftsComponent
    },
    {
      path: "posts-list",
      component: DashboardPostsListComponent
    },
    {
      path: "auth-posts",
      component: DashboardAuthPostsComponent
    },
    {
      path: "users-list",
      component: DashboardUsersListComponent
    }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProfileRoutingModule { }
