import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialModule } from './../core/_helpers/material.module';
import { ProfileRoutingModule } from './profile-routing.module';


// import { ProfilePageComponent } from './components/profile-page/profile-page.component';
import { FormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
// import { PrivatePostsComponent } from './components/private-posts/private-posts.component';
// import { AuthPostsComponent } from './components/auth-posts/auth-posts.component';
// import { ActivePostsComponent } from './components/active-posts/active-posts.component';
// import { AuthPendingPostsComponent } from './components/auth-pending-posts/auth-pending-posts.component';
import { MatFormFieldModule } from '@angular/material/form-field';
//New-----------

import { ProfilePageComponent } from './components/profile-page';
import { ActivePostsComponent } from './components/active-posts/active-posts.component';
import { AuthPendingPostsComponent } from './components/auth-pending-posts/auth-pending-posts.component';
import { PrivatePostsComponent } from './components/private-posts/private-posts.component';
import { EditProfileComponent } from './components/edit-profile';
import { UsersListComponent } from './components/users-list';
import { DraftsPostsComponent } from './components/drafts-posts';
import { NewPostComponent } from './components/new-post';
import { AuthPostsComponent } from './components/auth-posts/auth-posts.component';
import { BlogModule } from '../Blog';
import { NgbPaginationModule } from '@ng-bootstrap/ng-bootstrap';
import { DummyComponent } from './components/dummy/dummy.component';



@NgModule({
  declarations: [
    // ProfilePageComponent,
    // PrivatePostsComponent,
    // AuthPostsComponent,
    // ActivePostsComponent,
    // AuthPendingPostsComponent,
    ProfilePageComponent,
    ActivePostsComponent,
    AuthPendingPostsComponent,
    PrivatePostsComponent,
    DraftsPostsComponent,
    EditProfileComponent,
    UsersListComponent,
    NewPostComponent,
    AuthPostsComponent,
    DummyComponent,
],
  imports: [
    CommonModule,
    ProfileRoutingModule,
    FormsModule,
    MaterialModule,
    BlogModule,
    NgbPaginationModule,
  ],
  exports: [
    CommonModule,
    FormsModule,
    MaterialModule,
    // MatTableModule,
    // MatPaginatorModule,
    // MatSortModule,
    // MatFormFieldModule
    // ProfilePageComponent,
    // PrivatePostsComponent,
    // AuthPostsComponent,
    // ActivePostsComponent,
    // AuthPendingPostsComponent,
    ProfilePageComponent,
    ActivePostsComponent,
    AuthPendingPostsComponent,
    PrivatePostsComponent,
    DraftsPostsComponent,
    UsersListComponent,
    BlogModule  ,
    NgbPaginationModule,
    DummyComponent
  ]
})
export class ProfileModule { }
