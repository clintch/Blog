import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialModule } from './../core/_helpers/material.module';
import { ProfileRoutingModule } from './profile-routing.module';

import { DashboardComponent } from './components/dashboard/dashboard.component';

import { DashboardAuthPostsComponent } from './components/dashboard-auth-posts/dashboard-auth-posts.component';
import { DashboardEditProfileComponent } from './components/dashboard-edit-profile/dashboard-edit-profile.component';
import { DashboardNewPostComponent } from './components/dashboard-new-post/dashboard-new-post.component';
import { DashboardPostsListComponent } from './components/dashboard-posts-list/dashboard-posts-list.component';
import { ProfilePageComponent } from './components/profile-page/profile-page.component';
import { FormsModule } from '@angular/forms';
import { DashboardUsersListComponent } from './components/dashboard-users-list/dashboard-users-list.component';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { DashboardDraftsComponent } from './components/dashboard-drafts/dashboard-drafts.component';



@NgModule({
  declarations: [
    DashboardComponent,
    DashboardAuthPostsComponent,
    DashboardEditProfileComponent,
    DashboardNewPostComponent,
    DashboardPostsListComponent,
    ProfilePageComponent,
    DashboardUsersListComponent,
    DashboardDraftsComponent,
  ],
  imports: [
    CommonModule,
    ProfileRoutingModule,
    FormsModule,
    MaterialModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,

  ],
  exports: [
    CommonModule,
    DashboardComponent,
    DashboardAuthPostsComponent,
    DashboardEditProfileComponent,
    DashboardNewPostComponent,
    // DashboardUsersListComponent,
    DashboardPostsListComponent,
    FormsModule,
    MaterialModule,
    DashboardUsersListComponent,
    DashboardDraftsComponent,
    MaterialModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
  ]
})
export class ProfileModule { }
