import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BlogPageYoutubeplayerComponent } from './blog-page-youtubeplayer.component';

describe('BlogPageYoutubeplayerComponent', () => {
  let component: BlogPageYoutubeplayerComponent;
  let fixture: ComponentFixture<BlogPageYoutubeplayerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BlogPageYoutubeplayerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BlogPageYoutubeplayerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
