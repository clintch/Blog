import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'blog-page-youtubeplayer',
  templateUrl: './blog-page-youtubeplayer.component.html',
  styleUrls: ['./blog-page-youtubeplayer.component.css']
})
export class BlogPageYoutubeplayerComponent implements OnInit {
  @Input() videoId;
  //videoId: string ="PRQCAL_RMVo";

  constructor() { }

  ngOnInit(): void {
    const tag = document.createElement('script');
    tag.src = "https://www.youtube.com/iframe_api";
    // tag.setHeader("Set-Cookie", "HttpOnly;Secure;SameSite=Strict")
    document.body.appendChild(tag);
  }

}
