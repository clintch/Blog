import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BlogPagePhotosComponent } from './blog-page-photos.component';

describe('BlogPagePhotosComponent', () => {
  let component: BlogPagePhotosComponent;
  let fixture: ComponentFixture<BlogPagePhotosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BlogPagePhotosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BlogPagePhotosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
