import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blog-page-photos',
  templateUrl: './blog-page-photos.component.html',
  styleUrls: ['./blog-page-photos.component.css']
})
export class BlogPagePhotosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
