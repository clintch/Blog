import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { BlogPost, BlogService, UserService, TokenStorageService } from 'src/app/core';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';

@Component({
  selector: 'blog-thumbnail',
  templateUrl: './blog-thumbnail.component.html',
  styleUrls: ['./blog-thumbnail.component.css'],
  providers: [DatePipe]
})
export class BlogThumbnailComponent implements OnInit {

  @Input() blog:BlogPost;
  isLoggedIn: boolean = false;
  user_id: number;
  loggedUser: any={};
  
  @Input() activeStatus: boolean;
  checkActive: boolean;
  @Input() privateStatus: boolean;
  checkPrivate: boolean;
  @Input() draftStatus: boolean;
  checkdraft: boolean;
  @Input() authFlag: boolean;
  checkauthFlag: boolean;
  @Input() home: boolean;

  @Output() privateActiveBlogId = new EventEmitter<number>();
  @Output() activePrivateBlogId = new EventEmitter<number>();
  @Output() draftActiveBlogId = new EventEmitter<number>();
  @Output() authPendingActiveBlogId = new EventEmitter<number>();

  blogid: number;
  space: string = " ";
  likeCount: number;
  viewCount: number;
  hide: boolean;
  likeordis: string;
  imageURL: string;
  checkContinue: boolean;
  
  privateText: string;


  constructor(
    private router: Router,
    private blogService: BlogService,
    public datepipe: DatePipe,
    private breakpointObserver: BreakpointObserver,
    private userService: UserService,
    private tokenServiceService: TokenStorageService,
  ) { }
  
  isHandset$: Observable<boolean> = this.breakpointObserver.observe(
    [ 
      Breakpoints.TabletPortrait, 
      Breakpoints.TabletLandscape,
      Breakpoints.HandsetLandscape,
      Breakpoints.HandsetPortrait,
    ])
    .pipe(
      map(result => result.matches),
      shareReplay()
  );

  ngOnInit(): void {
    // isLoggedIn: boolean = false;
    // user_id: number;
    this.isLoggedIn = !!this.tokenServiceService.getToken();

    if (this.isLoggedIn) {
      this.loggedUser = this.tokenServiceService.getUser();
      this.user_id = this.loggedUser.userDetails[0].userId;
    }
    this.blogid = this.blog.blogId;
    this.likeCount = this.blog.likeCount;
    this.viewCount = this.blog.viewCount;
    this.imageURL ="../../../../assets/images/waterfall.jpg";
    this.hide = true;
    if(this.hide===true)
      this.likeordis = "Like";
    else
      this.likeordis = "DisLike";
    console.log("Content"+this.blog.blogId+" :"+ this.blog.content);
    console.log("FirstName: "+this.blog.firstName+"  &  "+"Last : "+this.blog.lastName);
    console.log("Status :"+ this.blog.status);

    this.checkContinue =  this.transform(this.blog.content, 100);

    this.checkPrivate = this.privateStatus;
    this.checkActive = this.activeStatus;
    this.checkauthFlag = this.authFlag;
    this.checkdraft = this.draftStatus;
    console.log("Draft: "+this.checkdraft);

  }

  onContinueReadingClick() {
    this.router.navigate(['/blog', this.blog.slug]);
  }
  transform(text: string, noofWords:number): boolean {
    let returnText = '';
    let lengthOfText = text.length;
    let bool: boolean;

    for (let i = 0; i < noofWords; i++) {
      let endIndex = text.indexOf(" ");
      returnText = returnText + text.substring(0, endIndex)+" ";
      let textEndPoint = text.length;
      text = text.substring(endIndex+1, textEndPoint);
    }
    
    if(text.length > 0)
      return true;
    else
      return false;
  }

  getBlog(id: number) {
    this.router.navigate(["/blog"], {
      // queryParams: {id}, skipLocationChange: true
      queryParams: {id},
    });
  }

  addLike() {
    this.hide = !this.hide;
    if(this.hide === false) {
      this.userService.addLikeCount(this.blogid, this.user_id,"like").subscribe(
        (response) => {
          this.likeCount = response;
          // this.likeordis = "DisLike";
        }
      );
    }
    else{
      this.userService.addLikeCount(this.blogid, this.user_id,"dislike").subscribe(
        (response) => {
          this.likeCount = response; 
          // this.likeordis = "Like";
        }
      );
   }
  }

  //Make Active from Private
  makeActive() {
    this.userService.updateBlogStatus(this.blog.blogId, this.blog.userId, "A").subscribe(
      (response) => {
        console.log("Num : "+response);
        if(response===1) {
          this.privateActiveBlogId.emit(this.blog.blogId);
        }
          
      }

    );
  }//end

  //Make Private from Active
  makePrivate() {
    this.userService.updateBlogStatus(this.blog.blogId, this.blog.userId, "P").subscribe(
      (response) => {
        let num= response;
        console.log("Num : "+response);
        if(num===1)
          this.activePrivateBlogId.emit(this.blog.blogId);
      }

    );
  }//end

  //Make Active from Draft
  makeActiveFromDraft() {
    this.userService.updateBlogStatus(this.blog.blogId, this.blog.userId, "A").subscribe(
      (response) => {
        let num= response;
        console.log("Num : "+response);
        if(num===1)
          this.draftActiveBlogId.emit(this.blog.blogId);
          
      }

    );
  }//end

  //Make Active from Auth Pending
  makeActiveAfterAuthorization() {
    this.userService.updateAuthFlagPtoA(this.blog.blogId, this.user_id).subscribe(
      (response) => {
        let num= response;
        console.log("Num : "+response);
        if(num===1)
          this.authPendingActiveBlogId.emit(this.blog.blogId);
      }
    );
  }//end

  viewCountAlter() {
    //Api call
    
  }
}
