import { Component, OnInit, Input } from '@angular/core';
import { BlogPost, BlogService } from 'src/app/core';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'blog-thumbnail',
  templateUrl: './blog-thumbnail.component.html',
  styleUrls: ['./blog-thumbnail.component.css'],
  providers: [DatePipe]
})
export class BlogThumbnailComponent implements OnInit {

  @Input() blog:BlogPost;
  @Input() userid: number;

  blogid: number;
  space: string = " ";
  likeCount: number;
  viewCount: number;
  hide: boolean;
  likeordis: string;
  imageURL: string;
  checkContinue: boolean;

  constructor(
    private router: Router,
    private blogService: BlogService,
    public datepipe: DatePipe
  ) { }

  ngOnInit(): void {
    this.blogid = this.blog.blogId;
    this.likeCount = this.blog.likeCount;
    this.viewCount = this.blog.viewCount;
    this.imageURL ="http://placehold.it/700x300";
    this.hide = true;
    if(this.hide===true)
      this.likeordis = "Like";
    else
      this.likeordis = "DisLike";
    console.log("Content"+this.blog.blogId+" :"+ this.blog.content);
    console.log("FirstName: "+this.blog.firstName+"  &  "+"Last : "+this.blog.lastName);

    this.checkContinue =  this.transform(this.blog.content, 10);
  }


  transform(text: string, noofWords:number): boolean {
    let returnText = '';
    let lengthOfText = text.length;
    let bool: boolean;

    for (let i = 0; i < noofWords; i++) {
      let endIndex = text.indexOf(" ");
      returnText = returnText + text.substring(0, endIndex)+" ";
      let textEndPoint = text.length;
      text = text.substring(endIndex+1, textEndPoint);
    }
    
    if(text.length > 0)
      return true;
    else
      return false;
  }

  getBlog(id: number) {
    this.router.navigate(["/blog"], {
      // queryParams: {id}, skipLocationChange: true
      queryParams: {id},
    });
  }

  addLike() {
    this.hide = !this.hide;
    if(this.hide === false) {
      this.blogService.addLikeCount(this.blogid, this.userid,"like").subscribe(
        (response) => {
          this.likeCount = this.likeCount+1;
          this.likeordis = "DisLike";
        }
      );
    }
    else{
      this.blogService.addLikeCount(this.blogid, this.userid,"dislike").subscribe(
        (response) => {
          this.likeCount = this.likeCount-1; 
          this.likeordis = "Like";
        }
      );
   }
  }
}
