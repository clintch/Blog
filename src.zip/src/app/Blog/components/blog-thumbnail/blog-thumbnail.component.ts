import { Component, OnInit, Input } from '@angular/core';
import { BlogPost, BlogService, UserService } from 'src/app/core';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';

@Component({
  selector: 'blog-thumbnail',
  templateUrl: './blog-thumbnail.component.html',
  styleUrls: ['./blog-thumbnail.component.css'],
  providers: [DatePipe]
})
export class BlogThumbnailComponent implements OnInit {

  @Input() blog:BlogPost;
  @Input() userid: number;
  @Input() privatestatus: boolean;

  blogid: number;
  space: string = " ";
  likeCount: number;
  viewCount: number;
  hide: boolean;
  likeordis: string;
  imageURL: string;
  checkContinue: boolean;
  checkPrivate: boolean;
  privateText: string;


  constructor(
    private router: Router,
    private blogService: BlogService,
    public datepipe: DatePipe,
    private breakpointObserver: BreakpointObserver,
    private userService: UserService
  ) { }
  
  isHandset$: Observable<boolean> = this.breakpointObserver.observe(
    [ 
      Breakpoints.TabletPortrait, 
      Breakpoints.TabletLandscape,
      Breakpoints.HandsetLandscape,
      Breakpoints.HandsetPortrait,
    ])
    .pipe(
      map(result => result.matches),
      shareReplay()
  );

  ngOnInit(): void {
    this.blogid = this.blog.blogId;
    this.likeCount = this.blog.likeCount;
    this.viewCount = this.blog.viewCount;
    this.imageURL ="../../../../assets/images/waterfall.jpg";
    this.hide = true;
    if(this.hide===true)
      this.likeordis = "Like";
    else
      this.likeordis = "DisLike";
    console.log("Content"+this.blog.blogId+" :"+ this.blog.content);
    console.log("FirstName: "+this.blog.firstName+"  &  "+"Last : "+this.blog.lastName);
    console.log("Status :"+ this.blog.status);

    this.checkContinue =  this.transform(this.blog.content, 100);
    this.checkPrivate = this.privatestatus;
    
  }

  onContinueReadingClick() {
    this.router.navigate(['/blog', this.blog.slug, {firstName: this.blog.firstName, lastName: this.blog.lastName}]);
  }
  transform(text: string, noofWords:number): boolean {
    let returnText = '';
    let lengthOfText = text.length;
    let bool: boolean;

    for (let i = 0; i < noofWords; i++) {
      let endIndex = text.indexOf(" ");
      returnText = returnText + text.substring(0, endIndex)+" ";
      let textEndPoint = text.length;
      text = text.substring(endIndex+1, textEndPoint);
    }
    
    if(text.length > 0)
      return true;
    else
      return false;
  }

  getBlog(id: number) {
    this.router.navigate(["/blog"], {
      // queryParams: {id}, skipLocationChange: true
      queryParams: {id},
    });
  }

  addLike() {
    this.hide = !this.hide;
    if(this.hide === false) {
      this.userService.addLikeCount(this.blogid, this.userid,"like").subscribe(
        (response) => {
          this.likeCount = response;
          // this.likeordis = "DisLike";
        }
      );
    }
    else{
      this.userService.addLikeCount(this.blogid, this.userid,"dislike").subscribe(
        (response) => {
          this.likeCount = response; 
          // this.likeordis = "Like";
        }
      );
   }
  }

  makeActive() {
    this.userService.changePrivateToActivePost(this.blog.blogId, this.blog.userId).subscribe(
      (response) => {
        let num= response;
        console.log("Num : "+response);
        if(num===1)
          this.checkPrivate = !this.checkPrivate;
      }

    );
  }//makeActive
}
