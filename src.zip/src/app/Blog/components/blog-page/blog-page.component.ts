import { Observable } from 'rxjs';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { BlogPost, BlogService } from 'src/app/core';
import { tap, switchMap, map, shareReplay } from 'rxjs/operators';
import { DatePipe } from '@angular/common';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';

@Component({
  selector: 'app-blog-page',
  templateUrl: './blog-page.component.html',
  styleUrls: ['./blog-page.component.css'],
  providers: [DatePipe]
})
export class BlogPageComponent implements OnInit {

  blog$!: Observable<BlogPost[] | null>;
  id: string = '';
  likeCount: number;
  viewCount: number;
  space: string = " ";
  firstName: string;
  lastName: string;
  imageURL: string = "";
  // blogList: BlogPost[]=[];
blogList: Array<BlogPost> = new Array();

  isHandset$: Observable<boolean> = this.breakpointObserver.observe(
    [ 
      Breakpoints.Handset,
      Breakpoints.HandsetPortrait, 
      Breakpoints.HandsetLandscape,
      Breakpoints.Tablet,
      Breakpoints.TabletPortrait,
      Breakpoints.TabletLandscape
    ])
    .pipe(
      map(result => result.matches),
      shareReplay()
  );

  constructor(
    private actiavtedRoute: ActivatedRoute,
    private blogService: BlogService,
    public datepipe: DatePipe,
    private breakpointObserver: BreakpointObserver
  ) { }

  ngOnInit(): void {
    // this.blog$ = this.actiavtedRoute.paramMap.pipe(
    //   tap((params: ParamMap) => (this.id = params.get('blog') as string)),
    //   switchMap((params: ParamMap) => this.blogService.getBlogBySlug(params.get('blog') as string))
    // );

    let slug = this.actiavtedRoute.snapshot.paramMap.get('blog');
    this.firstName = this.actiavtedRoute.snapshot.paramMap.get('firstName');
    this.lastName = this.actiavtedRoute.snapshot.paramMap.get('lastName');

    this.blogService.getBlogBySlug(slug).subscribe(
      (response) => {
        this.blogList = response;
        console.log(JSON.stringify(response));
          // this.blogService.addViewCount().subscribe(
          //   (response) => {
          //     console.log("view Count Added");
          //   }
          // );
          console.log("Blog OPened");
          console.log("FirstName: "+this.firstName+"  &  "+"Last : "+this.lastName);
       }
    );
    // console.log("slug "+slug);
    // console.log("slug "+this.blog);
  }

}
