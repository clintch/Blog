import { Observable } from 'rxjs';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { BlogPost, BlogService } from 'src/app/core';
import { tap, switchMap } from 'rxjs/operators';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-blog-page',
  templateUrl: './blog-page.component.html',
  styleUrls: ['./blog-page.component.css'],
  providers: [DatePipe]
})
export class BlogPageComponent implements OnInit {

  blog$!: Observable<BlogPost[] | null>;
  id: string = '';
  likeCount: number;
  viewCount: number;
  space: string = " ";
  blogList: BlogPost[]=[];

  constructor(
    private actiavtedRoute: ActivatedRoute,
    private blogService: BlogService,
    public datepipe: DatePipe
  ) { }

  ngOnInit(): void {
    // this.blog$ = this.actiavtedRoute.paramMap.pipe(
    //   tap((params: ParamMap) => (this.id = params.get('blog') as string)),
    //   switchMap((params: ParamMap) => this.blogService.getBlogBySlug(params.get('blog') as string))
    // );

    let slug = this.actiavtedRoute.snapshot.paramMap.get('blog');
    this.blogService.getBlogBySlug(slug).subscribe(
      (response) => {
        this.blogList = response;
          // this.blogService.addViewCount().subscribe(
          //   (response) => {
          //     console.log("view Count Added");
          //   }
          // );
          console.log("Blog OPened");
          console.log("FirstName: "+this.blogList[1].firstName+"  &  "+"Last : "+this.blogList[1].lastName);
      }
    );
    // console.log("slug "+slug);
    // console.log("slug "+this.blog);
  }

}
