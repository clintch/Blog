import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BlogPageSinglecommentComponent } from './blog-page-singlecomment.component';

describe('BlogPageSinglecommentComponent', () => {
  let component: BlogPageSinglecommentComponent;
  let fixture: ComponentFixture<BlogPageSinglecommentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BlogPageSinglecommentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BlogPageSinglecommentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
