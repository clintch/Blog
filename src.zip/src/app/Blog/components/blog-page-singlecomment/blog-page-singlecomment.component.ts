import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'blog-page-singlecomment',
  templateUrl: './blog-page-singlecomment.component.html',
  styleUrls: ['./blog-page-singlecomment.component.css']
})
export class BlogPageSinglecommentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
