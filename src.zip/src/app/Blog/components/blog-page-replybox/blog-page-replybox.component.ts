import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { UserService, ParentComment, Comment, BlogService, ChildComment } from 'src/app/core';

@Component({
  selector: 'blog-page-replybox',
  templateUrl: './blog-page-replybox.component.html',
  styleUrls: ['./blog-page-replybox.component.css']
})
export class BlogPageReplyboxComponent implements OnInit {

   @Input() blogId: number;
  //  @Input() userId: number;
   @Input() parentId: number;

   @Output() newComment = new EventEmitter<ChildComment>();

   comment: ChildComment;
   
  constructor(
    private userService: UserService,
    private blogService: BlogService,
  ) { }

  ngOnInit(): void {
    this.comment= new ChildComment();
    this.comment.blogId = this.blogId;
    this.comment.userId = 1;
    this.comment.parentId = this.parentId;
    // this.comment.userId = this.userId;
  }

  onSubmit() {

    this.userService.postChildComment(this.comment).subscribe(
      (response) => {
        console.log("Child Comment : "+response);
        this.newComment.emit(this.comment);
        this.comment= new ChildComment();
        this.comment.blogId = this.blogId;
        this.comment.userId = 1;
        this.comment.parentId = this.parentId;
      }
    );
  }

}
