import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BlogPageReplyboxComponent } from './blog-page-replybox.component';

describe('BlogPageReplyboxComponent', () => {
  let component: BlogPageReplyboxComponent;
  let fixture: ComponentFixture<BlogPageReplyboxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BlogPageReplyboxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BlogPageReplyboxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
