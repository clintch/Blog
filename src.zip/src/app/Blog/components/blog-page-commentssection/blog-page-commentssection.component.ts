import { Component, OnInit, Input } from '@angular/core';
import { BlogPost, ParentComment } from 'src/app/core';

@Component({
  selector: 'comments-section',
  templateUrl: './blog-page-commentssection.component.html',
  styleUrls: ['./blog-page-commentssection.component.css']
})
export class BlogPageCommentsectionComponent implements OnInit {

  @Input() blog: BlogPost;

  panelOpenState = true;
  constructor() { }

  ngOnInit(): void {

  }

}
