import { Component, OnInit, Input } from '@angular/core';
import { BlogPost, ParentComment, Comment } from 'src/app/core';

@Component({
  selector: 'comments-section',
  templateUrl: './blog-page-commentssection.component.html',
  styleUrls: ['./blog-page-commentssection.component.css']
})
export class BlogPageCommentsectionComponent implements OnInit {

  @Input() blog: BlogPost;
  newComment: Comment;

  getNewParentComment(comment: ParentComment) {
    // this.newComment = comment;
    this.blog.comments.unshift(comment);
    this.blog.replyCount++;
    //console.log("getParentID(): "+ this.parentId);
  }
  panelOpenState = true;
  constructor() { }

  ngOnInit(): void {

  }

  getReplyCount(replyCount: number) {
    this.blog.replyCount += replyCount;
  }
}
