import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BlogPageCommentsectionComponent } from './blog-page-commentssection.component';

describe('BlogPageCommentssectionComponent', () => {
  let component: BlogPageCommentsectionComponent;
  let fixture: ComponentFixture<BlogPageCommentsectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BlogPageCommentsectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BlogPageCommentsectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
