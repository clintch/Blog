import { Component, OnInit, Input } from '@angular/core';
import { UserService, ParentComment, Comment, BlogService } from 'src/app/core';

@Component({
  selector: 'blog-page-commentbox',
  templateUrl: './blog-page-commentbox.component.html',
  styleUrls: ['./blog-page-commentbox.component.css']
})
export class BlogPageCommentboxComponent implements OnInit {

   @Input() blogId: number;
  //  @Input() userId: number;
   
   parentId: number;
   comment= new Comment();
   
  constructor(
    private userService: UserService,
    private blogService: BlogService,
  ) { }

  ngOnInit(): void {
    this.comment.blogId = this.blogId;
    this.comment.userId = 1;
    // this.comment.userId = this.userId;
  }

  submit() {

    this.blogService.postParentComment(this.comment).subscribe(
      (response) => {
        this.parentId = response.parentId; //parentId will be set
      }
    )
  }

}
