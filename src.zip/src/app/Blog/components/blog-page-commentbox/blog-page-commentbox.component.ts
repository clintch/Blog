import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { UserService, ParentComment, Comment, BlogService } from 'src/app/core';

@Component({
  selector: 'blog-page-commentbox',
  templateUrl: './blog-page-commentbox.component.html',
  styleUrls: ['./blog-page-commentbox.component.css']
})
export class BlogPageCommentboxComponent implements OnInit {

   @Input() blogId: number;
  //  @Input() userId: number;
  @Output() newComment = new EventEmitter<ParentComment>();
   

   comment:ParentComment;
   
  constructor(
    private userService: UserService,
    private blogService: BlogService,
  ) { }

  ngOnInit(): void {
    this.comment= new ParentComment();
    this.comment.blogId = this.blogId;
    this.comment.userId = 1;
    // this.comment.userId = this.userId;
  }

  onSubmit() {
    this.userService.postParentComment(this.comment).subscribe(
      (response) => {
        this.comment.parentId = response;
        this.newComment.emit(this.comment);
        this.comment= new ParentComment();
        this.comment.blogId = this.blogId;
        this.comment.userId = 1;
      }
    )
  }

}
