import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BlogPageCommentboxComponent } from './blog-page-commentbox.component';

describe('BlogPageCommentboxComponent', () => {
  let component: BlogPageCommentboxComponent;
  let fixture: ComponentFixture<BlogPageCommentboxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BlogPageCommentboxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BlogPageCommentboxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
