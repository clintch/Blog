import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ParentComment, ChildComment } from 'src/app/core';
import { Observable } from 'rxjs';
import { Breakpoints, BreakpointObserver } from '@angular/cdk/layout';
import { map, shareReplay } from 'rxjs/operators';

@Component({
  selector: 'blog-page-nestedcomment',
  templateUrl: './blog-page-nestedcomment.component.html',
  styleUrls: ['./blog-page-nestedcomment.component.css']
})
export class BlogPageNestedcommentComponent implements OnInit {

  @Input() parentComment: ParentComment;
  @Input() blogId: number;

  @Output() replyCount  = new EventEmitter<number>();
  panelOpenState = false;


  isHandset$: Observable<boolean> = this.breakpointObserver.observe(
    [ 
      Breakpoints.Handset,
      Breakpoints.HandsetPortrait, 
      Breakpoints.HandsetLandscape,
      Breakpoints.Tablet,
      Breakpoints.TabletPortrait,
      Breakpoints.TabletLandscape
    ])
    .pipe(
      map(result => result.matches),
      shareReplay()
  );
  constructor( private breakpointObserver: BreakpointObserver) { }

  ngOnInit(): void {
    console.log("Parent Id in : "+this.parentComment.parentId);
  }

  getNewChildComment(comment: ChildComment) {
    // this.newComment = comment;
    this.parentComment.children.push(comment);
    this.replyCount.emit(1);
    //console.log("getParentID(): "+ this.parentId);
  }

}
