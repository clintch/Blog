import { Component, OnInit, Input } from '@angular/core';
import { ParentComment } from 'src/app/core';

@Component({
  selector: 'blog-page-nestedcomment',
  templateUrl: './blog-page-nestedcomment.component.html',
  styleUrls: ['./blog-page-nestedcomment.component.css']
})
export class BlogPageNestedcommentComponent implements OnInit {

  @Input() parentComment: ParentComment;
  panelOpenState = false;

  constructor() { }

  ngOnInit(): void {
  }

}
