import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BlogPageNestedcommentComponent } from './blog-page-nestedcomment.component';

describe('BlogPageNestedcommentComponent', () => {
  let component: BlogPageNestedcommentComponent;
  let fixture: ComponentFixture<BlogPageNestedcommentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BlogPageNestedcommentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BlogPageNestedcommentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
