import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {YouTubePlayerModule} from '@angular/youtube-player';

import { SharedModule } from '../Shared';
import { CoreModule } from '../core';
import { BlogRoutingModule } from './blog-routing.module';
import { BlogPageComponent } from './components/blog-page/blog-page.component';
import { BlogThumbnailComponent } from './components/blog-thumbnail/blog-thumbnail.component';
import { MaterialModule } from '../core';
import { BlogPagePhotosComponent } from './components/blog-page-photos/blog-page-photos.component';
import { PostGuard } from '../core/_guards';
import { BlogPageYoutubeplayerComponent } from './components/blog-page-youtubeplayer/blog-page-youtubeplayer.component';
import { BlogPageCommentboxComponent } from './components/blog-page-commentbox/blog-page-commentbox.component';
import { BlogPageSinglecommentComponent } from './components/blog-page-singlecomment/blog-page-singlecomment.component';
import { BlogPageNestedcommentComponent } from './components/blog-page-nestedcomment/blog-page-nestedcomment.component';
import { BlogPageCommentsectionComponent } from './components/blog-page-commentssection/blog-page-commentssection.component';
import { FormsModule } from '@angular/forms';




@NgModule({
  declarations: [
    BlogPageComponent,
    BlogThumbnailComponent, 
    BlogPagePhotosComponent, 
    BlogPageYoutubeplayerComponent, 
    BlogPageCommentboxComponent, 
    BlogPageSinglecommentComponent, 
    BlogPageNestedcommentComponent,
    BlogPageCommentsectionComponent,
  ],
  imports: [
    CommonModule,
    BlogRoutingModule,
    MaterialModule,
    YouTubePlayerModule,
    SharedModule,
    CoreModule,
    FormsModule
  ],
  exports: [
    CommonModule,
    BlogRoutingModule,
    BlogPageComponent,
    BlogThumbnailComponent,
    MaterialModule,
    BlogPagePhotosComponent, 
    YouTubePlayerModule,
    BlogPageYoutubeplayerComponent,
    BlogPageCommentboxComponent, 
    BlogPageSinglecommentComponent, 
    BlogPageNestedcommentComponent,
    BlogPageCommentsectionComponent,
    SharedModule,
  ],
  providers: [
    PostGuard
  ],
})
export class BlogModule { }
