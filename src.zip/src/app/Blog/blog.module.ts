import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BlogRoutingModule } from './blog-routing.module';
import { BlogPageComponent } from './component/blog-page/blog-page.component';
import { BlogPageCommentsComponent } from './component/blog-page-comments/blog-page-comments.component';


@NgModule({
  declarations: [BlogPageComponent, BlogPageCommentsComponent],
  imports: [
    CommonModule,
    BlogRoutingModule
  ],
  exports: [
    CommonModule,
    BlogRoutingModule
  ]
})
export class BlogModule { }
