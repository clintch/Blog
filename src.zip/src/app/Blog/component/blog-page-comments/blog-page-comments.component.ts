import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blog-page-comments',
  templateUrl: './blog-page-comments.component.html',
  styleUrls: ['./blog-page-comments.component.css']
})
export class BlogPageCommentsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
