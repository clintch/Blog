import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BlogPageCommentsComponent } from './blog-page-comments.component';

describe('BlogPageCommentsComponent', () => {
  let component: BlogPageCommentsComponent;
  let fixture: ComponentFixture<BlogPageCommentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BlogPageCommentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BlogPageCommentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
