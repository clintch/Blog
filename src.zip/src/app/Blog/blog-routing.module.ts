import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BlogPageComponent } from './components/blog-page';
import { PostGuard } from '../core/_guards';
import { PageNotFoundComponent } from '../Shared';

const routes: Routes = [

  {
    path: "",
    component: BlogPageComponent,
    // canActivate: [PostGuard],
  },
  // { 
  //   path: '**',
  //   component: PageNotFoundComponent
  // }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BlogRoutingModule { }
