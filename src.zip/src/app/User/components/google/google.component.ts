import { AuthenticateService } from 'src/app/core';
import { Component, OnInit } from '@angular/core';



@Component({
  selector: 'google',
  templateUrl: './google.component.html',
  styleUrls: ['./google.component.css']
})
export class GoogleComponent implements OnInit {

  constructor(private authenticateService: AuthenticateService) {}
  signInWithGoogle(): void {
    this.authenticateService.gooFaceSignIn("google");
  }

  ngOnInit(): void {
  }

}
