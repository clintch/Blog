import { Router } from '@angular/router';
import { UniversalLoginStg, AuthenticateService, UserService } from 'src/app/core';
import { Component } from '@angular/core';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';


@Component({
  selector: 'signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent {
  user = new UniversalLoginStg();
  hide = true;
  emailSame=false;
  isSignUpFailed: boolean = false;
  errorMessage: string="";
  isSuccessful = false;

  isHandset$: Observable<boolean> = this.breakpointObserver.observe(
    [ 
      Breakpoints.WebPortrait, 
      Breakpoints.WebLandscape,
    ])
    .pipe(
      map(result => result.matches),
      shareReplay()
  );
  
  constructor(
    private authenticateService: AuthenticateService,
    private router: Router,
    private breakpointObserver: BreakpointObserver,
    private userService: UserService
    ) { }

  submit() {
      this.authenticateService.register(this.user).subscribe(
        (response) => {
          console.log(response);
          this.isSuccessful = true;
          this.isSignUpFailed = false;
          this.router.navigate(["/token"]);
        },
        (errors) => {
           this.errorMessage = errors.error.message;
          this.isSignUpFailed = true;
          this.router.navigate(["/signup"]);
        }
      );
    }
    //primaryEmail available check
    checkEmail(value) {
      this.userService.checkEmail(value).subscribe(
        (response) => {
          this.emailSame = true;
        }
      );
      // alert("Value : "+value);
    }

    getValue(event) {
      
    }
}
