import { Router } from '@angular/router';
import { UniversalLoginStg, AuthenticateService } from 'src/app/core';
import { Component } from '@angular/core';


@Component({
  selector: 'signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent {
  user = new UniversalLoginStg();
  hide = true;
  emailSame=false;
  isSignUpFailed: boolean = false;
  errorMessage: string="";
  isSuccessful = false;
  constructor(
    private authenticateService: AuthenticateService,
    private router: Router
    ) { }

  submit() {
      this.authenticateService.register(this.user).subscribe(
        (response) => {
          console.log(response);
          this.isSuccessful = true;
          this.isSignUpFailed = false;
          this.router.navigate(["/token"]);
        },
        (errors) => {
           this.errorMessage = errors.error.message;
          this.isSignUpFailed = true;
          this.router.navigate(["/signup"]);
        }
      );
    }
    checkEmail() {
      alert("Email is available");
    }

    getValue(event) {
      
    }
}
