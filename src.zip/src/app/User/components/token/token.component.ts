import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/core';

@Component({
  selector: 'token',
  templateUrl: './token.component.html',
  styleUrls: ['./token.component.css']
})
export class TokenComponent implements OnInit {
  token: any = {};
  hide = true;
  errorMessage: string;
  isTokenFailed: boolean= false;

  constructor(
    private userService: UserService,
    private router: Router
  ) { }

  ngOnInit(): void {
  }

  submit() {
    this.userService.getToken(this.token).subscribe(
      (response) => {
        console.log("token verified");
        this.router.navigate(["/profile"]);
      },
      (errors) => {
        // this.errorMessage = errors.error.message;
        this.isTokenFailed= true;
        this.errorMessage = "Token is not Verified";
      }
    )
  }
}
