import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/core';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';
@Component({
  selector: 'token',
  templateUrl: './token.component.html',
  styleUrls: ['./token.component.css']
})
export class TokenComponent implements OnInit {
  token: any = {};
  hide = true;
  errorMessage: string;
  isTokenFailed: boolean= false;

  isHandset$: Observable<boolean> = this.breakpointObserver.observe(
    [ 
      Breakpoints.WebPortrait, 
      Breakpoints.WebLandscape,
    ])
    .pipe(
      map(result => result.matches),
      shareReplay()
  );

  constructor(
    private userService: UserService,
    private router: Router,
    private breakpointObserver: BreakpointObserver,
  ) { }

  ngOnInit(): void {
  }

  submit() {
    this.userService.getToken(this.token).subscribe(
      (response) => {
        console.log("token verified");
        this.router.navigate(["/profile"]);
      },
      (errors) => {
        // this.errorMessage = errors.error.message;
        this.isTokenFailed= true;
        this.errorMessage = "Token is not Verified";
      }
    )
  }
}
