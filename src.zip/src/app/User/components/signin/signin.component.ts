import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { AuthenticateService, TokenStorageService } from 'src/app/core';


@Component({
  selector: 'signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent{
  user: any= {};
  hide = true;  //password Hide and Show
  emailSame=false;
  isLoggedIn = false;
  isLoginFailed = false;
  errorMessage = '';
  roles: string[] = [];
  constructor(
    private authenticateService: AuthenticateService,
    private router: Router,
    private tokenStorageService: TokenStorageService
  ) { }

  ngOnInit() {
    if(this.tokenStorageService.getCookieToken()) {
      this.isLoggedIn = true;
      this.roles = this.tokenStorageService.getCookieUser().roles;
    }
    else if (this.tokenStorageService.getSessionToken()) {
      this.isLoggedIn = true;
      this.roles = this.tokenStorageService.getSessionUser().roles;
    }
  }

  submit() {
        this.authenticateService.authenticate(this.user).subscribe(
          (response) => {
            console.log(response);
            this.tokenStorageService.saveToken(response);
            this.tokenStorageService.saveUser(response);

            this.isLoginFailed = false;
            this.isLoggedIn = true;
            this.roles = this.tokenStorageService.getSessionUser().roles;
            this.router.navigate(["/token"]);
          },
          (errors) => {
            this.errorMessage = errors.error.message;
            this.isLoginFailed = true;
          }
        )
    }
    checkEmail() {

    }

    getValue(event) {
      
    }
    reloadPage() {
      window.location.reload();
    }
}
