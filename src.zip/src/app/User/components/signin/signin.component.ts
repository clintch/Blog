import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { AuthenticateService, TokenStorageService } from 'src/app/core';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';
import { SocialAuthService } from 'angularx-social-login';

@Component({
  selector: 'signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent{
  user: any= {};
  hide = true;  //password Hide and Show
  emailSame=false;
  // loggedIn = false;
  // isLoginFailed = false;
  // errorMessage = '';
  // roles: string[] = [];

  // form: any = {};
  isLoggedIn = false;
  isLoginFailed = false;
  errorMessage = '';
  roles: string[] = [];

  constructor(
    private authenticateService: AuthenticateService,
    private router: Router,
    private tokenStorageService: TokenStorageService,
    private breakpointObserver: BreakpointObserver,
    private authService: SocialAuthService
  ) { }



  ngOnInit() {
    if (this.tokenStorageService.getToken()) {
      this.isLoggedIn = true;
      this.roles = this.tokenStorageService.getUser().roles;
    }
  }

  onSubmit() {
    this.authenticateService.authenticate(this.user).subscribe(
      (response) => {
        this.tokenStorageService.saveToken(response.accessToken);
        this.tokenStorageService.saveUser(response);
        console.log(response);

        this.isLoginFailed = false;
        this.isLoggedIn = true;
        this.roles = this.tokenStorageService.getUser().roles;
        this.reloadPage();
      },
      err => {
        this.errorMessage = err.error.message;
        this.isLoginFailed = true;
      }
    );
  }

  reloadPage() {
    window.location.reload();
  }

  isWeb$: Observable<boolean> = this.breakpointObserver.observe(
    [ 
      Breakpoints.WebPortrait, 
      Breakpoints.WebLandscape,
    ])
    .pipe(
      map(result => result.matches),
      shareReplay()
  );

  isHandset$: Observable<boolean> = this.breakpointObserver.observe(
    [ 
      Breakpoints.Handset,
      Breakpoints.HandsetPortrait, 
      Breakpoints.HandsetLandscape,
      Breakpoints.Tablet,
      Breakpoints.TabletPortrait,
      Breakpoints.TabletLandscape
    ])
    .pipe(
      map(result => result.matches),
      shareReplay()
  );
  


  // ngOnInit() {
    // console.log("LoginFalied: "+ this.isLoginFailed);
    // this.authService.authState.subscribe((user) => {
    //   this.user = user;
    //   this.isLoggedIn = (user != null);
    // });

    // if(this.tokenStorageService.getCookieToken()) {
    //   this.isLoggedIn = true;
    //   this.roles = this.tokenStorageService.getCookieUser().roles;
    // }
    // else if (this.tokenStorageService.getSessionToken()) {
    //   this.isLoggedIn = true;
    //   this.roles = this.tokenStorageService.getSessionUser().roles;
    // }
  // }

  // submit() {
  //   console.log("Entered Submit()");
  //       this.authenticateService.authenticate(this.user).subscribe(
  //         (response) => {
  //           console.log(response);
  //           let userId = response.userId;
  //           this.tokenStorageService.saveToken(response.accessToken);
  //           this.tokenStorageService.saveUser(response);

  //           this.isLoginFailed = true;
  //           console.log("LoginFalied: "+ this.isLoginFailed);
  //           this.loggedIn = true;
            // this.roles = this.tokenStorageService.getCookieUser().roles;
            // console.log("Roles:"+this.tokenStorageService.getCookieUser().roles);
            // console.log("Role 1: "+this.roles[0]);
            // console.log("Role 2: "+this.roles[1]);
            // this.reloadPage();
            // console.log("Reload");
            // this.router.navigate(["/profile"], { 
            //      queryParams: {id: userId}});
    //       },
    //       (errors) => {
    //         console.log("Error");
    //         this.errorMessage = errors.error.message;
    //         this.isLoginFailed = true;
    //       }
    //     )
    // }
    checkEmail() {

    }

    // getValue(event) {
      
    // }
    // reloadPage() {
    //   window.location.reload();
    // }
}
