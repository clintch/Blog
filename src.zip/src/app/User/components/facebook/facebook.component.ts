import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'facebook',
  templateUrl: './facebook.component.html',
  styleUrls: ['./facebook.component.css']
})
export class FacebookComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
