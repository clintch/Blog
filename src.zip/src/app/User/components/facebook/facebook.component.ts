import { Component, OnInit } from '@angular/core';
import { AuthenticateService } from 'src/app/core';

@Component({
  selector: 'facebook',
  templateUrl: './facebook.component.html',
  styleUrls: ['./facebook.component.css']
})
export class FacebookComponent implements OnInit {

  constructor(private authenticateService: AuthenticateService) {}
  signInWithFB(): void {
    this.authenticateService.gooFaceSignIn("facebook");
  }

  ngOnInit(): void {
  }

}
