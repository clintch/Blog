import { FontAwesomeModule, FaIconLibrary } from '@fortawesome/angular-fontawesome';
import { MaterialModule } from './../core/_helpers/material.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UserRoutingModule } from './user-routing.module';
import { SignupComponent } from './components/signup/signup.component';
import { SigninComponent } from './components/signin/signin.component';
import { GoogleComponent } from './components/google/google.component';
import { FacebookComponent } from './components/facebook/facebook.component';
import { FormsModule } from '@angular/forms';
import {
  GoogleLoginProvider,
  FacebookLoginProvider,
  SocialAuthServiceConfig,
} from "angularx-social-login";
import { TokenComponent } from './components/token/token.component';
import { faGoogle, faFacebook } from '@fortawesome/free-brands-svg-icons';

const Google_OAuth_Client_Id: string = "895128221624-svemo6vvr51do9jvo0es98ke3scgojof.apps.googleusercontent.com";
const Facebook_App_Id: string = "3210189662400494";
const LinkedIn_App_Id: string = "86ufxofi41rj61";

@NgModule({
  declarations: [SignupComponent, SigninComponent, GoogleComponent, FacebookComponent, TokenComponent],
  imports: [
    CommonModule,
    UserRoutingModule,
    FormsModule,
    MaterialModule,
    FontAwesomeModule
  ],
  exports:[
    CommonModule,
    FormsModule,
    MaterialModule,
    SignupComponent,
    SigninComponent,
    GoogleComponent,
    FacebookComponent,
    FontAwesomeModule
  ],
  providers: [
    {
      provide: 'SocialAuthServiceConfig',
      useValue: {
        autoLogin: false,
        providers: [
          {
            id: GoogleLoginProvider.PROVIDER_ID,
            provider: new GoogleLoginProvider(
              '624796833023-clhjgupm0pu6vgga7k5i5bsfp6qp6egh.apps.googleusercontent.com'
            ),
          },
          {
            id: FacebookLoginProvider.PROVIDER_ID,
            provider: new FacebookLoginProvider('561602290896109'),
          },
        ],
      } as SocialAuthServiceConfig,
    }
  ],
})
export class UserModule { 
  constructor(private library: FaIconLibrary) {
    library.addIcons(faGoogle, faFacebook);
  }
}
