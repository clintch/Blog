import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SigninComponent } from './components/signin';
import { SignupComponent } from './components/signup';
import { TokenComponent } from './components/token';
import { PageNotFoundComponent } from '../Shared';


const routes: Routes = [
  {
    path: "{/signin}",
    component: SigninComponent,
  },
  {
    path: "signup",
    component: SignupComponent,
  },
  {
    path: "token",
    component: TokenComponent,
  },
  {
    path: "home",
    loadChildren: "./Home/#HomeModule",
  },
  // {
  //   path: "",
  //   redirectTo: "home",
  //   pathMatch: 'full'
  // }

  // { 
  //   path: '**',
  //   component: PageNotFoundComponent
  // }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserRoutingModule { }
