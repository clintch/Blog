package com.user.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.user.service.UserProfileUpdatingService;

import io.swagger.annotations.ApiOperation;

import com.blog.model.BlogPost;
import com.user.dto.UserMasterRequestDto;
import com.user.dto.UserMasterUpdateRequestDto;
import com.user.dto.UserProfileRequestDto;
import com.user.model.UserMaster;



@RestController
//@RequestMapping("/blog/details")
@CrossOrigin("*")
public class UserProfileController {
	private final UserProfileUpdatingService userProfileUpdatingService;
	
	@Autowired
	public UserProfileController(UserProfileUpdatingService userProfileUpdatingService) {
		this.userProfileUpdatingService = userProfileUpdatingService;
	}
	
//	@GetMapping
//	public ResponseEntity<List<MobileNumber>> findAll() {
//		return ResponseEntity.ok(MobileNumberService.findAll());
//	}
	
	
	
	

	
//	
//	@GetMapping("/{id}")
//	public ResponseEntity <UserMaster> findById(@PathVariable Long id){
//		 return ResponseEntity.ok(ProfileUpdatingService.findByUserId(id).get());
//		 
//	}
	
	
	@PostMapping("/profile/userDetails")
	@ApiOperation("get user details by userId")
	public  Optional<UserMaster> getProfile(@RequestBody UserProfileRequestDto userProfileRequestDto) {
		return userProfileUpdatingService.findByUserId(userProfileRequestDto.getUserId());	
		
	}
	
	
//	@PostMapping("/profile/{primaryEmail}")
//	@ApiOperation("Profile")
//	public  Optional<UserMaster> getProfileByEmail(@RequestBody UserProfileDto userProfileDto) {
//		return ProfileUpdatingService.getPrimayEmail(userProfileDto.getPrimaryEmail());
//		
//	}
	
	
	@PostMapping("/profile/saveProfile")
	@ApiOperation("To create a user profile !")
	 public String save(@RequestBody UserMasterRequestDto userMasterReq){
		UserMaster usrMasterSave = new UserMaster(userMasterReq.getFirstName(),userMasterReq.getMiddleName(),userMasterReq.getLastName(),userMasterReq.getPrimaryMobile(),userMasterReq.getSecondaryMobile(),userMasterReq.getPrimaryEmail(),userMasterReq.getSecondaryEmail(),userMasterReq.getAddress1(),userMasterReq.getAddress2(),userMasterReq.getStreetName(),userMasterReq.getStateCode(),userMasterReq.getDistrictCode(),userMasterReq.getPinCode(),userMasterReq.getIntro(),userMasterReq.getProfile(),userMasterReq.getGender(),userMasterReq.getProfessionCode());
		  ResponseEntity.status(HttpStatus.CREATED).body(userProfileUpdatingService.save(usrMasterSave));
		  return "User created !";
		 }
	
	@PutMapping("profile/updateProfile")
	@ApiOperation("Update the user details ")
	public Boolean update (@RequestBody UserMasterUpdateRequestDto userMasterUpdateReq) {
		UserMaster usrMasterUpdate = new UserMaster(userMasterUpdateReq.getUserId(),userMasterUpdateReq.getFirstName(),userMasterUpdateReq.getMiddleName(),userMasterUpdateReq.getLastName(),userMasterUpdateReq.getPrimaryMobile(),userMasterUpdateReq.getSecondaryMobile(),userMasterUpdateReq.getPrimaryEmail(),userMasterUpdateReq.getSecondaryEmail(),userMasterUpdateReq.getAddress1(),userMasterUpdateReq.getAddress2(),userMasterUpdateReq.getStreetName(),userMasterUpdateReq.getStateCode(),userMasterUpdateReq.getDistrictCode(),userMasterUpdateReq.getPinCode(),userMasterUpdateReq.getIntro(),userMasterUpdateReq.getProfile(),userMasterUpdateReq.getGender(),userMasterUpdateReq.getProfessionCode());
		 ResponseEntity.accepted().body(userProfileUpdatingService.save(usrMasterUpdate));
		 return true;
	}
	
	@DeleteMapping("profile/deleteProfile/{userId}")
	@ApiOperation("To remove user by userId")
	public ResponseEntity delete(@PathVariable Long userId) {
		userProfileUpdatingService.deleteById(userId);
		return ResponseEntity.accepted().build();
		
	}
	
	
}
