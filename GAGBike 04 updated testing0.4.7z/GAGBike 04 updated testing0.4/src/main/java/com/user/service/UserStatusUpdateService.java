package com.user.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.user.dao.UserStatusUpdateDao;

@Service
public class UserStatusUpdateService {
	
	@Autowired
	UserStatusUpdateDao userStatusUpdateDao;
	
	public void userStatusUpdation(long userId, String status) {
		userStatusUpdateDao.updateBlogPostStatus(userId, status);
		
	}

}
