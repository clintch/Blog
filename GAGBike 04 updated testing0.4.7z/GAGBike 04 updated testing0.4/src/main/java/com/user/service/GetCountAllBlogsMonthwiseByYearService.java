package com.user.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.blog.model.BlogPost;
import com.user.dao.GetCountAllBlogsMonthwiseByYearDao;
import com.user.dto.GetCountAllBlogsMonthwiseByYearResponseDto;

@Service
public class GetCountAllBlogsMonthwiseByYearService {

	@Autowired
	GetCountAllBlogsMonthwiseByYearDao getCountAllBlogsMonthwiseByYearDao;
	
	public List<GetCountAllBlogsMonthwiseByYearResponseDto> getCountAllBlogsMonthwiseByYear(int year) {
		return getCountAllBlogsMonthwiseByYearDao.getCountAllBlogsMonthwiseByYear(year);
	}
	
//	public List<BlogPost> getBlogBySlug( String slug){
//		return blogPostBySlugDao.getBlogBySlug(slug);
//		
//	}
}
