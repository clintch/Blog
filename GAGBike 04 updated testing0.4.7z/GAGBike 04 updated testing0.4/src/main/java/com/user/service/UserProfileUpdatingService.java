package com.user.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.user.service.UserProfileUpdatingService;
import com.user.model.UserMaster;
import com.user.dao.UserProfileUpdatingDao;
import com.user.dto.UserMasterRequestDto;


@Service
public class UserProfileUpdatingService {
	
	private final UserProfileUpdatingDao userProfileUpdatingDao;
	
	
	@Autowired
	public UserProfileUpdatingService (UserProfileUpdatingDao userProfileUpdatingDao ) {
		this.userProfileUpdatingDao = userProfileUpdatingDao;
		
	}
//	public List<MobileNumber> findAll(){
//		return mobrepo.findAll();
//	}
//	
	public Optional<UserMaster> findByUserId(Long userId){
		return userProfileUpdatingDao.findById(userId);
		
	}
	 
	public UserMaster save (UserMaster userMaster) {
		userMaster.setAddDate(new Date());
		userMaster.setAuthFlag("N");
		userMaster.setBlogCount(0);
		userMaster.setFollowersCnt(0);
		userMaster.setFollowingCnt(0);
		userMaster.setStatus("I");
		userMaster.setContactVerifyFlag((byte) 0);
		
		
		return userProfileUpdatingDao.save(userMaster);
	}
	
	public void deleteById(Long userId) {
		userProfileUpdatingDao.deleteById(userId);
		
	}
	
	
	
	

}
