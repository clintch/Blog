package com.user.model;

import java.io.Serializable;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Columns;

import lombok.Data;

@Entity
@Table(name = "user_login_roles")
@Data
public class UserLoginRoles implements Serializable {
	@Id
	@Column(name = "user_id")
	private int userId;
	@Column(name = "role_id")
	private int roleId;

}
