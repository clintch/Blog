package com.user.dao;

import com.user.model.UserMaster;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;
@Repository
public class ProfileByEmail {

    @PersistenceContext
    private EntityManager em;
    
 
    @Transactional
    public List<UserMaster> getByPrimaryEmail(String primaryEmail) {
    	  //TypedQuery<BlogPost> query = em.createQuery("SELECT c FROM BlogPost c ", BlogPost.class);
    		 // List<BlogPost> results = query.getResultList();
    		
    		  String queryStr =
    			      //"SELECT NEW com.blog.model.BlogPage(c.blogId,c.userId,d.firstName,d.lastName,c.parentId,c.title,c.metaTitle,c.slug,c.summary,c.published,c.createdAt,c.updatedAt,c.publishedAt,c.replyCount,c.likeCount,c.viewCount,c.status,c.authFlag,c.authUser,c.authDate ,c.content) FROM BlogPost c JOIN UserMaster d ON c.userId = d.userId where c.slug = :slug";

    			      "SELECT c FROM UserMaster c  where c.primaryEmail = :primaryEmail";
    		  
    		  TypedQuery<UserMaster> query =
    			      em.createQuery(queryStr, UserMaster.class);
    			//  List<BlogPage> results = query.getResultList();
    		  List<UserMaster> results =  query.setParameter("primaryEmail", primaryEmail).getResultList();
    			  return results;
    	//	  return results;
    }	
}
