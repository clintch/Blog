package com.user.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

@Repository
public class UserStatusUpdateDao {
	
	 @PersistenceContext
	 private EntityManager em;
	    
    @Transactional
    public void updateBlogPostStatus(long userId, String status) {
    	
    	Query qry= em.createQuery("UPDATE UserMaster t1 SET t1.status = :status WHERE t1.userId = :userId");
       	qry.setParameter("userId", userId);
    	qry.setParameter("status", status);
    	qry.executeUpdate();
    	}

}
