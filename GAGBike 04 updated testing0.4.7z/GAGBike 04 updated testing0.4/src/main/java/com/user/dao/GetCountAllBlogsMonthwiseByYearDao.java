package com.user.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import com.blog.dto.BlogPostCategoryResponseDto;
import com.blog.model.BlogPost;
import com.user.dto.GetCountAllBlogsMonthwiseByYearResponseDto;
import org.springframework.stereotype.Repository;

@Repository
public class GetCountAllBlogsMonthwiseByYearDao {
	
	 @PersistenceContext
	 private EntityManager em;
	 
	 @Transactional
	 public List<GetCountAllBlogsMonthwiseByYearResponseDto> getCountAllBlogsMonthwiseByYear(int year) {
		 
		 String qry= "select NEW com.user.dto.GetCountAllBlogsMonthwiseByYearResponseDto(count(blog_id), MONTH(published_at)) from BlogPost AS bc where"
				 		+
				 	 " YEAR(published_at)=:year AND MONTH(published_at)>=1 AND MONTH(published_at)<=12"
				 		+
				 	 " group by MONTH(published_at) order by MONTH(published_at)";
		 TypedQuery<GetCountAllBlogsMonthwiseByYearResponseDto> query = em.createQuery(qry, GetCountAllBlogsMonthwiseByYearResponseDto.class);
	     return query.setParameter("year", year).getResultList();
	     
//	     TypedQuery<BlogPostCategoryResponseDto> query = em.createQuery("SELECT DISTINCT  NEW com.blog.dto.BlogPostCategoryResponseDto(bc.title,bc.parentCatId) FROM BlogCategoryMaster AS bc ", BlogPostCategoryResponseDto.class);
//   	  List<BlogPostCategoryResponseDto> results = query.getResultList();
//   		  return results;
	 }
}
