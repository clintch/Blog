package com.user.dao;


import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.user.model.UserMaster;

public interface UserProfileUpdatingDao extends JpaRepository<UserMaster, Long>{


}
