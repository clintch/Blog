package com.user.dto;

public class UserStatusUpdateRequestDto {
	
	private long userId ;
	private String status;

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	public UserStatusUpdateRequestDto() {
		
	}

	public UserStatusUpdateRequestDto(long userId, String status) {
		this.userId = userId;
		this.status = status;
	}
	
}
