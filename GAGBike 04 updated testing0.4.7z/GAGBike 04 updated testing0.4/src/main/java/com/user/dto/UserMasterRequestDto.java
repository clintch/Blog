package com.user.dto;

import java.util.Date;

public class UserMasterRequestDto {
	
	
	//private long userId ;
	private String firstName;
	private String middleName;
	private String lastName;
	private long primaryMobile;
	private long secondaryMobile;
	private String primaryEmail;
	private String secondaryEmail;
	private String Address1;	
	private String Address2;	
	private String streetName;
	private String stateCode;	
	private String districtCode;
	private long pinCode;	
	//private Date addDate;
	private String intro;
	private String profile;
	//private String authFlag;
	//private long blogCount;
	//private long followersCnt;
	//private long followingCnt;
	//private String status;
	//private byte contactVerifyFlag;
	private String	gender;
	private String	professionCode;
	
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public long getPrimaryMobile() {
		return primaryMobile;
	}
	public void setPrimaryMobile(long primaryMobile) {
		this.primaryMobile = primaryMobile;
	}
	public long getSecondaryMobile() {
		return secondaryMobile;
	}
	public void setSecondaryMobile(long secondaryMobile) {
		this.secondaryMobile = secondaryMobile;
	}
	public String getPrimaryEmail() {
		return primaryEmail;
	}
	public void setPrimaryEmail(String primaryEmail) {
		this.primaryEmail = primaryEmail;
	}
	public String getSecondaryEmail() {
		return secondaryEmail;
	}
	public void setSecondaryEmail(String secondaryEmail) {
		this.secondaryEmail = secondaryEmail;
	}
	public String getAddress1() {
		return Address1;
	}
	public void setAddress1(String address1) {
		Address1 = address1;
	}
	public String getAddress2() {
		return Address2;
	}
	public void setAddress2(String address2) {
		Address2 = address2;
	}
	public String getStreetName() {
		return streetName;
	}
	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}
	public String getStateCode() {
		return stateCode;
	}
	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}
	public String getDistrictCode() {
		return districtCode;
	}
	public void setDistrictCode(String districtCode) {
		this.districtCode = districtCode;
	}
	public long getPinCode() {
		return pinCode;
	}
	public void setPinCode(long pinCode) {
		this.pinCode = pinCode;
	}
	public String getIntro() {
		return intro;
	}
	public void setIntro(String intro) {
		this.intro = intro;
	}
	public String getProfile() {
		return profile;
	}
	public void setProfile(String profile) {
		this.profile = profile;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getProfessionCode() {
		return professionCode;
	}
	public void setProfessionCode(String professionCode) {
		this.professionCode = professionCode;
	}
	
	public UserMasterRequestDto() {
		
	}
	public UserMasterRequestDto(String firstName, String middleName, String lastName, long primaryMobile,
			long secondaryMobile, String primaryEmail, String secondaryEmail, String address1, String address2,
			String streetName, String stateCode, String districtCode, long pinCode, String intro, String profile,
			String gender, String professionCode) {
		super();
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.primaryMobile = primaryMobile;
		this.secondaryMobile = secondaryMobile;
		this.primaryEmail = primaryEmail;
		this.secondaryEmail = secondaryEmail;
		Address1 = address1;
		Address2 = address2;
		this.streetName = streetName;
		this.stateCode = stateCode;
		this.districtCode = districtCode;
		this.pinCode = pinCode;
		this.intro = intro;
		this.profile = profile;
		this.gender = gender;
		this.professionCode = professionCode;
	}
	
	

}
