package com.user.dto;

import lombok.Data;

@Data
public class UserProfileRequestDto {
	
	private long userId;

}
