package com.geoLoc.dto;

import lombok.Data;

@Data
public class DstrictResponseDto {
	

	
	private String districtCode;
	private String districtName;
        

}
