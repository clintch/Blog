package com.blog.dto;

public class BlogPostAuthFlagRequestDto2 {
	
	private String authFlag;

	public String getAuthFlag() {
		return authFlag;
	}

	public void setAuthFlag(String authFlag) {
		this.authFlag = authFlag;
	}

	public BlogPostAuthFlagRequestDto2() {

	}
	public BlogPostAuthFlagRequestDto2(String authFlag) {
		this.authFlag = authFlag;
	}
	
	

}
