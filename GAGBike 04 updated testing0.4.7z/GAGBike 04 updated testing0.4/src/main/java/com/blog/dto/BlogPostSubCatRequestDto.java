package com.blog.dto;

public class BlogPostSubCatRequestDto {
	
	private  long parentCatId;

	public long getParentCatId() {
		return parentCatId;
	}

	public void setParentCatId(long parentCatId) {
		this.parentCatId = parentCatId;
	}
	public BlogPostSubCatRequestDto() {
		
	}

	public BlogPostSubCatRequestDto(long parentCatId) {
		this.parentCatId = parentCatId;
	}
	
}
