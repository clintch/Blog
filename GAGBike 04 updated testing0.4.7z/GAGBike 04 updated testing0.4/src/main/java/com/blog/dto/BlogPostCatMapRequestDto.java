package com.blog.dto;

public class BlogPostCatMapRequestDto {
	
	private  long  categoryId ;

	public long getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(long categoryId) {
		this.categoryId = categoryId;
	}

	public BlogPostCatMapRequestDto() {
		
	}
	public BlogPostCatMapRequestDto(long categoryId) {
		this.categoryId = categoryId;
	}
	
	
	
}
