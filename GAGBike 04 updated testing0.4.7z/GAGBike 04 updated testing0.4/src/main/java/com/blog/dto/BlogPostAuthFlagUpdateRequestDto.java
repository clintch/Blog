package com.blog.dto;

public class BlogPostAuthFlagUpdateRequestDto {
	
	private long userId;
	private long blogId;

	
	
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public long getBlogId() {
		return blogId;
	}
	public void setBlogId(long blogId) {
		this.blogId = blogId;
	}

	public BlogPostAuthFlagUpdateRequestDto() {
		
	}
	public BlogPostAuthFlagUpdateRequestDto(long userId, long blogId, String authFlag) {
		super();
		this.userId = userId;
		this.blogId = blogId;
	}

}
