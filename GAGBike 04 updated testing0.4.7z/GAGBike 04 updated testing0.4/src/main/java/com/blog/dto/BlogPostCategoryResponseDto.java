package com.blog.dto;

import lombok.Data;

public class BlogPostCategoryResponseDto {
	
	private  String  title;
	private  long    parentCatId;
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public long getParentCatId() {
		return parentCatId;
	}
	public void setParentCatId(long parentCatId) {
		this.parentCatId = parentCatId;
	}
	public BlogPostCategoryResponseDto() {
		
	}
	public BlogPostCategoryResponseDto(String title, long parentCatId) {
		this.title = title;
		this.parentCatId = parentCatId;
	}
	
	

	

}
