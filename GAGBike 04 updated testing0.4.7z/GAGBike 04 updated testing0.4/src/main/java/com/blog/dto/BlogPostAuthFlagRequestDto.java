package com.blog.dto;

import lombok.Data;
@Data
public class BlogPostAuthFlagRequestDto {
	
	private long userId;
	private String authFlag;
	private String status;
	
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	
	public String getAuthFlag() {
		return authFlag;
	}
	public void setAuthFlag(String authFlag) {
		this.authFlag = authFlag;
	}
	public BlogPostAuthFlagRequestDto() {
		
	}
	public BlogPostAuthFlagRequestDto(long userId, String authFlag, String status) {
		super();
		this.userId = userId;
		this.authFlag = authFlag;
		this.status = status;
	}
	


}
