package com.blog.dto;

import lombok.Data;

@Data
public class BlogPostByBlogIdRequestDto {
	
	private long blogId;

}
