package com.blog.dto;

import java.util.Date;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

public class BlogPostStatusUpdateRequestDto {
	
	private long userId;
	private long blogId;
	private String status;
	
	
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public long getBlogId() {
		return blogId;
	}
	public void setBlogId(long blogId) {
		this.blogId = blogId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public BlogPostStatusUpdateRequestDto() {
		
	}
	public BlogPostStatusUpdateRequestDto(long userId, long blogId, String status) {
		super();
		this.userId = userId;
		this.blogId = blogId;
		this.status = status;
	}
	
}
