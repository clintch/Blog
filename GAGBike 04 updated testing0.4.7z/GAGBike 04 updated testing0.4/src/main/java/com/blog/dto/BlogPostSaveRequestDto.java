package com.blog.dto;

import lombok.Data;
@Data
public class BlogPostSaveRequestDto {

	private long userId;
	private String title;
	private String metaTitle;
	private String slug;
	private String summary;
	private String status;
	private String content;
	
	private  String  url;
	
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getMetaTitle() {
		return metaTitle;
	}
	public void setMetaTitle(String metaTitle) {
		this.metaTitle = metaTitle;
	}
	public String getSlug() {
		return slug;
	}
	public void setSlug(String slug) {
		this.slug = slug;
	}
	public String getSummary() {
		return summary;
	}
	public void setSummary(String summary) {
		this.summary = summary;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getContent() {
		return content;
	}
	public BlogPostSaveRequestDto() {
		
	}
	public void setContent(String content) {
		this.content = content;
	}
	public BlogPostSaveRequestDto(long userId, String title, String metaTitle, String slug, String summary, String status,
			String content) {
		super();
		this.userId = userId;
		this.title = title;
		this.metaTitle = metaTitle;
		this.slug = slug;
		this.summary = summary;
		this.status = status;
		this.content = content;
	}
	public BlogPostSaveRequestDto(long userId, String title, String metaTitle, String slug, String summary,
			String status, String content, String url) {
		super();
		this.userId = userId;
		this.title = title;
		this.metaTitle = metaTitle;
		this.slug = slug;
		this.summary = summary;
		this.status = status;
		this.content = content;
		this.url = url;
	}

	

}
