package com.blog.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;
@Repository
public class BlogPostStatusUpdateDao {

    @PersistenceContext
    private EntityManager em;
    
    @Transactional
    public void updateBlogPostStatus(long userId,long blogId, String status) {
    	
    	Query qry= em.createQuery("UPDATE BlogPost t1 SET t1.status = :status WHERE t1.userId = :userId AND t1.blogId =: blogId");
	    	qry.setParameter("status", status);
	    	qry.setParameter("userId", userId);
	    	qry.setParameter("blogId", blogId);
		    qry.executeUpdate();
		    }
    }
