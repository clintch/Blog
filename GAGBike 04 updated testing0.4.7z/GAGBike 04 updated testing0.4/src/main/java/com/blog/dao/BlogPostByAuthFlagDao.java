package com.blog.dao;

import com.blog.dto.BlogPostResponseDto;
import com.blog.model.*;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.LockModeType;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.LockModeType;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;
@Repository
public class BlogPostByAuthFlagDao {

    @PersistenceContext
    private EntityManager em;
    
    
    @Transactional
    public List<BlogPage> getAllBlogByAuthFlag( String authFlag) {
    	  //TypedQuery<BlogPost> query = em.createQuery("SELECT c FROM BlogPost c ", BlogPost.class);
    		 // List<BlogPost> results = query.getResultList();
    		
    		  String queryStr =
    				  
    			      "SELECT NEW com.blog.model.BlogPage(c.blogId,c.userId,d.firstName,d.lastName,c.parentId,c.title,c.metaTitle,c.slug,c.summary,c.published,c.createdAt,c.updatedAt,c.publishedAt,c.replyCount,c.likeCount,c.viewCount,c.status,c.authFlag,c.authUser,c.authDate ,c.content) FROM BlogPost c JOIN UserMaster d ON c.userId = d.userId where c.authFlag = :authFlag AND c.status = 'A'";
    		  
    		  TypedQuery<BlogPage> query =
    			      em.createQuery(queryStr, BlogPage.class);
    			//  List<BlogPage> results = query.getResultList();
    			 List<BlogPage> results =  query.setParameter("authFlag", authFlag).getResultList();
    			  return results;
    	//	  return results;
    }


    @Transactional
	  public List<BlogPage> getAllBlogByFlagStatus() {
	    	  TypedQuery<BlogPage> query = em.createQuery("SELECT NEW com.blog.model.BlogPage(c.blogId,c.userId,d.firstName,d.lastName,c.parentId,c.title,c.metaTitle,c.slug,c.summary,c.published,c.createdAt,c.updatedAt,c.publishedAt,c.replyCount,c.likeCount,c.viewCount,c.status,c.authFlag,c.authUser,c.authDate ,c.content) FROM BlogPost c JOIN UserMaster d ON c.userId = d.userId where c.authFlag = 'P' AND c.status = 'A'", BlogPage.class);
	    		  List<BlogPage> results = query.getResultList();
	    		  return results;
	    }


	 @Transactional
	 public List<BlogPage> getAllBlogByAuthStatusUserId(long userId) {
	        		
	    		  String queryStr = //"SELECT NEW com.blog.dto.BlogPostResponseDto(c.userId,u.userDetails) FROM BlogPost c INNER JOIN UserMaster u ON c.userId = u.userId WHERE c.userId =:userId";
	    		 
	    		  // select  p.user_id, p.title, pc.user_id, pc.add_date from blog_post as p join user_master as pc  order by p.user_id
	    			      "SELECT NEW com.blog.model.BlogPage(c.blogId,c.userId,d.firstName,d.lastName,c.parentId,c.title,c.metaTitle,c.slug,c.summary,c.published,c.createdAt,c.updatedAt,c.publishedAt,c.replyCount,c.likeCount,c.viewCount,c.status,c.authFlag,c.authUser,c.authDate ,c.content) FROM BlogPost c JOIN UserMaster d ON c.userId = d.userId where c.authFlag = 'P' AND c.status = 'A' AND c.userId = :userId";
	    		System.out.println("userId----------------"+userId);  
	    		  TypedQuery<BlogPage> query =
	    			      em.createQuery(queryStr, BlogPage.class);
	    			//  List<BlogPage> results = query.getResultList();
	    		 // javax.persistence.LockModeType lockMode = LockModeType.OPTIMISTIC_FORCE_INCREMENT;
	    			 List<BlogPage> results =  query.setParameter("userId", userId).getResultList();
	    			  return results;
	    	//	  return results;
	    }
	 
	 
	 @Transactional
	 public long getCountAllBlogsAuthFlagPending(){
		  TypedQuery<Long> query = em.createQuery("SELECT count(c) FROM BlogPost c  where c.authFlag = 'P' AND c.status = 'A'", Long.class);
		  Long results = query.getSingleResult();
		  return results;
		 
	 }
	 
	 
	 @Transactional
	 public long getCountAllBlogsAuthFlagActive(){
		  TypedQuery<Long> query = em.createQuery("SELECT count(c) FROM BlogPost c  where c.authFlag = 'A' AND c.status = 'A'", Long.class);
		  Long results = query.getSingleResult();
		  return results;
		 
	 }
	 

}

	/*
	  @Transactional
	  public List<BlogPage> getAllBlogByAuthFlag2(long userId, String authFlag, String status) {
	    	
	    	Query qry= em.createQuery("SELECT NEW com.blog.model.BlogPage(c.blogId,c.userId,d.firstName,d.lastName,c.parentId,c.title,c.metaTitle,c.slug,c.summary,c.published,c.createdAt,c.updatedAt,c.publishedAt,c.replyCount,c.likeCount,c.viewCount,c.status,c.authFlag,c.authUser,c.authDate ,c.content) FROM BlogPost c JOIN UserMaster d ON c.userId = d.userId where c.authFlag = :authFlag, c.userId= :userId , c.status = :status");
		    	
		    	qry.setParameter("userId", userId);
		    	qry.setParameter("authFlag", authFlag);
		    	qry.setParameter("status", status);
			    qry.executeUpdate();
				return null;
			    }
		*/  


//@Transactional
//public List<BlogPageTwo> getAllBlgByAuthFlg( String authFlag) {
//	  //TypedQuery<BlogPost> query = em.createQuery("SELECT c FROM BlogPost c ", BlogPost.class);
//		 // List<BlogPost> results = query.getResultList();
//		
//		  String queryStr =
//			      "SELECT NEW com.blog.model.BlogPageTwo(c.blogId,c.userId,d.firstName,d.lastName,c.parentId,c.title,c.metaTitle,c.slug,c.summary,c.published,c.createdAt,c.updatedAt,c.publishedAt,c.replyCount,c.likeCount,c.viewCount,c.status,c.authFlag,c.authUser,c.authDate ,c.content) FROM BlogPost c JOIN UserMaster d ON c.userId = d.userId where c.authFlag = :authFlag";
//		  
//		  TypedQuery<BlogPageTwo> query =
//			      em.createQuery(queryStr, BlogPageTwo.class);
//			//  List<BlogPage> results = query.getResultList();
//			 List<BlogPageTwo> results =  query.setParameter("authFlag", authFlag).getResultList();
//			  return results;
//	//	  return results;
//}
//
//}