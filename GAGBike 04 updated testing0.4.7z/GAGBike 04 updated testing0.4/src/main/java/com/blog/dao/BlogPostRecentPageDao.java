package com.blog.dao;

import com.blog.model.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BlogPostRecentPageDao extends JpaRepository<BlogPost,Long>{


//	@Query("SELECT c.blogId,c.metaTitle FROM BlogPost AS c")
//    public List<String> findBlogId();


}
