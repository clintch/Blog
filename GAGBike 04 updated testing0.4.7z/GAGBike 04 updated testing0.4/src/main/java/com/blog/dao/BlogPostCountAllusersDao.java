package com.blog.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;

import com.blog.model.BlogPost;
import com.user.model.UserMaster;

@Repository
public class BlogPostCountAllusersDao {

    @PersistenceContext
    private EntityManager em;
    
 /*
  
    
    @Transactional
    public long getUsersCount() {
    		  String queryStr = "SELECT count(um) FROM UserMaster um JOIN UserLoginRoles ur ON um.userId = ur.userId WHERE ur.roleId = '1' OR ur.roleId = '2'";
    		  TypedQuery query =  (TypedQuery) em.createQuery(queryStr);
    		  long results =  (long) query.getSingleResult();
    			  return results;

    }
    */
    
    public long getUsersCount() {
		  String queryStr = "SELECT count(distinct um) FROM UserMaster um JOIN UserLoginRoles ur ON um.userId = ur.userId WHERE ur.roleId = '1' OR ur.roleId = '2'";
		  TypedQuery<Long> query =   em.createQuery(queryStr, Long.class);
		  long results =  query.getSingleResult();
			  return results;
		  
    
    }
    
    public long getAuthUsersCount() {
		  String queryStr = "SELECT count(distinct um) FROM UserMaster um JOIN UserLoginRoles ur ON um.userId = ur.userId WHERE  ur.roleId = '2'";
		  TypedQuery<Long> query =   em.createQuery(queryStr, Long.class);
		  long results =  query.getSingleResult();
			  return results;
		  
  
  }
    
}
