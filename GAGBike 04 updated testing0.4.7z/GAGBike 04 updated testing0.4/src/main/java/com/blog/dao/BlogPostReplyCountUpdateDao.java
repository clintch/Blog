package com.blog.dao;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;
@Repository
public class BlogPostReplyCountUpdateDao {

    @PersistenceContext
    private EntityManager em;
    
    @Transactional
    public void updateReplayCount(long blogId) {
    	
//		  Query query= em.createQuery("UPDATE BlogPost t1 SET t1.replyCount = (SELECT COUNT(a.parentId) + COUNT(distinct b.parentId) FROM BlogPostParentComment AS a JOIN  BlogPostChildComment AS b ON a.blogId = b.blogId ) WHERE t1.blogId =:blogId");
////(SELECT COUNT( a.parentId)+COUNT(distinct b.parentId) FROM BlogPostParentComment AS a JOIN  BlogPostChildrenComment AS b ON a.parentId = b.parentId WHERE a.blog_id =1)	
//		  
//		  //SELECT COUNT(DISTINCT a.parent_id),COUNT( DISTINCT b.childd) FROM BlogPostParentComment AS a JOIN  BlogPostChildComment AS b ON  a.blogId = b.blogId = :blogId WHERE  a.blogId = :blogId
//		  query.setParameter("blogId", blogId);
//	       query.executeUpdate();
//    }
//}


Query query2= em.createQuery("UPDATE BlogPost t1 SET t1.replyCount = (SELECT COUNT( a.parentId) FROM BlogPostParentComment AS a WHERE a.blogId = :blogId)+(SELECT COUNT( b.parentId) FROM BlogPostChildComment AS b WHERE b.blogId = :blogId) WHERE t1.blogId = :blogId");
//(SELECT COUNT( a.parentId)+COUNT(distinct b.parentId) FROM BlogPostParentComment AS a JOIN  BlogPostChildrenComment AS b ON a.parentId = b.parentId WHERE a.blog_id =1)	       
		  
		  query2.setParameter("blogId", blogId);
	       query2.executeUpdate();
  }
}

