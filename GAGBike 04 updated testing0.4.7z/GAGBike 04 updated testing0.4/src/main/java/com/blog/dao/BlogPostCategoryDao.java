package com.blog.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.print.attribute.standard.Media;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;

import com.blog.dto.BlogPostCategoryResponseDto;
import com.blog.model.BlogCategoryMaster;
import com.blog.model.BlogPost;

@Repository
public class BlogPostCategoryDao {
	
    @PersistenceContext
    private EntityManager em;
	
	 @Transactional
	  public List<BlogPostCategoryResponseDto> getAllBlogCategory() {
	    	  TypedQuery<BlogPostCategoryResponseDto> query = em.createQuery("SELECT DISTINCT  NEW com.blog.dto.BlogPostCategoryResponseDto(bc.title,bc.parentCatId) FROM BlogCategoryMaster AS bc ", BlogPostCategoryResponseDto.class);
	    	  List<BlogPostCategoryResponseDto> results = query.getResultList();
	    		  return results;
	    }

	public List<BlogCategoryMaster> getAllBlogSubCategories(long parentCatId) {
		 TypedQuery<BlogCategoryMaster> query = em.createQuery("SELECT bc FROM BlogCategoryMaster AS bc WHERE bc.parentCatId = :parentCatId", BlogCategoryMaster.class);
		    List<BlogCategoryMaster> results = query.setParameter("parentCatId", parentCatId).getResultList();
		    return results;
		    
	}

	public List<BlogPost> getAllBlogsByCategories(long categoryId) {
		TypedQuery<BlogPost> query = em.createQuery("SELECT  DISTINCT bp FROM BlogPost AS bp JOIN BlogPostCategoryMap AS bcm ON bp.blogId = bcm.blogId  WHERE bcm.categoryId = :categoryId", BlogPost.class);
		List<BlogPost> results = query.setParameter("categoryId", categoryId).getResultList();
	    return results;
	}

	

}
