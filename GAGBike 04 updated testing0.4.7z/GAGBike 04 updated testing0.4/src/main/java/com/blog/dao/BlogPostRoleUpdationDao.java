package com.blog.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;
@Repository
public class BlogPostRoleUpdationDao {
	



    @PersistenceContext
    private EntityManager em;
    
    @Transactional
    public void userRoleUpdation(long userId,long roleId) {
    	
    	Query qry= em.createNativeQuery("INSERT INTO user_login_roles (user_id , role_id) VALUES (:userId , :roleId);");
	    	qry.setParameter("userId", userId);
	    	qry.setParameter("roleId", roleId);
		    qry.executeUpdate();
		    }
    



//    
//    @Transactional
//    public void insertWithQuery(Person person) {
//        entityManager.createNativeQuery("INSERT INTO person (id, first_name, last_name) VALUES (?,?,?)")
//          .setParameter(1, person.getId())
//          .setParameter(2, person.getFirstName())
//          .setParameter(3, person.getLastName())
//          .executeUpdate();
//    }
    
}


//insert into user_login_roles  (user_id,role_id) values ('1','4')