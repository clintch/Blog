package com.blog.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.blog.model.BlogPost;
@Repository
public interface SingleBlogPostWithCommentDao extends JpaRepository<BlogPost, Long> {

	public BlogPost findById(long blogId);
	
	
	
//	@Query("SELECT new com.blog.model.SampleModel(COUNT(c.blogId)+1) FROM BlogPost AS c")  //wrked
//    public List<SampleModel> findBlogId(); 

}
