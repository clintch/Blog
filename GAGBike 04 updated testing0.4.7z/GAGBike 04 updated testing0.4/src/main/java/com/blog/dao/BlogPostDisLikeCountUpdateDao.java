package com.blog.dao;

import com.blog.model.*;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;
@Repository
public class BlogPostDisLikeCountUpdateDao {

    @PersistenceContext
    private EntityManager em;
    
 
    @Transactional
    public void updateDisLikeCount(long blogId) {
    	
    	Query qry= em.createQuery("UPDATE BlogPost t1 SET t1.likeCount = (SELECT COUNT( a.type)-1 FROM BlogPostLike AS a WHERE a.blogId = :blogId AND a.type = '1') WHERE t1.blogId = :blogId");
			qry.setParameter("blogId", blogId);
			qry.executeUpdate();
			
    }
    
    @Transactional
    public long disLikeCountReturn(long blogId) {

    		
    		  String queryStr = "SELECT a FROM BlogPost AS a WHERE a.blogId = :blogId";
    		  TypedQuery<BlogPost> query = em.createQuery(queryStr, BlogPost.class);
    		  BlogPost results =  query.setParameter("blogId", blogId).getSingleResult();
    			  return results.getLikeCount();
    }
	
    
}

