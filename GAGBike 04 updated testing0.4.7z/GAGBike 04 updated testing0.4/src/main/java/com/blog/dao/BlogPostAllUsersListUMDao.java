package com.blog.dao;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;
import com.user.model.UserMaster;
@Repository
public class BlogPostAllUsersListUMDao {

    @PersistenceContext
    private EntityManager em;
    
 
    @Transactional
    public List<UserMaster> getUserList() {
    	
    	String queryStr = "SELECT DISTINCT um FROM UserMaster um JOIN UserLoginRoles ur ON um.userId = ur.userId WHERE ur.roleId = '1' OR ur.roleId = '2' ";
    		 TypedQuery<UserMaster> query =
    			      em.createQuery(queryStr, UserMaster.class);
    			  List<UserMaster> results = query.getResultList();	
    			  return results;
    }
}
    			  
    			  
   /*
    for (UserMaster c : results) {
        System.out.println(c.getFirstName());
    }
    return results;
    }
    */
     


