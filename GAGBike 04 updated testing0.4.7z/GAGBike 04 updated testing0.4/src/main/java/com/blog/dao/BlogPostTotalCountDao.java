package com.blog.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;
@Repository
public class BlogPostTotalCountDao {

    @PersistenceContext
    private EntityManager em;
    
    @Transactional
    public void updateBlogPostCount(long userId) {
    	
    	Query qry= em.createQuery("UPDATE UserMaster t1 SET t1.blogCount = (SELECT COUNT(a.blogId) FROM BlogPost AS a WHERE a.userId = :userId) WHERE t1.userId = :userId");
	    	qry.setParameter("userId", userId);
		    qry.executeUpdate();
		    }
    

    @Transactional
    public void updateBlogPostAuthFlag(long userId) {
    
    	Query qry= em.createQuery("UPDATE UserMaster t1 SET t1.authFlag = 'Y' WHERE t1.blogCount>5 AND t1.userId = :userId");
	    	qry.setParameter("userId", userId);
		    qry.executeUpdate();
		    }
    	
    }
    
