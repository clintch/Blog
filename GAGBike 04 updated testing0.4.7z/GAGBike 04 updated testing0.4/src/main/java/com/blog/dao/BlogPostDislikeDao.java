package com.blog.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;
@Repository
public class BlogPostDislikeDao {

    @PersistenceContext
    private EntityManager em;
    
    @Transactional
    public void updateBlogPostDislike(long userId,long blogId) {
    	
//    	Query qry= em.createQuery("UPDATE BlogPostLike t1 SET t1.type = '0' WHERE t1.userId = :userId  AND t1.blogId = :blogId" );
//	    	qry.setParameter("userId", userId);
//	    	qry.setParameter("blogId" ,blogId);
//		    qry.executeUpdate();
//		    }
    	
    	Query qry= em.createQuery("DELETE FROM BlogPostLike AS t1 WHERE t1.userId = :userId  AND t1.blogId = :blogId" );
    	qry.setParameter("userId", userId);
    	qry.setParameter("blogId" ,blogId);
	    qry.executeUpdate();
	    }

	
    }
