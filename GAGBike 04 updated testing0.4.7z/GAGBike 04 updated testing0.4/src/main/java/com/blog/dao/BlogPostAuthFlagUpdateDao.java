package com.blog.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;
@Repository
public class BlogPostAuthFlagUpdateDao {

    @PersistenceContext
    private EntityManager em;
    
    @Transactional
    public void updateBlogPostAuthFlag(long userId,long blogId) {
    	
    	Query qry= em.createQuery("UPDATE BlogPost t1 SET t1.authFlag = 'A', t1.authUser = convert(:userId,CHAR), t1.published = '1', t1.authDate = now() , t1.publishedAt = now(),t1.updatedAt = now() WHERE t1.userId = :userId AND t1.blogId = :blogId");
	    	//qry.setParameter("authFlag", authFlag);
	    	qry.setParameter("userId", userId);
	    	qry.setParameter("blogId", blogId);
		    qry.executeUpdate();
		    }
    }
    
