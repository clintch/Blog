package com.blog.service;

import java.util.List;

import javax.print.attribute.standard.Media;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.blog.dao.BlogPostCategoryDao;
import com.blog.dto.BlogPostCategoryResponseDto;
import com.blog.model.BlogCategoryMaster;
import com.blog.model.BlogPost;

@Service
public class BlogPostCategoryService {
	
	@Autowired
	BlogPostCategoryDao blogPostCategoryDao;
	
	public List<BlogPostCategoryResponseDto> getAllBlogCategory() {
		return blogPostCategoryDao.getAllBlogCategory();
	}


	public List<BlogCategoryMaster> getAllBlogSubCategories(long parentCatId) {
		return blogPostCategoryDao.getAllBlogSubCategories(parentCatId);
	}


	public List<BlogPost> getAllBlogsByCategories() {
		// TODO Auto-generated method stub
		return null;
	}


	public List<BlogPost> getAllBlogsByCategories(long categoryId) {
		return blogPostCategoryDao.getAllBlogsByCategories(categoryId);
	}




}
