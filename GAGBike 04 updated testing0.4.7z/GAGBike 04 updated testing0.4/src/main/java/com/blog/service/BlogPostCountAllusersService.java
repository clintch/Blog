package com.blog.service;

import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.blog.dao.BlogPostCountAllusersDao;


@Service
public class BlogPostCountAllusersService {
	
	@Autowired
	BlogPostCountAllusersDao blogPostCountAllusersDao;
	
	
	   public long getUsersCount() {
		   return blogPostCountAllusersDao.getUsersCount();
	   }
	  
	    
	    public long getAuthUsersCount() {
	    	return blogPostCountAllusersDao.getAuthUsersCount();
	    }

}
