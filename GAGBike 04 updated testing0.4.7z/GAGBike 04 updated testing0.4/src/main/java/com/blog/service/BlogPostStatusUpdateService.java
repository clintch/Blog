package com.blog.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.blog.dao.BlogPostStatusUpdateDao;

@Service
public class BlogPostStatusUpdateService {
	
	@Autowired
	BlogPostStatusUpdateDao blogPostStatusUpdateDao;
	
	
	 public void updateBlogPostCount(long userId,long blogId, String status) {
		 blogPostStatusUpdateDao.updateBlogPostStatus(userId, blogId, status);
		 
	 }

}
