package com.blog.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.blog.dao.BlogPostByAuthFlagDao;
import com.blog.dto.BlogPostResponseDto;
import com.blog.model.BlogPage;
import com.blog.model.BlogPost;
@Service
public class BlogPostAuthFlagService {
	
	@Autowired
	BlogPostByAuthFlagDao  blogPostByAuthFlagDao;
	
//	@Autowired
//	public BlogAuthFlagService (BlogByAuthFlag  blogByAuthFlag ) {
//		this.blogByAuthFlag = blogByAuthFlag;
//	}
//	
	
	/*
	 public List<BlogPage> getAllBlogByAuthFlag2(long userId, String authFlag, String status){
		    return blogPostByAuthFlagDao.getAllBlogByAuthFlag2(userId,authFlag,status);
		    
		}
*/
	public List<BlogPage> getAllBlogByAuthFlag(String authFlag) {
		return blogPostByAuthFlagDao.getAllBlogByAuthFlag(authFlag);
	}

	
	public List<BlogPage> getAllBlogByFlagStatus() {
		return blogPostByAuthFlagDao.getAllBlogByFlagStatus();
	}



	public List<BlogPage> getAllBlogByAuthStatusUserId(long userId) {
		return blogPostByAuthFlagDao.getAllBlogByAuthStatusUserId(userId);
	}
	
	public long getCountAllBlogsAuthFlagPending(){
		return blogPostByAuthFlagDao.getCountAllBlogsAuthFlagPending();
	}
	
	public long getCountAllBlogsAuthFlagActive(){
		return blogPostByAuthFlagDao.getCountAllBlogsAuthFlagActive();
	}

//	public List<BlogPage> getByFlag(String authFlag){
//			return blogByAuthFlag.getAllBlogByAuthFlag(authFlag);
//		}


}
