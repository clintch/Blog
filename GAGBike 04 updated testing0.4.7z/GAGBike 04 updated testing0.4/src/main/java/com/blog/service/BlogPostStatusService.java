package com.blog.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.blog.dao.BlogPostByStatusDao;
import com.blog.model.BlogPage;
@Service
public class BlogPostStatusService {
	
	@Autowired
	BlogPostByStatusDao blogPostByStatusDao;
	
	public List<BlogPage> getAllBlogs(long userId,String status){
		return blogPostByStatusDao.getAllBlogs(userId,status);
		
	}

}
