package com.blog.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.blog.dao.BlogPostVideosUrlsDao;
import com.blog.model.BlogVideosUrls;

@Service
public class BlogPostVideosUrlsService {
	
	@Autowired
	BlogPostVideosUrlsDao blogPostVideosUrlsDao;

	public void saveBlogPostVideosUrls(BlogVideosUrls blogVideosUrls) {
		blogPostVideosUrlsDao.save(blogVideosUrls);
		
	}
	
	

}
