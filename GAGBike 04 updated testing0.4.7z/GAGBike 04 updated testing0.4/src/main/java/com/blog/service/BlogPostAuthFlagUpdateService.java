package com.blog.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.blog.dao.BlogPostAuthFlagUpdateDao;

@Service
public class BlogPostAuthFlagUpdateService {
	
	
	@Autowired
	BlogPostAuthFlagUpdateDao blogPostAuthFlagUpdateDao;
	
	
//	 public void updateBlogPostAuthFlag(long userId,long blogId, String authFlag) {
//		 blogPostAuthFlagUpdateDao.updateBlogPostAuthFlag(userId, blogId, authFlag);
//		 
//	 }


	public void updateBlogPostAuthFlag(long userId, long blogId) {
		 blogPostAuthFlagUpdateDao.updateBlogPostAuthFlag(userId, blogId);
		
	}

}
