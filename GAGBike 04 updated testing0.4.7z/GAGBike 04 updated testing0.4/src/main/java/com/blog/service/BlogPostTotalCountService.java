package com.blog.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.blog.dao.BlogPostTotalCountDao;

@Service
public class BlogPostTotalCountService {
	
	@Autowired
	BlogPostTotalCountDao blogPostTotalCountDao;
	
	 public void updateBlogPostCount(long userId) {
		 blogPostTotalCountDao.updateBlogPostCount(userId);
	 }
	 

	 public void updateBlogPostAuthFlag(long userId) {
		 blogPostTotalCountDao.updateBlogPostAuthFlag(userId);
	 }
	

}
