package com.blog.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.blog.dao.BlogPostRoleUpdationDao;

@Service
public class BlogPostRoleUpdationService {
	
	@Autowired
	BlogPostRoleUpdationDao blogPostRoleUpdationDao;
	
	 public void userRoleUpdation(long userId,long roleId) {
		 blogPostRoleUpdationDao.userRoleUpdation(userId, roleId);
	 }



}
