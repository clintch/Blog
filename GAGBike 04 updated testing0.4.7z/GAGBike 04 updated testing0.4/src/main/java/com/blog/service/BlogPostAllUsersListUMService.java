package com.blog.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.blog.dao.BlogPostAllUsersListUMDao;
import com.blog.model.BlogPost;
import com.user.model.UserLoginRoles;
import com.user.model.UserMaster;

@Service
public class BlogPostAllUsersListUMService {
	@Autowired
	BlogPostAllUsersListUMDao blogPostAllUsersListUMDao;
	
	public List<UserMaster> getUserList() {
		return blogPostAllUsersListUMDao.getUserList();
	}
	

}
