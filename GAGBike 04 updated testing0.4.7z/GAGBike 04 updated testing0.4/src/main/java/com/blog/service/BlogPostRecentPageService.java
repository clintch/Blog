package com.blog.service;

import java.util.List;
import java.util.Optional;

import com.blog.dao.BlogPostRecentPageDao;
import com.blog.model.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
public class BlogPostRecentPageService {
	
	private final BlogPostRecentPageDao BlogPostRecentPageDao;
	
	
	
	@Autowired
	public BlogPostRecentPageService (BlogPostRecentPageDao BlogPostRecentPageDao ) {
		this.BlogPostRecentPageDao = BlogPostRecentPageDao;
		
}
	public List<BlogPost> findAll(){
		return BlogPostRecentPageDao.findAll();
	}
	
	
	
	public Optional <BlogPost> findById(Long blogId){
		return BlogPostRecentPageDao.findById(blogId);
		
	}
	 
	public BlogPost save (BlogPost RecentPg) {
		return BlogPostRecentPageDao.save(RecentPg);
	}
	
	
	public void deleteById(Long blogId) {
		BlogPostRecentPageDao.deleteById(blogId);
		
	}
	public Page<BlogPost> findAll(Pageable pagingSort) {
		
		return BlogPostRecentPageDao.findAll(pagingSort);
		
	}

	

	
	
	
//	
//	public List<BlogPage> getBlogDetail(long userId){
//		return BlogRecentPageDao.getBlogId(userId);
//	}
//	public List<BlogPage> getBlogId(long userId) {
//		return BlogPageDao.getBlogId(userId);
//	}
//	

}
