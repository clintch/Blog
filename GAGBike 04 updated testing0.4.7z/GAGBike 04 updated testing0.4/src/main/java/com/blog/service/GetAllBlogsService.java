package com.blog.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.blog.dao.GetAllBlogsDao;
import com.blog.model.BlogPost;

@Service
public class GetAllBlogsService {
	
	@Autowired
	GetAllBlogsDao getAllBlogsDao;
	
	
	 public List<BlogPost> getAllBlogs() {
		 return getAllBlogsDao.getAllBlogs();
		 
	 }
	 
	

}
