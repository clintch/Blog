package com.blog.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.blog.dao.BlogPostBlogIdDao;
import com.blog.model.BlogPage;
import com.blog.model.BlogPost;

@Service
public class BlogPostByBlogIdService {
	
	@Autowired
	BlogPostBlogIdDao  blogPostBlogIdDao;
	
	public BlogPost getBlogByBlogId(long blogId) {
		return blogPostBlogIdDao.getBlogId(blogId);
	}

	

}
