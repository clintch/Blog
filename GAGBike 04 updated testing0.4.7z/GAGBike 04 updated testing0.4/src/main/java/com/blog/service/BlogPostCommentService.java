package com.blog.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.blog.dao.BlogPostChildCommentDao;
import com.blog.dao.BlogPostDeleteCommentDao;
import com.blog.dao.BlogPostParentCommentDao;
import com.blog.model.BlogPostChildComment;
import com.blog.model.BlogPostParentComment;

@Service
public class BlogPostCommentService {
	
	@Autowired
	BlogPostParentCommentDao blogPostParentCommentDao;
	
	@Autowired
	BlogPostChildCommentDao blogPostChildCommentDao;
	
	@Autowired
	BlogPostCommentUpdateService blogPostCommentUpdateService;
	
	@Autowired
	BlogPostDeleteCommentDao blogPostDeleteCommentDao;
	
	
//	@Autowired
//	BlogChildCommentUpdateService blogChildComment;
//	
//	public void insert(BlogPostComment blogPostComment) {
//		blogParentCommentSave.save(blogPostComment);
//    }
//	
	
	public void save(BlogPostParentComment blogPostParentComment) {
		//blogCommentUpdateService.countOfBlogId(blogPostParentComment.getBlogId());
		 blogPostParentComment.setStatus("A");
		 blogPostParentComment.setAuthFlag("A");
		 blogPostParentComment.setAuthUser("authUser");
		 blogPostParentComment.setLikeCount(0);
		 blogPostParentComment.setPublished(1);
		 blogPostParentComment.setTitle("Parent Title");
		blogPostParentCommentDao.save(blogPostParentComment);
		blogPostCommentUpdateService.updateReplayCount(blogPostParentComment.getBlogId());
    }
	
	public void save(BlogPostChildComment blogPostChildComment) {
		//blogCommentUpdateService.countOfBlogId(blogPostChildComment.getBlogId());
		blogPostChildComment.setStatus("A");
		blogPostChildComment.setAuthFlag("A");
		blogPostChildComment.setAuthUser("authUser");
		blogPostChildComment.setLikeCount(0);
		blogPostChildComment.setPublished(1);
		blogPostChildComment.setTitle("Child Title");
		blogPostChildCommentDao.save(blogPostChildComment);
		blogPostCommentUpdateService.updateReplayCount(blogPostChildComment.getBlogId());
		//blogChildComment.countOfChildId(blogPostChildComment.getBlogId());
    }

	 public void deleteParentComment(long blogId,long parentId) {
		blogPostDeleteCommentDao.deleteParentComment(blogId, parentId);
		blogPostCommentUpdateService.updateReplayCount(blogId);
		
	}
	 
	public void deleteChildComment(long blogId,long childId) {
		blogPostDeleteCommentDao.deleteChildComment(blogId, childId);
		blogPostCommentUpdateService.updateReplayCount(blogId);
	}

//	public BlogPostComment save(BlogPostComment blogPostComment) {
//		return blogParentCommentSave.save(blogPostComment);
//	}

//	public void save(BlogParentComment blogParentComment) {
//		blogSaveComment.save(blogParentComment);
//		
//	}
//	
//	public BlogParentComment save(BlogParentComment blogParentComment) {
//		return blogParentCommentSave.save(blogParentComment);
//		 
//		
//	}
//	public BlogChildComment save(BlogChildComment blogChildComment) {
//		return blogReplyCountUpdate.save(blogChildComment);
//		 
//		
//	}
	

}
