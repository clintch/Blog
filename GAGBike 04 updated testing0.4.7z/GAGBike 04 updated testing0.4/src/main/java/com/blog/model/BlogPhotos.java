package com.blog.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "blog_photos")
@NoArgsConstructor 
@Data
public class BlogPhotos implements Serializable{
	@Id
//	@OneToOne(cascade = CascadeType.ALL,fetch = FetchType.LAZY, orphanRemoval =true)
//	@JoinColumn(name ="blogId", referencedColumnName = "blogId")
//	private BlogPost blogPost;
	private  long   id;
	private  long   blogId;	
	private  byte   slNo;
	private  String phSourceCode;
	private  String photoBase64	;	
	private  String thumbnailFlag;
	@CreationTimestamp
	private  Date   addDate	;
	
	
}
