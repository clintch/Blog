package com.blog.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Table(name = "blog_usr_followers_map")
@NoArgsConstructor 
@Data
public class BlogUsrFollowersMap {
	
	@Id
	private   long     userId;                             
	private   long     followerId;                             
	private   String   followType;                             
	private   Date     startDate;                             
	private   Date     endDate;                             
	private   Date     addDate;                             
	private   String   status;  
	
}
