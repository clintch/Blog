package com.blog.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name = "BlogPostChildComment")
public class BlogPostChildComment implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long childId;
	private String childContent;
	private long parentId;
	private long blogId;
	
//	@OneToOne(cascade = CascadeType.ALL,fetch = FetchType.LAZY, orphanRemoval =true)
//	@JoinColumn(name ="userId", referencedColumnName = "userId")
//	private BlogPostParentComment blogPostParentComment;
	
	private long userId;
	private String title;
	private long published;
	@CreationTimestamp
	private Date createdAt;
	@UpdateTimestamp
	private Date updatedAt;
	@UpdateTimestamp
	private Date publishedAt;
	private long replyCount;
	private long likeCount;
	private String status;
	private String authFlag;
	private String authUser;
	@UpdateTimestamp
	private Date authDate;
	
	public BlogPostChildComment(long childId, String childContent, long parentId, long blogId, long userId,
			String title, long published, Date createdAt, Date updatedAt, Date publishedAt, long replyCount,
			long likeCount, String status, String authFlag, String authUser, Date authDate) {
		super();
		this.childId = childId;
		this.childContent = childContent;
		this.parentId = parentId;
		this.blogId = blogId;
		this.userId = userId;
		this.title = title;
		this.published = published;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
		this.publishedAt = publishedAt;
		this.replyCount = replyCount;
		this.likeCount = likeCount;
		this.status = status;
		this.authFlag = authFlag;
		this.authUser = authUser;
		this.authDate = authDate;
	}

	public long getBlogId() {
		return blogId;
	}

	public void setChildId(long childId) {
		this.childId = childId;
	}

	public void setChildContent(String childContent) {
		this.childContent = childContent;
	}

	public void setParentId(long parentId) {
		this.parentId = parentId;
	}

	public void setBlogId(long blogId) {
		this.blogId = blogId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public long getUserId() {
		return userId;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setPublished(long published) {
		this.published = published;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public void setPublishedAt(Date publishedAt) {
		this.publishedAt = publishedAt;
	}

	public void setReplyCount(long replyCount) {
		this.replyCount = replyCount;
	}

	public void setLikeCount(long likeCount) {
		this.likeCount = likeCount;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setAuthFlag(String authFlag) {
		this.authFlag = authFlag;
	}

	public void setAuthUser(String authUser) {
		this.authUser = authUser;
	}

	public void setAuthDate(Date authDate) {
		this.authDate = authDate;
	}

	public long getChildId() {
		return childId;
	}

	public String getChildContent() {
		return childContent;
	}

	public BlogPostChildComment() {
		
	}

	public BlogPostChildComment(long blogId, long userId, long parentId, String childContent) {
		
		this.blogId = blogId;
		this.userId = userId;
		this.parentId = parentId;
		this.childContent = childContent;
	}

	public BlogPostChildComment(long blogId, long userId, long parentId) {
		this.blogId = blogId;
		this.userId = userId;
		this.parentId = parentId;
	}
	
}  