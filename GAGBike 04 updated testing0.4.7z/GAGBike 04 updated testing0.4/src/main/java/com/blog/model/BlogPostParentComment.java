package com.blog.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

	
@Entity
@Table(name = "BlogPostParentComment")
public class BlogPostParentComment implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long parentId;
	private long blogId;
	
//	@ManyToOne
//	@JoinColumn(name ="userId",insertable = false, updatable = false)
//	private BlogPost blogPost;
	private long userId;
	//private long parentId;
	private String title;
	private long published;
	@CreationTimestamp
	private Date createdAt;
	@UpdateTimestamp
	private Date updatedAt;
	@UpdateTimestamp
	private Date publishedAt;
	private long replyCount;
	private long likeCount;
	private String status;
	private String authFlag;
	private String authUser;
	@UpdateTimestamp
	private Date authDate;
	//private String childContent;
	private String parentContent;
	
  @OneToMany(cascade = CascadeType.ALL)
  @JoinColumn(name = "parentId", referencedColumnName = "parentId")
  private List<BlogPostChildComment> children;
	
	
	public long getParentId() {
		return parentId;
	}
	
	public String getParentContent()  {
		return parentContent ;
	}
	public void setParentContent(String parentContent) {
		this.parentContent = parentContent ;
	}
	public long getBlogId() {
		return blogId;
	}
	public void setBlogId(long blogId) {
		this.blogId = blogId;
	}
	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}
	public void setParentId(long parentId) {
		this.parentId = parentId;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public void setPublished(long published) {
		this.published = published;
	}
	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}
	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}
	public void setPublishedAt(Date publishedAt) {
		this.publishedAt = publishedAt;
	}
	public void setReplyCount(long replyCount) {
		this.replyCount = replyCount;
	}
	public void setLikeCount(long likeCount) {
		this.likeCount = likeCount;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public void setAuthFlag(String authFlag) {
		this.authFlag = authFlag;
	}
	public void setAuthUser(String authUser) {
		this.authUser = authUser;
	}
	public void setAuthDate(Date authDate) {
		this.authDate = authDate;
	}
	
	

	public List<BlogPostChildComment> getChildren() {
		return children;
	}

	public void setChildren(List<BlogPostChildComment> children) {
		this.children = children;
	}

	public BlogPostParentComment(long parentId, long blogId, long userId, String title, long published, Date createdAt,
			Date updatedAt, Date publishedAt, long replyCount, long likeCount, String status, String authFlag,
			String authUser, Date authDate, String parentContent,
			List<BlogPostChildComment> children) {
		super();
		this.parentId = parentId;
		this.blogId = blogId;
		this.userId = userId;
		this.title = title;
		this.published = published;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
		this.publishedAt = publishedAt;
		this.replyCount = replyCount;
		this.likeCount = likeCount;
		this.status = status;
		this.authFlag = authFlag;
		this.authUser = authUser;
		this.authDate = authDate;
		this.parentContent = parentContent;
		this.children = children;
	}

	public BlogPostParentComment() {
		
	}

	public BlogPostParentComment(long blogId, long userId,String parentContent) {
		this.blogId = blogId;
		this.userId = userId;
		this.parentContent = parentContent;

	}
	
	
}

