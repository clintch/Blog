package com.blog.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "blog_category_master")
@NoArgsConstructor 
@Data
public class BlogCategoryMaster {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private  long    catId;	
	private  long    parentCatId;
	private  String  title;		
	private  String  metaTitle;	
	private  String  slug;		
	private  String  content;
	
	public BlogCategoryMaster(long parentCatId) {
		this.parentCatId = parentCatId;
	}
}
