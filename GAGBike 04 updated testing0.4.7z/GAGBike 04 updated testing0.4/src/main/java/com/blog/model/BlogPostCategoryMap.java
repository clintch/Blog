package com.blog.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import groovy.transform.Generated;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "blog_post_category_map")
@NoArgsConstructor 
@Data
public class BlogPostCategoryMap {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private  long  blogId ;			                                                                         
	private  long  categoryId ;
	
}
