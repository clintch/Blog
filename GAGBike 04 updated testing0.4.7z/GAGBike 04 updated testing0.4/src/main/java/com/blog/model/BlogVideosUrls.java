package com.blog.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "blog_videos_urls")
@NoArgsConstructor 
@Data
//@SequenceGenerator(name="seq", initialValue=0, allocationSize=100)
public class BlogVideosUrls {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	//@GeneratedValue(strategy = GenerationType.TABLE,generator = "seq")
	private  long    urlId;			                                                                       
	private  long    blogId;		                                                                     
	private  String  url; 
	@CreationTimestamp
	private  Date    addDate;
	
	public BlogVideosUrls(long blogId, String url) {
		this.blogId = blogId;
		this.url = url;
		
	}
	
}
