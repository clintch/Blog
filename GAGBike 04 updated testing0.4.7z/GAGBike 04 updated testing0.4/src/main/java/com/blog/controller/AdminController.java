package com.blog.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.blog.dao.BlogPostCountAllusersDao;
import com.blog.dto.BlogPostRoleUpdationDto;
import com.blog.dto.BlogPostStatusUpdateRequestDto;
import com.blog.model.BlogPage;
import com.blog.model.BlogPost;
import com.blog.service.BlogPostAllUsersListUMService;
import com.blog.service.BlogPostAuthFlagService;
import com.blog.service.BlogPostCountAllusersService;
import com.blog.service.BlogPostRoleUpdationService;
import com.user.dto.GetCountAllBlogsMonthwiseByYearRequestDto;
import com.user.dto.GetCountAllBlogsMonthwiseByYearResponseDto;
import com.user.dto.UserStatusUpdateRequestDto;
import com.user.model.UserMaster;
import com.user.service.GetCountAllBlogsMonthwiseByYearService;
import com.user.service.UserStatusUpdateService;

import io.swagger.annotations.ApiOperation;


@RestController
@CrossOrigin(origins = "*", maxAge =864000)
@RequestMapping("/admin")
public class AdminController {
	
	@Autowired
	BlogPostAllUsersListUMService blogPostAllUsersListUMService;
	
	@Autowired
	BlogPostCountAllusersService blogPostCountAllusersService;
	
	@Autowired
	BlogPostAuthFlagService blogPostAuthFlagService;
	
	@Autowired
	BlogPostRoleUpdationService blogPostRoleUpdationService;
	
	@Autowired
	UserStatusUpdateService userStatusUpdateService;
	
	@Autowired
	GetCountAllBlogsMonthwiseByYearService getCountAllBlogsMonthwiseByYearService;
	
	
/////************** get all users ****************

	
	@GetMapping("/getAllUsersAndModerators")
	@ApiOperation("get all users (ROLE = user & mod)")
	public List<UserMaster> getAllUsers(){
		return blogPostAllUsersListUMService.getUserList();
	    
	}
	
/////************** COUNT of users (ROLE = USER & MOD) ****************
	
	
	@GetMapping("/getCountAllUsersAndModerators")
	@ApiOperation("get COUNT of all users & moderators(ROLE = user & mod)")
	public long getCountAllUsers(){
		return blogPostCountAllusersService.getUsersCount();
	    
	}
	
/////************** COUNT of users (ROLE = MOD) ****************
	
	
	@GetMapping("/getCountAllAuthUsers")
	@ApiOperation("get COUNT of all users (ROLE = mod)")
	public long getCountAllAuthUsers(){
		return blogPostCountAllusersService.getAuthUsersCount();
	    
	}
	
////////------- COUNT OF BLOGS AuthFlag=P and status = A---------
	
	
	@GetMapping("/getCountAllBlogsAuthFlagPending")
	@ApiOperation("get COUNT of blogs by auth flag = P & status = A ")
	public long getCountAllBlogsAuthFlagPending(){
		return blogPostAuthFlagService.getCountAllBlogsAuthFlagPending();
	}
	
////////------- COUNT OF BLOGS AuthFlag=P and status = A---------
	
	
	@GetMapping("/getCountAllBlogsAuthFlagActive")
	@ApiOperation("get COUNT of blogs by auth flag = A & status = A ")
	public long getCountAllBlogsAuthFlagActive(){
		return blogPostAuthFlagService.getCountAllBlogsAuthFlagActive();
	}
	
////////------- User Roles Updation ---------
	
	@PostMapping(path = "/userRoleUpdation")
	@ApiOperation("users role updation (ROLE = ADMIN (3) / MOD (2) / USER (1) )")
	public String userRoleUpdation(@RequestBody BlogPostRoleUpdationDto blogPostRoleUpdationDto) throws IOException  {
		blogPostRoleUpdationService.userRoleUpdation(blogPostRoleUpdationDto.getUserId(),blogPostRoleUpdationDto.getRoleId());
		return "User Role Updated - Role Id = "+blogPostRoleUpdationDto.getRoleId();
	}
	

////////------- User Status Updation ---------	
	
	@PostMapping(path = "/userStatusUpdation")
	@ApiOperation("user status updation")
	public long userStatusUpdation(@RequestBody UserStatusUpdateRequestDto userStatusUpdate) throws IOException  {
		UserMaster usrMstrSts = new UserMaster(userStatusUpdate.getUserId(),userStatusUpdate.getStatus());
		userStatusUpdateService.userStatusUpdation(userStatusUpdate.getUserId(),userStatusUpdate.getStatus());
		return 1;
	}
	
//////------- COUNT OF BLOGS IN MONTHWISE FOR GIVEN YEAR ---------	
	
	@PostMapping(path = "/getCountAllBlogsMonthwiseByYear")
	@ApiOperation("get COUNT of blogs monthwise for year")
	public List<GetCountAllBlogsMonthwiseByYearResponseDto> getCountAllBlogsMonthwiseByYear(@RequestBody GetCountAllBlogsMonthwiseByYearRequestDto getCountAllBlogsMonthwiseByYear) throws IOException {
		
		return getCountAllBlogsMonthwiseByYearService.getCountAllBlogsMonthwiseByYear(getCountAllBlogsMonthwiseByYear.getYear());
		
	}

}
