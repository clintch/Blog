package com.blog.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.blog.dao.SingleBlogPostWithCommentDao;
import com.blog.dao.BlogPostDisLikeCountUpdateDao;
import com.blog.dao.BlogPostLikeCountUpdateDao;
import com.blog.dao.BlogPostReplyCountUpdateDao;
import com.blog.dto.BlogPostAuthFlagRequestDto2;
import com.blog.dto.BlogPostByAuthStatusUserIdRequestDto;
import com.blog.dto.BlogPostAuthFlagUpdateRequestDto;
import com.blog.dto.BlogPostByBlogIdRequestDto;
import com.blog.dto.BlogPostCatMapRequestDto;
import com.blog.dto.BlogPostCategoryResponseDto;
import com.blog.dto.BlogPostChildCommentDeleteRequestDto;
import com.blog.dto.BlogPostChildCommentRequestDto;
import com.blog.dto.BlogPostDisLikeRequestDto;
import com.blog.dto.BlogPostLikeRequestDto;
import com.blog.dto.BlogPostParentCommentDeleteRequestDto;
import com.blog.dto.BlogPostParentCommentRequestDto;
import com.blog.dto.BlogPostSaveRequestDto;
import com.blog.dto.BlogPostSlugRequestDto;
import com.blog.dto.BlogPostStatusRequestDto;
import com.blog.dto.BlogPostStatusUpdateRequestDto;
import com.blog.dto.BlogPostSubCatRequestDto;
import com.blog.dto.BlogPostVideosUrlsRequestDto;
import com.blog.model.BlogPostChildComment;
import com.blog.model.BlogPostLike;
import com.blog.model.BlogCategoryMaster;
import com.blog.model.BlogPage;
import com.blog.model.BlogPost;
import com.blog.model.BlogPostParentComment;
import com.blog.model.BlogVideosUrls;
import com.blog.service.BlogPostAuthFlagService;
import com.blog.service.BlogPostAuthFlagUpdateService;
import com.blog.service.BlogPostByBlogIdService;
import com.blog.service.BlogPostCategoryService;
import com.blog.service.BlogPostCommentService;
import com.blog.service.BlogPostCommentUpdateService;
import com.blog.service.BlogPostLikeService;
import com.blog.service.BlogPostSaveService;
import com.blog.service.BlogPostSlugService;
import com.blog.service.BlogPostStatusService;
import com.blog.service.BlogPostStatusUpdateService;
import com.blog.service.BlogPostVideosUrlsService;
import com.blog.service.GetAllBlogsService;
import com.user.dto.GetCountAllBlogsMonthwiseByYearRequestDto;
import com.user.dto.GetCountAllBlogsMonthwiseByYearResponseDto;
import com.user.service.GetCountAllBlogsMonthwiseByYearService;

import io.swagger.annotations.ApiOperation;

import com.blog.service.BlogPostRecentPageService;

@RestController
@CrossOrigin(origins = "*", maxAge =864000)
@RequestMapping("/blog")
public class BlogController {
	
	@Autowired
	BlogPostSaveService blogPostSaveService;
	
	@Autowired
	SingleBlogPostWithCommentDao blogcommentrepo;
	
	
	@Autowired
	BlogPostStatusService blogPostStatusService;

	
	@Autowired
	BlogPostReplyCountUpdateDao blogPostReplyCountUpdateDao;
	
	@Autowired
	BlogPostCommentService blogPostCommentService;
	
	@Autowired
	BlogPostCommentUpdateService blogPostCommentUpdateService;
	
	@Autowired
	BlogPostAuthFlagService blogPostAuthFlagService;
	
	@Autowired
	BlogPostSlugService blogPostSlugService;
	
	@Autowired
	BlogPostByBlogIdService blogPostByBlogIdService;
	
	@Autowired
	GetAllBlogsService getAllBlogsService;
	

	@Autowired
	BlogPostLikeService blogPostLikeService;
	
	@Autowired
	BlogPostVideosUrlsService blogPostVideosUrlsService;
	
	
	@Autowired
	BlogPostLikeCountUpdateDao blogPostLikeCountUpdateDao;
	
	@Autowired
	BlogPostDisLikeCountUpdateDao blogPostDisLikeCountUpdateDao;
	
	@Autowired
	BlogPostStatusUpdateService blogPostStatusUpdateService;
	
	@Autowired
	BlogPostAuthFlagUpdateService blogPostAuthFlagUpdateService;
	
	@Autowired
	BlogPostCategoryService blogPostCategoryService;
	
		
private final BlogPostRecentPageService BlogPostRecentPageService;
	
	@Autowired
	public BlogController(BlogPostRecentPageService BlogPostRecentPageService) {
		this.BlogPostRecentPageService = BlogPostRecentPageService;
	}
	
	
	
	 private Sort.Direction getSortDirection(String direction) {
		    if (direction.equals("asc")) {
		      return Sort.Direction.ASC;
		    } else if (direction.equals("desc")) {
		      return Sort.Direction.DESC;
		    }

		    return Sort.Direction.ASC;
		  }
	
//	@GetMapping
//	public ResponseEntity<List<BlogPost>> findAll() {
//		return ResponseEntity.ok(BlogPostRecentPageService.findAll());
//	}
//	
	
	
	
////***** get all recent blogs ****
	
	@GetMapping("/page/RecentPage")
	@ApiOperation("get all recent pages")
	public ResponseEntity<Map<String, Object>> getAllPages(
			@RequestParam(required = false) String title,
		      @RequestParam(defaultValue = "0") int page,
		      @RequestParam(defaultValue = "3") int size,
		      @RequestParam(defaultValue = "blogId,desc") String[] sort) {
		try {
		      List<Order> orders = new ArrayList<Order>();

		      if (sort[0].contains(",")) {
		        
		        for (String sortOrder : sort) {
		          String[] _sort = sortOrder.split(",");
		          orders.add(new Order(getSortDirection(_sort[1]), _sort[0]));
		        }
		      } else {
		      
		        orders.add(new Order(getSortDirection(sort[1]), sort[0]));
		      }

		      List<BlogPost> BlogRecentPages = new ArrayList<BlogPost>();
		      Pageable pagingSort = PageRequest.of(page, size, Sort.by(orders));

		      Page<BlogPost> pageTuts;
		      if (title == null)
		        pageTuts = BlogPostRecentPageService.findAll(pagingSort);
		      else
		        pageTuts = BlogPostRecentPageService.findAll(pagingSort);

		      BlogRecentPages = pageTuts.getContent();

		      if (BlogRecentPages.isEmpty()) {
		        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		      }

		
		Map<String, Object> response = new HashMap<>();
		response.put("RecentPages",BlogRecentPages);
		response.put("currentPage", pageTuts.getNumber());
		response.put("totalBlogs", pageTuts.getTotalElements());
	    response.put("totalPages", pageTuts.getTotalPages());
	    return new ResponseEntity<>(response, HttpStatus.OK);
	    } catch (Exception e) {
	      return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	  }
	
	 
//	    @GetMapping("/page/{blogId}")                      //<---------------------          //////////////get by id
//		public ResponseEntity <BlogPost> findById(@RequestBody @PathVariable Long blogId){
//		Optional<BlogPost> blogRecentPage = BlogRecentPageService.findById(blogId);
//		return ResponseEntity.ok(BlogRecentPageService.findById(blogId).get());
//			 
//		}
//	    
//	    
//	    @PostMapping("/BlogPostCreate/create")            //<---------------------          //////////////sample creation
//		 public ResponseEntity <BlogPost> create (@RequestBody BlogPost blogRecentPage){
//			 return ResponseEntity.status(HttpStatus.CREATED).body(BlogRecentPageService.save(blogRecentPage));
//		}
//	    
//	    
//	    
//	    @PutMapping("/BlogPostUpdate/{blogId}")          //  <---------------------           //////////////sample updation
//		public ResponseEntity <BlogPost> update (@PathVariable Long blogId, @RequestBody BlogPost blogRecentPage){
//			return ResponseEntity.accepted().body(BlogRecentPageService.save(blogRecentPage));
//		}
//	    
//
//		@DeleteMapping("/BlogPostDelete/{blogId}")        //<---------------------            /////////////sample removal
//		public ResponseEntity delete(@PathVariable Long blogId) {
//			BlogRecentPageService.deleteById(blogId);
//			return ResponseEntity.accepted().build();
//			
//		}

	
	
	
	
	
	
////**************** get Single blog by blogId ************
	
//@GetMapping("/getBlog")  ////---------------get single blog by blogId
//public  BlogPage findBlogId(@RequestBody long blogId) {
//	return  blogPostImpl.getData(blogId);
//	
//}
	
//@PostMapping("/getBlog")
//public BlogPage getBlogByBlogId(@RequestBody BlogPage blogPage){
//    return blogByBlogIdService.getBlogByBlogId(blogPage.getBlogId());
//}


	

@PostMapping("/getBlog")
@ApiOperation("get blog by blog id")
public BlogPost getBlogByBlogId(@RequestBody BlogPostByBlogIdRequestDto blogPostByBlogIdRequestDto){
	BlogPost blogObj = new BlogPost(blogPostByBlogIdRequestDto.getBlogId());
    return blogPostByBlogIdService.getBlogByBlogId(blogObj.getBlogId());
}
	



/////****** getAllBlogPostsWithComment ********
@GetMapping("/getAllBlogPostsWithComment") ///////////////getAllBlogs ///BlogPost
@ApiOperation("get all blogs with comments")
public ResponseEntity<List<BlogPost>> getAllBlogPostsWithComment()  {
	return ResponseEntity.ok(BlogPostRecentPageService.findAll());
}

////**************** get All blogs ************************************************************

//@GetMapping("/getAllBlogs")
//@ApiOperation("get all blogs")
//public List<BlogPost> getAllBlogs(){
//    return getAllBlogsService.getAllBlogs();
//}

@GetMapping("/getAllBlogs")
@ApiOperation("get all blogs")
public ResponseEntity<List<BlogPost>> findAll() {
	return ResponseEntity.ok(BlogPostRecentPageService.findAll());
}


////**************** get a Single blog by Slug **********


@GetMapping("/getAllBlogBySlug/{slug}")
@ApiOperation("get all blogs by slug")
public  List<BlogPost> getAllBlogBySlug(@PathVariable String slug) {	
	return  blogPostSlugService.getBlogBySlug(slug);	
}

//@PostMapping("/getBlogBySlug")
//public List<BlogPage> getAllBlogBySlug(@RequestBody BlogPage blogPage){
//    return blogBySlug.getBlogBySlug(blogPage.getSlug());
//}


@PostMapping("/getAllBlogBySlug")
@ApiOperation("get all blogs by slug")
public List<BlogPost> getBlogBySlug(@RequestBody BlogPostSlugRequestDto blogPostSlugRequestDto){
	BlogPost slugObj = new BlogPost(blogPostSlugRequestDto.getSlug());
    return blogPostSlugService.getBlogBySlug(slugObj.getSlug());
}




////**************** get All blogs by status **********


//-------getByStatus---------
@GetMapping("/getAllBlogByStatus/{status}")
@ApiOperation("get all blogs by status")
public List<BlogPage> getAllBlogByStatus(@PathVariable long userId,String status){
	    return blogPostStatusService.getAllBlogs(userId,status);
	}

//@PostMapping("/getBlog")
//public BlogPage findByStatus(@RequestBody BlogPage blogPage){
//    return blogByStatus.getBlog(blogPage.getStatus());
//}

//@PostMapping("/getAllBlogs")
//public List<BlogPage> getByStatus(@RequestBody BlogPage blogPage){
//    return blogByStatus.getAllBlogs(blogPage.getStatus());
//}

@PostMapping("/getAllBlogByStatus")
@ApiOperation("get all blogs by status")
public List<BlogPage> getAllByStatus(@RequestBody BlogPostStatusRequestDto blogPostStatusRequestDto){
	BlogPage statusObj = new BlogPage(blogPostStatusRequestDto.getUserId(),blogPostStatusRequestDto.getStatus());
    return blogPostStatusService.getAllBlogs(statusObj.getUserId(),statusObj.getStatus());
}



////**************** get All blogs by AuthFlag **********


////////-------getByAuthFlag---------
@GetMapping("/getAllBlogByAuthFlag/{authFlag}")
@ApiOperation("get all blogs by auth flag --- authFlag = P/A")
public List<BlogPage> getAllByAuthFlag(@PathVariable String authFlag){
	System.out.println("authFlag--------"+authFlag);
	    return blogPostAuthFlagService.getAllBlogByAuthFlag(authFlag);
	}


@PostMapping("/getAllUserBlogByAuthFlagPendingActive")
@ApiOperation("get all blogs by auth flag --- authFlag = P/A")
public List<BlogPage> getAllByAuthFlagPost(@RequestBody BlogPostAuthFlagRequestDto2 blogPostAuthFlagRequestDto2){
	    return blogPostAuthFlagService.getAllBlogByAuthFlag(blogPostAuthFlagRequestDto2.getAuthFlag());
	}

//@PostMapping("/getAllBlogByAuthFlag")
//public List<BlogPage> getAllByAuthFlag(@RequestBody BlogPage blogPage){
//  return blogByAuthFlagService.getAllBlogByAuthFlag(blogPage.getAuthFlag());
//}



////////-------getByAuthFlag=P and status = A---------
@GetMapping("/getAllBlogByAuthFlagPendingStatusActive")
@ApiOperation("get all blogs by auth flag and status --- authFlag = P and status = A")
public List<BlogPage> getAllByAuthFlagStatus(){
	return blogPostAuthFlagService.getAllBlogByFlagStatus();
}


@PostMapping("/getAllUserBlogByAuthFlagPending")
@ApiOperation("get all blogs by ''UserId'' auth flag = P AND status = A")
public List<BlogPage> getAllBlogByAuthStatusUserId(@RequestBody BlogPostByAuthStatusUserIdRequestDto AuthStatusUserId){	
	BlogPage AuthStatusUser = new BlogPage(AuthStatusUserId.getUserId(),"A");
	return blogPostAuthFlagService.getAllBlogByAuthStatusUserId(AuthStatusUser.getUserId());
} 
//***********************************************************************************************************************
/*
@PostMapping("/getAllBlogByUserIdd")
@ApiOperation("get all blogs by UserId auth flag = P AND status = A")
public List<BlogPost> getAllUserBlogByAuthStatus(@RequestBody BlogPostAuthFlagRequestDto3 blogPostAuthFlagRequestDto3){
	BlogPost slugObj3 = new BlogPost(blogPostAuthFlagRequestDto3.getUserId());
    return blogPostAuthFlagService.getAllUserBlogByAuthStatus(slugObj3.getUserId());
}

*/
// ** -------- userId & AuthFlag & status
/*
@PostMapping("/getAllBlogByAuthFlag")
@ApiOperation("get all blogs auth flag")
public List<BlogPage> getAllBlogByAuthFlag(@RequestBody BlogPostAuthFlagRequestDto blogPostAuthFlagRequestDto){	
	BlogPage flagObj = new BlogPage(blogPostAuthFlagRequestDto.getUserId(),blogPostAuthFlagRequestDto.getAuthFlag(),blogPostAuthFlagRequestDto.getStatus());
//	   return blogAuthFlagService.getAllBlogByAuthFlag(blogAuthFlagRequestDto.getAuthFlag());
	return blogPostAuthFlagService.getAllBlogByAuthFlag2(flagObj.getUserId(),flagObj.getAuthFlag(),flagObj.getStatus());
}
*/
///** get All blogs by AuthFlag -- userId & AuthFlag --- BlogAuthFlagRequestDtoTwo**


//@PostMapping("/getAllBlgByAuthFlg")
//public List<BlogPageTwo> getAllBlgByAuthFlg(@RequestBody BlogAuthFlagRequestDtoTwo blogAuthFlagRequestDtoTwo){	
//	BlogPageTwo flagObj = new BlogPageTwo(blogAuthFlagRequestDtoTwo.getAuthFlag(),blogAuthFlagRequestDtoTwo.getUserId());
////	   return blogAuthFlagService.getAllBlogByAuthFlag(blogAuthFlagRequestDto.getAuthFlag());
//	return blogByAuthFlag.getAllBlgByAuthFlg(flagObj.getAuthFlag());
//}




//************* Single Blog with Comment Section *************

@GetMapping("/getSingleBlogWithComment/{blogId}")
@ApiOperation("get a blog")
public BlogPost getSingleBlogWithComment(@PathVariable long blogId){
    return blogcommentrepo.findById(blogId);
}

//**************** PARENT Comment Save Section *************  Closed

//@PostMapping(value="/commentBox")
//public String publishPost( @RequestBody BlogParentComment blogParentComment){   //BlogChildComment
//	blogCommentService.insert(blogParentComment);
//	//commentService.insert(SquadPlayer);
////    return "Posted";
////}
/////////////////////////////////////////////////////
//
//
//@PostMapping(path = "/ParentCommentBox")
//public BlogParentComment saveParentcommentBox(@RequestBody BlogParentComment blogParentComment) throws IOException  {
//	return blogCommentService.save(blogParentComment);
//	//return "Posted";
//}
//
////**************** CHILD Comment Save Section *************
//
//@PostMapping(path = "/ChildCommentBox")
//public BlogChildComment saveChildcommentBox(@RequestBody BlogChildComment blogChildComment) throws IOException  {
//	return blogCommentService.save(blogChildComment);
//	//return "Posted";
//}




//////*********** Update blogId wise replayCount from BlogPostComment to BlogPost ***********worked *****commented 11.22//

//
//@GetMapping("findAllCommment/findAllaaa")  //wkd--blgPstDAO
//public List<String> findAllll(){
//return blogPostDAO.findBlogId();
//}
//
//@GetMapping("/countOfBlogId")  //wkd--blgCmtRepo--wrkdddd
//public List<SampleModel> findAllll(){
//return blogcommentrepo.findBlogId();
//}


//**************11.22
/*
@GetMapping("/blogReplyCountUpdated/{blogId}")  //wkd--blgCmtRepoSample
@ApiOperation("get method for update the reply count")
public void UpdateReplyCount(@PathVariable long blogId){
blogPostReplyCountUpdateDao.updateReplayCount(blogId);

}
*/

////////////////******** Save Parent comment AND UPDATE THE RPLY COUNT***********



//@PostMapping(path = "/SaveBlogComment")
//public BlogPostComment SaveBlogComment(@RequestBody BlogPostComment blogPostComment) throws IOException  {
//	return blogCommentService.save(blogPostComment);
//	//return "Posted";
//}

//@PostMapping(value = "/SaveBlogParentComment")
//public Long saveParentComment( @RequestBody BlogPostParentComment blogPostParentComment){
//	 blogCommentSaveService.save(blogPostParentComment);
//    return blogPostParentComment.getParentId() ;
//}


@PostMapping(path = "/SaveBlogParentComment")
@ApiOperation("Parent Comment")
public Long saveParentComment(@RequestBody BlogPostParentCommentRequestDto blogPostParentCommentRequestDto) throws IOException{
	BlogPostParentComment ParentComment = new BlogPostParentComment(blogPostParentCommentRequestDto.getBlogId(),blogPostParentCommentRequestDto.getUserId(),blogPostParentCommentRequestDto.getParentContent());
	blogPostCommentService.save(ParentComment);
	return ParentComment.getParentId() ;
}

////////////////******** DELETE Parent comment AND UPDATE THE RPLY COUNT********************************

@DeleteMapping(path = "/deleteBlogParentComment")
public String deleteParentComment(@RequestBody BlogPostParentCommentDeleteRequestDto blogPostParent) throws IOException{
	blogPostCommentService.deleteParentComment(blogPostParent.getBlogId(), blogPostParent.getParentId());
	return "Parent Comment Deleted";
}


////////////////******** Save Child comment *********************************************************


//@PostMapping(value = "/SaveBlogChildComment")
//public String saveChildComment( @RequestBody BlogPostChildComment blogPostChildComment){
//	 blogCommentSaveService.save(blogPostChildComment);
//    return "CHILD - COMMENT SAVED";
//}

@PostMapping(path = "/SaveBlogChildComment")
@ApiOperation("Child Comment")
public Long saveChildComment(@RequestBody BlogPostChildCommentRequestDto blogPostChildCommentRequestDto) throws IOException{
	BlogPostChildComment ChildComment = new BlogPostChildComment(blogPostChildCommentRequestDto.getBlogId(),blogPostChildCommentRequestDto.getUserId(),blogPostChildCommentRequestDto.getParentId(),blogPostChildCommentRequestDto.getChildContent());
	blogPostCommentService.save(ChildComment);
	return ChildComment.getChildId();
}


////////////////******** DELETE Child comment ************************************************


@DeleteMapping(path = "/deleteBlogChildComment")
public String deleteChildComment(@RequestBody BlogPostChildCommentDeleteRequestDto blogPostChildCommentDeleteRequestDto) throws IOException{
	blogPostCommentService.deleteChildComment(blogPostChildCommentDeleteRequestDto.getBlogId(),blogPostChildCommentDeleteRequestDto.getChildId());
	//blogPostChildDeleteCommentDao.deleteChildCommentCount(blogPostChildCommentDeleteRequestDto.getBlogId());
	return "Child Comment Deleted";
}


/////************ SampleRepoSample parent **********

//@GetMapping("/getReplayCount") 
//public List<SampleModel> getReplyCount(@PathVariable long blogId) {
//	return blogReplyCountRepo.getReplyCount(blogId); }
//

///////////////////////// ******* COMMENTED API ******* ////////////////
//
//@GetMapping("findAllCommment/findAll")
//public List<BlogPost> findAll1(){
//  return blogcommentrepo.findAll();
//}
//
///////////////////////// ******* COMMENTED API ******* ////////////////

/*

//@GetMapping("/getAllaaaaaaa/{userId}")
//public List<BlogPage> getBlogId(@PathVariable long userId){
//  return BlogPageDao.getBlogId(userId);
//}

@GetMapping("/getAllaaaaaaa/{userId}")
public ResponseEntity<List<BlogPost>> findBlogId(@PathVariable long userId) {
	return ResponseEntity.ok(BlogRecentPageService.findBlogId(userId));
}

*/



//    @GetMapping("/getBlog/{blogId}")
//	public ResponseEntity <BlogPost> findById(@RequestBody @PathVariable Long blogId){
//	Optional<BlogPost> blogRecentPage = BlogRecentPageService.findById(blogId);
//	return ResponseEntity.ok(BlogRecentPageService.findById(blogId).get());
//		 
//	}
    
 
//    @PostMapping("/save/saveBlogs")
//	 public ResponseEntity <BlogPost> create (@RequestBody BlogPost blogPost){
//		 return ResponseEntity.status(HttpStatus.CREATED).body(BlogRecentPageService.save(blogPost));
//	}
//    
    
    
//    @PutMapping("/updateBlog/{blogId}")
//	public ResponseEntity <BlogPost> updateBlog (@PathVariable Long blogId, @RequestBody BlogPost blogPost){
//		return ResponseEntity.accepted().body(BlogRecentPageService.save(blogPost));
//	}
    

/////////////////////// ******* COMMENTED API ******* ////////////////
//
//	@DeleteMapping("/deleteBlog/{blogId}")
//	public ResponseEntity deleteBlog(@PathVariable Long blogId) {
//		BlogRecentPageService.deleteById(blogId);
//		return ResponseEntity.accepted().build();
//		
//	}
////////////////////// ******* COMMENTED API ******* ////////////////

	
//	@PostMapping(path = "/saveBlog")
//	public String saveBlog(@RequestBody BlogPost blogPost) throws IOException  {
//		//BlogPost TempBlogPost = new BlogPost(blogPost);
//		blogPostService.save(blogPost);
//		return "success";
//	}
/*	
	@PostMapping(path = "/saveBlog")
	@ApiOperation("to post a blog")
	public String saveBlog(@RequestBody BlogPostSaveRequestDto blogPostSaveRequestDto) throws IOException{
	BlogPost TempBlogPost = new BlogPost(blogPostSaveRequestDto.getSummary(),blogPostSaveRequestDto.getContent(),blogPostSaveRequestDto.getMetaTitle(),blogPostSaveRequestDto.getStatus(),blogPostSaveRequestDto.getTitle(),blogPostSaveRequestDto.getUserId(),blogPostSaveRequestDto.getSlug());
	   blogPostSaveService.save(TempBlogPost);
			return "BLOG SAVED";
	}
*/
	@PostMapping(path = "/saveBlog")
	@ApiOperation("to post a blog with video url")
	public String saveBlog(@RequestBody BlogPostSaveRequestDto blogPostSaveRequestDto) throws IOException{
		
		BlogPost TempBlogPost = new BlogPost(blogPostSaveRequestDto.getSummary(),blogPostSaveRequestDto.getContent(),blogPostSaveRequestDto.getMetaTitle(),blogPostSaveRequestDto.getStatus(),blogPostSaveRequestDto.getTitle(),blogPostSaveRequestDto.getUserId(),blogPostSaveRequestDto.getSlug());
			long blogId = TempBlogPost.getBlogId();
			blogPostSaveService.save(TempBlogPost);
		BlogVideosUrls blogVideosUrls = new BlogVideosUrls(TempBlogPost.getBlogId(),blogPostSaveRequestDto.getUrl()); 
			blogPostVideosUrlsService.saveBlogPostVideosUrls(blogVideosUrls);
			return "BLOG SAVED";
	}

	
	////////////////// ******** BLog Like & Dislike ************ //////////////
	
	
	
//	@PostMapping(path = "/saveLike")
//	public String saveLike(@RequestBody BlogPostLike blogPostLike) throws IOException  {
//		blogPostLikeService.save(blogPostLike);
//		return "LIKED";
//	}
	
	
	@PostMapping(path = "/saveLike")
	@ApiOperation("Like")
	public Long saveLike(@RequestBody BlogPostLikeRequestDto blogPostLikeRequestDto) throws IOException  {
		BlogPostLike blogPostLike = new BlogPostLike(blogPostLikeRequestDto.getUserId(),blogPostLikeRequestDto.getBlogId());
		blogPostLikeService.save(blogPostLike);
		return blogPostLikeCountUpdateDao.likeCountReturn(blogPostLikeRequestDto.getBlogId());
		
	}
	
	
	@PostMapping(path = "/saveDisLike")
	@ApiOperation("Dislike")
	public long saveDisLike(@RequestBody BlogPostDisLikeRequestDto blogPostDisLikeRequestDto) throws IOException  {
		BlogPostLike blogPostLike = new BlogPostLike(blogPostDisLikeRequestDto.getUserId(),blogPostDisLikeRequestDto.getBlogId());
		blogPostLikeService.updateBlogPostDislike(blogPostLike);
		return blogPostDisLikeCountUpdateDao.disLikeCountReturn(blogPostDisLikeRequestDto.getBlogId());
	}
	
	
	////////////////// ******** Blog Video Urls ************ //////////////
	
	@PostMapping(path = "/saveUrls")
	@ApiOperation("to add video urls")
	public String saveUrls(@RequestBody BlogPostVideosUrlsRequestDto blogPostVideosUrlsRequestDto) throws IOException  {
		BlogVideosUrls blogVideosUrls = new BlogVideosUrls(blogPostVideosUrlsRequestDto.getBlogId(),blogPostVideosUrlsRequestDto.getUrl());
		blogPostVideosUrlsService.saveBlogPostVideosUrls(blogVideosUrls);
		return "VIDEO URL ADDED ";
	}
	
//////////////////******** BlogPost Status Updation ************ //////////////
	
	
	
	@PostMapping(path = "/statusUpdation")
	@ApiOperation("blog status updation")
	public long blogStatusUpdation(@RequestBody BlogPostStatusUpdateRequestDto blogPostStatusUpdateRequestDto) throws IOException  {
		BlogPost blogPost = new BlogPost(blogPostStatusUpdateRequestDto.getUserId(),blogPostStatusUpdateRequestDto.getBlogId(),blogPostStatusUpdateRequestDto.getStatus());
		blogPostStatusUpdateService.updateBlogPostCount(blogPostStatusUpdateRequestDto.getUserId(),blogPostStatusUpdateRequestDto.getBlogId(),blogPostStatusUpdateRequestDto.getStatus());
		return 1;
	}
	
//////////////////******** BlogPost AuthFlag Updation ************ //////////////
	
	/*
	
	@PostMapping(path = "/authFlagUpdation")
	@ApiOperation("blog auth flag updation")
	public String blogAuthFlagUpdation(@RequestBody BlogPostAuthFlagUpdateRequestDto blogPostAuthFlagUpdateRequestDto) throws IOException  {
		BlogPost blogPost = new BlogPost(blogPostAuthFlagUpdateRequestDto.getUserId(),blogPostAuthFlagUpdateRequestDto.getBlogId(),blogPostAuthFlagUpdateRequestDto.getAuthFlag());
		blogPostAuthFlagUpdateService.updateBlogPostAuthFlag(blogPostAuthFlagUpdateRequestDto.getUserId(),blogPostAuthFlagUpdateRequestDto.getBlogId(),blogPostAuthFlagUpdateRequestDto.getAuthFlag());
		return "Your BlogPost AuthFlag Updated as  " +blogPostAuthFlagUpdateRequestDto.getAuthFlag();
	}
	*/
	@PostMapping(path = "/authFlagUpdation")
	@ApiOperation("blog auth flag updation --- authFlags = A, authUser = userId, published = 1, publishedAt, authDate & updated_at = current date & time")
	public long blogAuthFlagUpdation(@RequestBody BlogPostAuthFlagUpdateRequestDto blogPostAuthFlagUpdateRequestDto) throws IOException  {
		BlogPost blogPost = new BlogPost(blogPostAuthFlagUpdateRequestDto.getUserId(),blogPostAuthFlagUpdateRequestDto.getBlogId());
		blogPostAuthFlagUpdateService.updateBlogPostAuthFlag(blogPostAuthFlagUpdateRequestDto.getUserId(),blogPostAuthFlagUpdateRequestDto.getBlogId());
		return 1;
	}
	
	
////////////////////// ******* COMMENTED API ******* ////////////////
	
//	@GetMapping(path = "/blogSelectAll")
//	public ArrayList<BlogPost> selectAll() {
//		return blogSaveService.selectAll();
//	}
	
/////////////////////// ******* COMMENTED API ******* ////////////////


	
////////*************** Get Categories *************
	@GetMapping("/getAllBlogCategories")
	@ApiOperation("get all blog categories")
	public List<BlogPostCategoryResponseDto> getAllBlogCategories(){
		return blogPostCategoryService.getAllBlogCategory();
	}
	
	
////////*************** Get Sub-Categories *************
	@PostMapping("/getAllBlogSubCategories")
	@ApiOperation("get all blog sub-categories")
	public List<BlogCategoryMaster> getAllBlogSubCategories(@RequestBody BlogPostSubCatRequestDto blogPostSubCatRequestDto){
		BlogCategoryMaster blogCat = new BlogCategoryMaster(blogPostSubCatRequestDto.getParentCatId());
		return blogPostCategoryService.getAllBlogSubCategories(blogCat.getParentCatId());
	}
	
	
////////*************** Get All blogs based on Categories & Sub-Cat *************
	@PostMapping("/getAllBlogsByCategories")
	@ApiOperation("get All blogs based on Categories & Sub-Cat")
	public List<BlogPost> getAllBlogsByCategories(@RequestBody BlogPostCatMapRequestDto blogPostCatMapRequestDto){
		return blogPostCategoryService.getAllBlogsByCategories(blogPostCatMapRequestDto.getCategoryId());
	}


}
